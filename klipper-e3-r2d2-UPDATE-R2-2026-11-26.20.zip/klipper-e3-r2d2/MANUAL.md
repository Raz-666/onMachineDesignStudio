# R2-D2 Macro System — The User Manual

**Package:** `klipper-e3-r2d2` · Ender-3 + BTT SKR mini E3 + Pi Zero 2 W (Mainsail) ·
12864 LCD (16 characters per line)

**Version:** this manual describes the current release, `R2-2026-11-19.3` — and only it. Every chapter documents what the system
does today; the version changelog lives in README.md.

This is the operating manual for the complete macro system: what the printer can
do, how every kind of file is printed, plotted or turned into labels and partial
prints, and how to tune a running job. It is organized the way you use the
machine — daily workflow first, generators next, calibration after that,
reference tables at the end. Installation and wiring live in the appendices.

**How to read this manual**

- **New to the system?** Read chapters 2–4. They walk you from uploading a file
  to a finished print — including every dialog you will meet.
- **Want to make labels, plot an image or print just a section of a file?**
  Chapter 5 covers all three generators with every parameter.
- **Print quality to improve?** Chapter 10 is the calibration ladder — in the
  order it should be done, matching the Maintenance menu on the LCD.
- **Looking for a specific menu, macro or console message?** Chapters 14–25 are
  the reference part; the cheat sheet (ch. 24) has the short paths.

## Table of contents

1. [Safety first](#1-safety-first)
2. [The system in five minutes](#2-the-system-in-five-minutes)
3. [From file to print — the daily workflow](#3-from-file-to-print--the-daily-workflow)
4. [Scenario library — every file type walked through](#4-scenario-library--every-file-type-walked-through)
5. [The generators: Range, Labels, Plotter, Cable ties, Angles, Lithophanes (+ Spray stencils), ColorPic, Gaskets, Frames, Bricks, Kits & Figures, String Art](#5-the-generators-range-labels-plotter-cable-ties-angles-lithophanes-spray-stencils-colorpic-gaskets-frames-bricks-kits--figures-string-art)
6. [During the print: tuning, pauses, objects](#6-during-the-print-tuning-pauses-objects)
7. [Filament: load / unload / change / runout / cold pull](#7-filament-load--unload--change--runout--cold-pull)
8. [Temperature system L1/L2](#8-temperature-system-l1l2)
9. [Speed, acceleration & machine limits](#9-speed-acceleration--machine-limits)
10. [Calibration — the ladder to good prints](#10-calibration--the-ladder-to-good-prints)
11. [Bed mesh & KAMP](#11-bed-mesh--kamp)
12. [Purge / prime line](#12-purge--prime-line)
13. [Maintenance & care](#13-maintenance--care)
14. [LCD menu reference](#14-lcd-menu-reference)
15. [Overrides reference](#15-overrides-reference)
16. [Sound reference](#16-sound-reference)
17. [Console messages](#17-console-messages)
18. [System: Klipper & Pi](#18-system-klipper--pi)
19. [Variables & editing the .cfg files](#19-variables--editing-the-cfg-files)
20. [What happens when a macro executes](#20-what-happens-when-a-macro-executes)
21. [Troubleshooting](#21-troubleshooting)
22. [Limits & known behavior](#22-limits--known-behavior)
23. [Cheat sheet: LCD paths & Mainsail commands](#23-cheat-sheet-lcd-paths--mainsail-commands)
24. [Complete macro index](#24-complete-macro-index)
25. [Electronics & expansion — U2C + EBB42 + Relay V1.2](#25-electronics--expansion--u2c--ebb42--relay-v12)

Appendices: [A Installation](#appendix-a-installation-detailed) ·
[B Power & electrics](#appendix-b-power--electrics) ·
[C First start & updates](#appendix-c-first-start--updates)

---

## 1. Safety first

A 3D printer combines hot heaters, high currents and unattended hours. This system
adds software guardrails — software is never a substitute for hardware safety.

**Hardware safety you should have**

- **Smoke detector** in the printer room — printers are fire load, especially overnight.
- Fused mains side, PSU with protection circuitry, cables in good condition.
- Cable strain relief at the heatbed (the classic Ender-3 chafe point).
- Clean bed, free airflow around the electronics, nothing flammable stacked on top.
- Never print behind a locked door; do not leave the printer alone for days.

**What the macro system does for you**

- Heaters off at print end (`heaters_off_at_end`) + hotend fan cool-down (`cooldown_fan_time`, default 30 s).
- Pauses KEEP temperatures on purpose (you want to continue) — CANCEL_PRINT turns heaters off.
- SYS_SHUTDOWN: heaters/fans off BEFORE the Pi goes down (two presses).
- After a Klipper error: alarm sound, system goes idle.
- Runout pauses at the next layer boundary — detected BEFORE the print starves.
- EMERGENCY_STOP (System menu or console) halts everything immediately.

**Smoke / heat action plan**

```
EMERGENCY_STOP  ->  switch off at the MAINS  ->  if smoking:
extinguish with CO2/foam only - NEVER water on live electronics
```

NOT protected by macros: a stuck MOSFET, a blocked fan, a loose heater cartridge.
Inspect the printer regularly.

## 2. The system in five minutes

**One idea carries the whole system: every file gets intercepted before it
prints.** A small Python service watches the gcodes folder and enriches every
arriving file; the macro layer catches every print start and holds it until you
have decided how it should run. Between the two, the printer always knows what
a file contains — material, layers, features, speeds — and can take over any
parameter without re-slicing.

**The Python tools (tools/)**

| Tool | What it does | When it runs |
|---|---|---|
| `r2_postproc.py` | THE interceptor: watches the gcodes folder (systemd service, 1 s heartbeat). Tags every new G-code with `LAYER_MARK` layer markers, an `APPLY_TYPE` marker after every `;TYPE:` comment and a `_FILE_INFO` parameter block (material, layer height × count, line widths, flow ratio, PA, by-object, nozzle, wall loops, measured per-feature speeds and accels). Contains the generators (Range, Labels, calibration towers, bridging test, resonance plates) and the plot converters (PNG/JPEG/SVG/PDF/TXT → pen-plotter G-code). | continuously (service) |
| `r2_postproc_next.py` | **the experimental copy** of the post-processor: byte for byte the same code as `r2_postproc.py` from .142h on, and from now on the file where new development happens. Never started directly — the stable file hands over when the LCD switch (System > PP engine) says `next`; a broken copy falls back to stable by itself (ch. 19a3) | selected by the switch |
| `r2_collect.py` | **the evidence pack**: one file with versions, host health, services + journals, the watcher state, `variables.cfg`, `printer.cfg`, a compact incident digest out of `klippy.log` (shutdowns, probe failures, the worst Reactor stalls with stacks, MCU statistics), the log tail and the newest MCU snapshot — written to `gcodes/crash_archive/` as `.txt` + `.txt.gcode` so Mainsail lists it for download (ch. 19a2) | on demand (LCD System > Diagnostics, or SSH) |
| `make_label_fonts.py` | builds the label fonts (stroke skeletons) that are baked into `r2_postproc.py` — SMOOTH, MONO and the small-text fonts COND, NARROW, CAPS. | build time only (not needed on the Pi) |
| `macro_render_test.py` | the 900+ test battery the package is built against | after edits |
| `config_validator.py` | checks all cfg modules + save-variable keys | after edits |
| `r81_golden_check.py` | byte-level regression net for the postproc paths | after edits |

Files are never destroyed: tagging rewrites a file once when it arrives
(already-tagged files skip); generators and converters always write NEW files.

**The mode state machine.** The macro `_STATE` always knows the mode:
idle → waiting (start dialog) → starting → printing → paused → filament →
finished → idle. Nearly every macro checks it first — PAUSE in idle just
answers politely.

**The watcher (macro side, 1-second heartbeat)**

- catches prints started WITHOUT PRINT_START (legacy files) → activates
  overrides + live tuning, resets the layer state
- counts layers via Z when the file has no LAYER_MARK markers (and in AS LEGACY
  mode)
- switches L1→L2 temps/fan/speed at the tracked layer 2 — mirror of LAYER_MARK
- detects sequential object changes (Z falling edge)
- temperature tower band control
- self-heals stuck pause states, disarms expired cancels (60 s), finishes
  legacy prints properly

**Overrides instead of re-slicing**

```
Rule:     override ON + value > 0  =  applied. Otherwise the file rules.
Priority: LCD override (ON)  >  file value  >  material preset.
```

M104/M109/M140/M190/M106/M204/M220/M221/SET_PRESSURE_ADVANCE/SET_RETRACTION from
the file are intercepted and redirected — strictly by layer (ch. 8). The
interceptors remember what the FILE asked for — temps, PA, retraction, fan
value, flow factor (shown as `File H:215/210C` hints in the menus). This is why
you can print the SAME file in a different material without opening the slicer:
load another material preset (Pre-Print > Material) and start AS LEGACY.

**Universal print intercept.** SDCARD_PRINT_FILE (print button), M24 (LCD
file list) and M23 (the stock SD list's file tap) catch EVERY print: the file is loaded and **held at position 0** —
not a single command runs before your decision. Then: homed if needed, start
dialog. The decision rides along until the file identifies itself; a net probe
(`_START_NET_PROBE`) catches files that neither heat nor call any start macro
and gives them home + heat + purge.

**Render before execute.** Klipper renders a whole macro template BEFORE
running it — a macro cannot see values it just set. Verification phases
therefore run as `delayed_gcode` seconds later (ch. 21). This one fact explains
most quirks:

| What you see | What it really is | What to do |
|---|---|---|
| a macro seems to "wait" for a state it just set | render-before-execute | nothing — by design |
| M104 logs "OVERWRITE" but the temp stays at the file value | print runs AS SLICED | switch mode or set the overwrite ON |
| "State re-synced" after an object change | watcher self-healing | cosmetic — ignore |
| LCD shows "File: …" next to your override | the interceptor captured the file value | compare on the spot |

## 3. From file to print — the daily workflow

This chapter is the complete path from "I have a file" to "the print is done",
with every click along the way. Later chapters go deeper; this one keeps you
moving.

### 3.1 Getting a file onto the printer

**Via Mainsail (recommended).** Drag the file into the gcode files panel (or
use Upload). Within a second of arriving, the postproc service has read and
tagged it: `; R2-POSTPROC v4` at the top, a `_FILE_INFO` parameter block after
the first command line, `LAYER_MARK` before every layer and `APPLY_TYPE` after
every `;TYPE:` comment. The console logs one line per file, e.g.
`[ok] vase.gcode: +312 LAYER_MARK (layer comments), +58 APPLY_TYPE, _FILE_INFO (layers=312, by_object=False)`.

**Via USB / scp / download.** Same thing — anything that lands in the gcodes
folder is processed, foreign downloads included. Files already carrying the
tag are skipped (nothing is double-processed).

**Selecting on the LCD.** The printer's file list (M24 path) opens the start
dialog before anything moves (see 3.5). At the moment you SELECT a file, its
`_FILE_INFO` is replayed to the system: Pre-Print > File info + Live Tuning > File (G-code) immediately.
Since .135 it also carries `SEQWARN=n` — the sequence audit's count of impossible feature
orders (ironing on layer 1 or before the layer's first top, brim outside the first layers,
top surface on layer 1). It is a FLAG only: tagged data always wins, nothing is rewritten.
shows THAT file's values — material, layers, speeds, features — never
leftovers from the previous print.

**What the selection preview tells you** (Pre-Print > File info, same data as the
Live Tuning > File (G-code) panel):

| Field | Meaning |
|---|---|
| Type | MARKED (fully tagged) / LEGACY (no markers) / PLOT (pen file) |
| Sliced by | R84: the slicer + version and the firmware flavor the file was made for (OrcaSlicer, PrusaSlicer, Cura, Elegoo, Kiri:Moto, AstroPrint, SliceBeam, … for Klipper / Marlin) — works for fresh uploads AND foreign downloads |
| Material, layer height × count, line width, flow ratio | straight from the slicer header |
| By-object | sequential printing detected (several objects, Z falls) |
| Feat | R220: the features this file really contains, as compact codes (WO WI = walls, IS/IL = infill, ST/SB = surfaces, BR/BM = bridge/brim, SU support, IR ironing, C1..C9 custom blocks). Press = the full TYPES list. Same row in Start? > File info |

**Preheat on select (182 °C):** the moment a file is
selected the nozzle preheats to **182 °C** and the bed to 60 °C — the
nozzle value is the **filament-swap level**: hot enough to change filament
(the extruder needs ≥180 °C) while the start dialog still asks AS SLICED /
AS LEGACY, still below serious ooze. Editable: Pre-Print > Preheat. OFF
there → **the selection stays cold** (no preheat at selection); after you
decide, the start sequence heats the usual way — home, mesh, target temps,
purge — the "last few degrees" shortcut only applies to the standby preheat.

**Two file quirks the system flags and FIXES for you — in place, no
re-upload:**

- **Marlin-volumetric files** (`;FLAVOR:Marlin (Volumetric)`, e.g. from Cura):
  they count E in mm³ — Klipper expects mm and would print them heavily
  under-extruded. The file info shows the warning and the print start says it
  out loud (alarm + M117). **Pre-Print > File info > `Vol->mm fix`** converts the
  file directly: every E value (including G92) is divided by the filament
  cross-section (1.75 mm → 2.405 mm²), the volumetric markers are neutralized
  and a conversion note lands in the header. R2-D2 beeps at the start and
  plays the happy tune when the file is Klipper-ready (then simply select it
  anew). Idempotent — a converted file is never converted twice.
- **Old Bowden-era files** with long baked-in retracts (5–6 mm where your
  direct extruder wants ~0.8): select the file, then **Pre-Print > File info >
  `RetFix file`** — the watcher rewrites the file ON DISK: clean
  retract/unretract pairs become **G10/G11** (firmware retraction), so your
  CURRENT retraction applies — live-tunable during the print. The R2 markers
  survive (no re-processing needed), wipes and folded retracts stay
  untouched, start beep + done beep, and the console reports the pair count.
  If a start dialog holds the file it is released automatically first. For
  future uploads you can instead leave **Pre-Print > File info > RetFix ON** — every new
  upload gets the treatment automatically.
- **The offer only shows when it applies:** it appears for files with
  **classic `G1 E-` retracts** (the convertible kind). Files that already
  use **firmware retraction (G10/G11)** — e.g. OrcaSlicer with firmware
  retraction enabled — and files whose retracts are **already fixed** never
  show `RetFix file` again. The file info says which case you have: `retract … (firmware
  G10/G11)` / `(FIXED -> G10/G11)` / `(slicer moves — Pre-Print > File info:
  RetFix!)` / nothing detected = offer stays hidden (field log .72).

| FS_* / FA_* | the MEASURED original speed / acceleration of each feature |
| L1/L2 temps, PA, retraction, fan, nozzle, wall loops | everything Pre-Print can override |

**Click pacing:** actions that write many values at once (material
select, preset load/save, range create, file fixes, the part generators)
insert ~100 ms micro-pauses between the disk writes — the Pi Zero never faces
a write burst. While a print runs the pauses no-op (a dwell would stutter
motion).

### 3.2 What the tools do with every file — the flow

```
upload / copy / scp ──►  gcodes folder
                              │  r2_postproc.py (service, 1 s)
                              ├─ G-code ──► tagged in place: LAYER_MARK,
                              │             APPLY_TYPE, _FILE_INFO, TYPES/FS/FA
                              ├─ photo.png / .jpg / .svg / .pdf / .txt
                              │        ──► untouched: select it in the file
                              │            list → Vnn_Plot_* generated on demand
                              └─ generated later on demand (Vnn_ leads =
                                  top of the list + your version number):
                                  Range Vnn_<src>_L<a>-<b>.gcode
                                  Label Vnn_<text>.gcode
                                  TempTower / RetractTower / FlowCube /
                                  Bridge / Resonance plates
                              ▼
        you press PRINT ──► file held at position 0 ──► start dialog
                              ▼
        AS LEGACY (takeover) or AS SLICED (file 1:1)
                              ▼
        homing → bed temp → adaptive mesh → hotend → nozzle wipe → purge line
                              ▼
        layer 1: L1 temps, fan off, speed brake ──► layer 2: L2 temps,
        file fan back, 100% speed ──► … print … ──► PRINT_END: park,
        stats, fanfare, cooldown, heaters off
```

Everything in this flow is live tunable and pausable (ch. 6), every object is
skippable, and the print can be ended normally at any planned layer (ch. 6.5).

### 3.3 G-code file types and how the system tells them apart

The system classifies every file — this decides what the start dialog offers
and which automatic rules apply:

| File type | How it is detected | What the system does |
|---|---|---|
| **Print by layer** (normal) | layer comments (`;LAYER_CHANGE`, `;LAYER:n`, `;CHANGE_LAYER`) or Z-scan; `BY_OBJECT=0` | the normal case: L1 rules on layer 1, L2 switch at layer 2, feature overrides per `APPLY_TYPE` |
| **Print by object** (sequential) | several objects + Z falling edges (`BY_OBJECT=1`), or falling `;Z:` comments | at every object change: L1 temps + L1 speed again (pause only if a heater must actually move), next object's layer 2 switches back to L2 — the layer counter re-anchors at every object start |
| **Multi-object with object data** | `EXCLUDE_OBJECT_DEFINE` lines in the file | adaptive KAMP mesh over the real objects, per-object skip (ch. 6.5), smart parking away from the remaining objects — a documented compromise: on the Pi Zero 2 W object processing OFF is recommended, such files then mesh full-bed (ch. 19b) |
| **Vase mode** (continuous Z) | Z-scan: slow continuous rise < 0.05 mm per move | layer marks accumulate until 0.18 mm — vase prints still get layer events; spiral files run like any other |
| **Legacy file** (old slicer profile, foreign download, no markers) | no `; R2-POSTPROC` tag, no PRINT_START | watcher catches the start → LEGACY start dialog; AS LEGACY = full takeover (mesh, purge, L1/L2, Z layer counting) |
| **Old mod file** (calls its own START_PRINT) | `START_PRINT` in the file | real legacy start: homing, heat, purge — then your decision rules |
| **Pure movement data** (no heaters, no start macro) | net probe: nothing heats, nothing calls | home + heat + purge before the file runs 1:1 |
| **Plot file** (pen) | `; R2-PLOT` header | plotter flow: no purge with a pen, AS LEGACY heats only when the extruder is ON; live tuning works while plotting |
| **Generated file** (Range / Labels / towers / plates) | carries the tag + PRINT_START header | runs through the NORMAL start flow like any sliced file |

**Layer detection without comments:** files without layer comments get a
Z-scan — a Z rise between 0.05 and 0.35 mm on an extruding move is a layer
boundary; a slow continuous rise is treated as vase mode. You see the method in
the console (`(Z scan)` vs `(layer comments)`).

### 3.4 Pre-Print — the settings before you start

Pre-Print is the panel you visit while the printer heats or before you commit.
Everything here is saved and reused; nothing is lost on restart.

| Entry | Contents |
|---|---|
| Offset X/Y/Z | SET_GCODE_OFFSET for X/Y/Z at the very top: ±0.1 mm steps + fine rows with ±0.05 mm (halved steps for the last bit of baby-sitting), applied live (MOVE=1) |
| File (G-code) | full slicer summary of the SELECTED file (type, material, layers, speeds, accels, temps, PA, retraction) + 16 feature activator rows: each shows the file's real speed and an ON switch — features the file does not contain show 'n/a' and refuse · Flow line: MAXRATE mm³/s (+ seam position, + *derived* marker when the geometry classifier tagged this file) · Cap / Fix flow cap + TAcc / Fix travel accel |
| Material | LOAD NOW + all material values (Bed/Hotend L1/L2, PA + smooth, flow, retract, fan L2) + Save as preset — edits of the ACTIVE material apply live |
| Temperatures | Bed/Hotend L1/L2 + Fan L2 (ON/OFF each) + the file's own values for comparison |
| Velocity | retraction length/speed/unretract + File R: display, acceleration, velocity, minimum cruise ratio, square corner (ON/OFF each) + Z-Hop ON/OFF + height — the global PA moved to PA per feat. **Drive** at the top of Retraction: DIRECT/BOWDEN starting-point profile (SET_EXTRUDER_DRIVE) — sets sane values, everything stays freely editable; ranges span both worlds (length 0–15 mm, speeds 5–100 mm/s) |
| Spd/Acc/PA/Flw per feat | four quick lists (also in Live Tuning): per-feature speed / accel / PA / flow, each led by its GLOBAL — 1st-layer speed (Spd), global accel + ON (Acc), global PA + smooth + File PA (PA), global flow + ON (Flw) — plus Now: the feature currently printing. The old top-level Speeds/Accels/Flow menus were merged here |
| Features | 16 submenus, one per feature (outer/inner wall, overhang wall, sparse/solid infill, top/bottom surface, bridge, internal bridge, gap fill, support, ironing, skirt, brim, prime tower, custom code) **plus the numbered custom slots C1..C9 of this file** (.136l — only the groups the file really carries appear): file original + ON switch + speed % + accel + flow + PA each |
| Bed Mesh | Level old files · Mesh ON/AUTO/OFF · Save after · Adaptive · Travel cap while meshing · Calibrate now · Load…/Delete… |
| Profiles | per-file profiles (pre/post) + default profiles + material presets — see 3.4a |
| Range/Stop | planned end at layer N + the range generator with floor/top holes (ch. 5.1) |
| Filament | Load / Unload / Change (M600) before the print, load & unload lengths |
| Plotter | only for plot files: PEN FILE picker, pen speed %, Pen Z, Shift X/Y, Reset overrides — at the very END of Pre-Print |

**The golden rule:** overrides only apply when they are ON. A stored value
without ON never touches the print; the file rules until you switch something
on.

### 3.4a Per-file profiles — the memory of every print

Every legacy-printed file can carry its OWN profile: all pre-print settings
(temps L1/L2, PA + smooth, retraction, motion, flow, fan, ironing flow,
first-layer speed, material, all 16 feature switches with their speed/accel
values) plus everything you tuned LIVE during the print. Two slots per file:

| Slot | Written | Read |
|---|---|---|
| **pre** | MANUALLY: Pre-Print > Profiles > This file > Save as pre | Load button — and at every file selection when Auto-load is ON |
| **post** | LEGACY entries from older versions — load or delete them manually; nothing is ever written here (the after-print decision is the **Rate print?** question, §3.7a) | Load / Delete button |

Rules of the game:

- **Auto-load applies YOUR `pre`** when one exists — a legacy `post`
  slot never auto-applies (it stays manually loadable).
- Cancelled prints write nothing.
- The key is the file path below the gcodes root, so `Petg/vase.gcode` and
  `vase.gcode` are two different files — exactly like the selection list.
- Pre-Print settings beat material presets: applying a profile writes the
  values AND their ON switches (the old "load default preset never switched
  anything on" bug is fixed with the same code path).

**Pre-Print > Profiles** has three sub-menus:

| Sub-menu | Contents |
|---|---|
| Material | LOAD / SAVE / RESET for PLA, PETG, TPU (save writes the material values WITHOUT loading anything first) + LOAD/SAVE for ABS/ASA — the same presets as Pre-Print > Material |
| Defaults | the 8 standalone default profiles: Save (current state) · Info (list all) · Load 1–8 · Delete 1–8 |
| This file | Save as pre / Load pre / Load post / Delete pre / Delete post + Auto-load ON/OFF — load/delete items appear only when that slot exists |
| From optimized | the tuned library in `gcodes/optimized/`: pick a number and click — its values become the Pre-Print **starting point** for the next print (nothing is written to any file). Plus **Save last print > optimized**: the second chance if the Rate print? question was missed (idle only) |

`SAVE_MATERIAL_TEMPS`/`SAVE_DEFAULT_PRESET`/`SAVE_FILE_PROFILE` console
commands do the same as their menu items; `FILE_PROFILES_INFO` lists what is
stored for the selected file.

### 3.4b Pre-Print > Fixes — repair instead of re-slicing

Six in-place repairs for the SELECTED file (a `.r2bak`-style numbered copy
stays in the folder; nothing runs during a print, the start dialog steps
aside): **RetFix** (slicer retracts → G10/G11 — your live rules), **Vol →
mm** (Marlin volumetric E), **Flow cap** (moves over your mm³/s limit get a
lower F), **Travel / TAcc** (travel speed + accel, live markers), **Segments**
(micro-move flood merged — MCU safe), **File check** (retag old files).
**.136n adds two more:**

- **Fix: Quality — the travel golden rule on a sliced file.** A travel
  keeps its retract + Z-hop **only when it crosses ink the nozzle would
  hit**: plastic of the **same layer** (the layer height is measured from
  the file itself) — endpoint touches and parallel neighbor lines never
  count — or **sacred ink of any layer** (outer wall, top/bottom surface,
  ironing: the faces you look at). Every other retract/hop block **drops**
  and its travel prints directly; that is where the time comes from. A
  crossing that rides **without any retract at all** (the slicer never
  armored it) gets the file's **own** retract values — length and F copied
  from the first retract in the file — and **never an invented Z-hop**;
  files without any retract are honestly reported instead (nothing is
  invented). The feature recognition contributes ONLY the travel detection
  here — no feature is re-tagged, nothing but travels is touched.
- **Fix: Speed — direct ways + ironing skipped.** Consecutive travel
  lines (no extrusion between them) merge into ONE move to the final
  target — the deceleration ramps of the intermediate stops were pure
  time; the position after the block stays exactly the same. And the
  whole **ironing pass is skipped** (the slowest, cosmetic-only pass of
  the file): its extrusion moves drop, the feature boundaries stay, and
  absolute-E files get a `G92` stitch so every following move keeps its
  meaning.

Console: `FIX_FILE WHAT=QUALITY` / `FIX_FILE WHAT=SPEED`. Both fixes
stamp `; R2-QUALITYFIX:` / `; R2-SPEEDFIX:` lines into the file and
report what they did.

### 3.5 The start dialog — AS LEGACY or AS SLICED

Every print start (print button, LCD list, PRINT_START) stops at the dialog:

| Mode | LCD / console | What rules |
|---|---|---|
| **AS SLICED** | > PRINT AS SLICED · `PRINT_AS_SLICED` | the FILE's VALUES, truly 1:1 — no overrides, no first-layer brake beyond the L1/L2 rules, no sequential restarts. Live commands still apply. "1:1" refers to temps/speeds/flow: the infrastructure (home, mesh, purge, park) still runs around the file. The first-layer rules shape **layer 1** (material L1 temps, fan off); **from layer 2 the file runs 1:1** — its own M104/M140 stand, only YOUR armed L2 override still wins. Toggle the rules with Pre-Print > Temperatures > L1 rules |
| **AS LEGACY** | > PRINT AS LEGACY · `PRINT_AS_LEGACY` | takeover with YOUR parameters: overrides ON (L1/L2 temps, PA, retraction, machine limits, flow), mesh + purge, Z layer tracking, sequential object handling |
| CANCEL | > CANCEL | aborts cleanly — nothing was heated |

**How to decide**

- Sliced with THIS system's profile, values as you want them → either mode
  works; AS SLICED is the honest 1:1 run.
- Foreign file, old profile, or you want your material preset / feature
  speeds / first-layer brake to apply → **AS LEGACY** (recommended default).
- Range and label files: the header comment in the file says it —
  AS LEGACY = your settings, AS SLICED = the source temperatures 1:1.

With `start_confirm` OFF, PRINT_START runs immediately as LEGACY takeover. The
dialog title shows the file type at a glance: `Start? MARKED` / `Start? LEGACY`.

### 3.6 While it prints

Everything is adjustable while the job runs — speed, flow, PA, accel, per-
feature speeds, temperatures, Z offset (babystepping), plus pauses, object
skips and the planned end. Chapter 6 is the complete reference; the short
version:

- **Live Tuning > Spd per feat** — global % and the CURRENT feature's % (the
  display names the feature that is printing right now); the four quick lists
  Spd/Acc/PA/Flw per feat carry the globals and the active feature at the top
- **Live Tuning > Extrusion** — flow, PA, retraction — every input shows what
  Klipper really runs at this moment
- **Live Tuning > Pause & Control** — pause now / next layer / at layer N /
  planned end at layer N / M600 change / cancel (2×)
- **Live Tuning > Objects** — skip a single object

### 3.7 After the print

PRINT_END (or a planned end, or the end of a legacy file) runs the full
choreography: lift, park away from the part, stats on the console, fanfare,
cooldown with the part fan, heaters off. `_PRINT_CLEANUP`
resets all per-print state — the next print starts clean, with your pre-print
settings, the selected material and the loaded mesh deliberately KEPT.

If — and only if — the print was successful AND you tuned something live, the
**Rate print?** question appears at the top of the menu (§3.7a).

### 3.7a Rate print? — optimized copies

After a live-tuned print the system asks ONE question — nothing is ever
adopted silently into Pre-Print (or into a `post` profile):

| Answer | What happens |
|---|---|
| **YES — optimized copy** | the tuning STAYS and the watcher writes an **optimized copy** (below). Confirm sound, `Optimized: saved` on the display. |
| **NO — discard** | the exact **pre-print baseline** (snapshotted at the print start, memory only) is restored — every override, feature switch, clamp and material — the tuning is gone without a trace. |
| **no auto-timeout** | the question STAYS in the menu until you answer. Only picking a new file (or starting a new print) answers it with NO — nothing is ever adopted automatically. |

The **optimized copy** lands in `gcodes/optimized/` with **numbered copies**:
the first save writes `name.gcode`, every further save of the same
file becomes `name_O2.gcode`, `name_O3`, … — your tuning history is never
silently overwritten. The original file is only ever **read**
(byte-identical, provable by md5/diff).
The copy carries your print's tuning:

- Values the file can display are **baked in as absolutes**: flow and speed
  percents (flow, per-feature speed, global M220 speed) are scaled into the
  file's own values, PA / accel / first-layer speed / fan limits are written
  directly. Pre-Print > File info shows the OPTIMIZED row instead of raw
  slicer values.
- Percent values are **neutralized in the replay** — reprinting the copy can
  never apply them a second time. Absolute values stay in the replay too
  (applying them twice is a no-op).
- Everything without a display key (temps, retraction, per-feature flow/PA)
  rides in the `_OPT_BAKED` replay line — the copy prints with exactly the
  values the successful print ended with, even from a cold start.
- The header notes source file + date (`; R2-OPT`) and what was baked.
- Re-optimizing the same source writes a NEW numbered copy (name.gcode,
  then name_O2, name_O3 …) — your tuning history stays, nothing is
  overwritten.

**Printing a copy:** the stock LCD file list shows the gcodes root ONLY
(Klipper never lists subfolders there) - the post-processor therefore mirrors
every printable subfolder file as a **link in the root** (ch. 14, SD Card), so the copy
is in the stock list AND stays in its folder. The top-level **Optimized** menu
remains the second way in: **40 live slots** (two pages — the list refreshes while the
menu is open, empty slots show a dot), pick one, **START** (the start dialog
asks as always) or **Values > Pre-Print** — the same 40 slots also sit in
Pre-Print > Profiles > From optimized. Mainsail/Fluidd show the folder
natively. Selecting a copy marks it OPTIMIZED everywhere.

**Taking values without printing:** Pre-Print > Profiles > **From optimized**
(see §3.4a) — the second chance **Save last print > optimized** sits in the
same menu.

### 3.8 Foreign G-code — other slicers, other firmware, other hardware

Files not sliced by you, not sliced for Klipper, or sliced for a DIFFERENT
extruder: here is the complete map of what differs, what the system handles
by itself, and where you click once.

**A) Other slicers — detected, normalized, zero clicks**

The watcher recognizes 12 slicer families by their header signature (OrcaSlicer,
PrusaSlicer, SuperSlicer, Bambu Studio, Cura, Elegoo Slicer, Kiri:Moto,
AstroPrint, SliceBeam, ideaMaker, Simplify3D, FlashPrint) and normalizes
their dialects:

| What differs between slicers | What the system does |
|---|---|
| layer comments: `;LAYER_CHANGE` (Orca/Prusa) · `;LAYER:n` · `;CHANGE_LAYER` (older/other) | all recognized — a `LAYER_MARK` is inserted for each; files with NO layer comments get a Z-scan instead (and say so in the console) |
| feature names: Orca `;TYPE:Outer wall` · Cura `;TYPE:WALL-OUTER` · `;TYPE:Support/Base` … | everything is mapped to the system's 16 internal feature codes — overrides work on ANY slicer's file (full census table below) |
| config headers `; line_width = 0.62` … | the relevant keys are read into `_FILE_INFO` (line widths, flow ratio, PA, speeds) — the Pre-Print preview shows the file's REAL values |
| `EXCLUDE_OBJECT_DEFINE` blocks | only present when the slicer was told to label objects (Orca: "Label objects") — with them: adaptive mesh + live skip; without: honest full-bed mesh message |

**A.1) The feature census — all 16 features in every slicer family** **

Every modern slicer writes `;TYPE:` comments into the G-code. The
post-processor maps each spelling (lowercase, dashes/spaces equal) to one
internal code, measures the speeds/accels per feature and injects an
`APPLY_TYPE` marker after every `;TYPE:` — that is what makes features live
tunable. Values with NO own marker (e.g. small perimeters) come from the
config header (`; key = value` lines) into the file info instead.

| System feature (menu) | OrcaSlicer / Bambu Studio | PrusaSlicer / SuperSlicer | Ultimaker Cura | How it reaches the system |
|---|---|---|---|---|
| OW Outer wall | `Outer wall` | `External perimeter` | `WALL-OUTER` | `;TYPE:` marker |
| IW Inner wall | `Inner wall` | `Perimeter` (`Thin wall` → here) | `WALL-INNER` | `;TYPE:` marker |
| OH Overhang wall | `Overhang perimeter` | `Overhang perimeter` | — (stays in WALL-OUTER) | `;TYPE:` marker |
| SP Sparse infill | `Sparse infill` | `Internal infill` | `FILL` | `;TYPE:` marker |
| SO Solid infill | `Internal solid infill` | `Solid infill` | — (in FILL/SKIN) | `;TYPE:` marker |
| TP Top surface | `Top surface`, `Top solid infill` | `Top solid infill` | `SKIN` | `;TYPE:` marker |
| BT Bottom surface | `Bottom surface`, `Bottom solid infill` | `Bottom solid infill` | `SKIN` (bottom) | `;TYPE:` marker |
| BR Bridge | `Bridge` | `Bridge infill` | `BRIDGE` | `;TYPE:` marker |
| IB Internal bridge | `Internal bridge` | `Internal bridge infill` | — | `;TYPE:` marker |
| GP Gap fill | `Gap fill`, `Gap infill` | `Gap fill` | — | `;TYPE:` marker |
| SU Support | `Support`, `Support interface`, `Support transition` | `Support material` (+ interface) | `SUPPORT`, `SUPPORT-INTERFACE` | `;TYPE:` marker |
| IR Ironing | `Ironing` | `Ironing` | — | `;TYPE:` marker |
| SK Skirt | `Skirt`, `Ooze shield` | `Skirt` | `SKIRT` | `;TYPE:` marker |
| BM Brim | `Brim` | `Brim` | `BRIM` | `;TYPE:` marker |
| PT Prime tower | `Prime tower` | `Wipe tower` | `PRIME-TOWER` | `;TYPE:` marker — and the R2 generators (labels/litho/colorpic) tag their own prime tower as PRIME-TOWER since .135 |
| CU Custom code | `custom` (custom G-code sections) | `custom` | — | `;TYPE:` marker — unknown blocks arrive NUMBERED as C1..C9 (.136l, one slot per distinct shape) |

**Speed-only — visible in the file info, not live-tunable:**

| Value | Slicer setting | Note |
|---|---|---|
| Small perimeters | `small_perimeter_speed` / `small_perimeter_acceleration` (Orca/Prusa; Orca default 50 % of the wall speed) | a pure SPEED setting — the slicer decides per loop which wall counts as 'small', there is no own `;TYPE:` marker. Speeds/Accels in the file info show Speed (small)/Accel (small) so you can see why short loops run slower. |

**Mapping decisions for types without an own menu entry** (documented in
`r2_postproc.py` `TYPE_MAP`): `Thin wall` → IW, `Skin` → TP (bottom-skin →
BT), `Raft` → BT, `Support interface`/`transition` → SU, `Ooze shield` → SK,
plain `Infill` → SP. **.136n (stage 7):** every INFILL variant a slicer can
name maps to SP — the 3D families (`Gyroid`, `3D-Lattice`, `Lightning`,
`Cross-Cubic`, `Honeycomb`) and the classic patterns (`Tri-Hexagon`,
`Zig-Zag`, `Rectilinear`, `Concentric`, `Octagram spiral`, `Hilbert curve`,
`Wiggle`…) — a `solid`/`top`/`bottom` token still wins over the pattern
name, and support grids stay SU.

**The mystery low-accel feature from the field log** — a feature switch with
low acceleration values that no menu owned: those were **custom G-code
sections** (per-object start/end, filament-change, layer-change G-code with
their own `M204`). They now arrive as **CU Custom code** and are editable
like any other feature — including an accel limit that keeps their own M204
in check. Since .136l the same holds for every UNRECOGNIZED block: it gets
a numbered C-slot instead of a guessed feature, so its hidden extruder
values (speed, accel) are separately controllable — and a value-less block
is simply not offered.

**A.2) The geometry classifier — feature control for files WITHOUT `;TYPE:` tags** **

ideaMaker, old Simplify3D profiles or hand-written G-code carry no `;TYPE:`
comments at all — no feature marker, no live tuning. For those files (and
ONLY those) the post-processor now **derives the features from the geometry
itself**: closed loops with nesting → outer/inner walls, parallel straight
lines with regular spacing → sparse or solid infill (spacing ≥ 3 mm = sparse),
solid fill on layer 1 → bottom surface, solid fill on the last layer → top
surface. Z-changes on travel moves count too (modal-Z: Z-hops never fake a
layer change).

**The system stays honest about it:** the file info says `DERIVED=1 CONF=0.7
COVER=…%` — *detected, not assumed*. Curved open paths stay UNCLASSIFIED
(they simply print 1:1), bridges are never guessed (needs the layer below —
documented limit), and a file WITH tags is never classified: the first
`;TYPE:` wins, tagged data always beats the guess. Derived features carry
the fixed confidence 0.7 and the console line explains it in plain words.

**.136n — stage 7 of the classifier: 3D infill + the layers check each
other.** Two rules were refined:

- **An open CURVED path bathed in material on both sides is 3D infill**
  (gyroid, cubic, cross, lightning) → SP, not a wall. The far probe
  (8 mm) sees the 2–6 mm line spacing of the 3D families that the
  0.7/1.2 mm wall probe misses. A curved path with a genuinely FREE
  side stays a wall (OW), and a path that turns monotonically like a
  loop arc (the sandwiched 270° arc) stays IW — a wave (S-curves, net
  turning ≈ 0) is infill, an arc is a wall.
- **Solid infill now needs its neighbors' vote (multi pass, the
  elimination principle):** pass 1 tags dense hatch SOLID as before;
  pass 2 — one layer later — lays the candidate's region over the
  picture of the layer ABOVE: **no ink up there (not even a wall ring)
  = it was the top skin** (TP); ink = internal solid (SP-SOLID) or one
  more layer of a stacked top shell — only the **uppermost** of a
  2–3 layer top shell becomes the top surface. The final pass (end of
  file) flips everything still pending: nothing ever follows the last
  layer. A thin wall ring above (the support-gap class) counts as
  "the model goes on" — that skin stays SOLID, exactly the R214 field
  rule.

**B) Files sliced for Marlin (other firmware) — two real differences**

Klipper-flavored files and Marlin-flavored files share nearly all commands,
but two Marlin habits break on Klipper. Both are detected, flagged loudly,
and fixed in place:

| Marlin habit | Symptom on Klipper | The fix |
|---|---|---|
| **Volumetric E** (`;FLAVOR:Marlin (Volumetric)`, common from Cura profiles with volumetric mode on) | E counts mm³ instead of mm → the print starves, barely extrudes at all | **Pre-Print > File info > `Vol->mm fix`**: every E value (G0/G1 and G92) is divided by the filament cross-section (1.75 mm → 2.405 mm²), the volumetric markers are neutralized, a note lands in the header. Idempotent — never converts twice. |
| **Long retraction moves** (E-only retract/unretract pairs, typical 5–6 mm from Bowden-era profiles) | they work, but they OVERRIDE your tuned ~0.8 mm direct-drive retraction and cannot be live-tuned | **Pre-Print > File info > `RetFix file`** **(or Pre-Print > File info > RetFix ON for every FUTURE upload)**: clean pairs become `G10/G11` firmware retraction — your current retraction applies and stays live-tunable. Wipes and folded retracts stay untouched. |

The file info line **"sliced by <slicer> for <firmware>"** (Pre-Print > File info)
tells you upfront what you are holding — fresh uploads and foreign downloads
alike. Marlin files WITHOUT volumetric markers and without extreme retracts
just run: the LEGACY start flow (dialog, mesh, purge, L1/L2) takes over.

**C) Files from other hardware (Bowden profile → your direct extruder)**

An old file from your Bowden days (or a friend's Bowden machine) contains
retraction distances tuned for a 400 mm filament path. Your direct extruder
wants ~0.8 mm. `RetFix file` rewrites exactly those pairs to G10/G11 — the
DISTANCE then comes from your saved retraction setting (Pre-Print > Velocity,
live-tunable during the print via Live Tuning > Extrusion). Nothing else in
the file changes; the R2 markers survive, so no re-processing happens.

The reverse (direct-drive file on a Bowden machine) is simply the same
setting tuned the other way — no file fix needed, just your retraction
values.

**D) Two more file fixes — hotend protection & travel accel** **

The file info shows the **maximum volumetric flow** the file really uses
(`MAXRATE`, mm³/s — measured from F × E-per-mm, travels excluded). A hotend
does ~8–15 mm³/s; a file that asks for 25 silently skips and under-extrudes
on small nozzles.

| Fix | What it does | You click… |
|---|---|---|
| **Flow cap** | every extruding move over the cap gets its F lowered so the volumetric rate stays under it (travels and retracts untouched; marker `; R2-FLOWCAP:` in the header, idempotent — a higher cap later simply re-fixes) | Pre-Print > File info > `Cap:` (value) + `Fix flow cap` |
| **Travel accel** | travel blocks get their own `M204 S…` (saved/restored around each travel run, the file's print accels stay) — separate travel tuning WITHOUT touching your global accel | Pre-Print > File info > `TAcc:` (value) + `Fix travel accel` |

Both run through the same background watcher as RetFix/Vol — the console
confirms, the LCD shows "working", the file is fixed in place (no re-upload).

**Fix feedback protocol:** a fix press plays the **start tune** and leaves the
menu on its own (you are back where you decide); the display shows the
progress, the fix runs **sequentially** with every other background job — and
a print start **waits** for it ("Wait: generating" on the LCD) instead of
racing the rewriter. The success tune plays when the file is done.

**The retract verdict — one line, no guessing:** Pre-Print > File info shows
`Ret:` with exactly one of four verdicts for the selected file:

| Ret: | Meaning | Your move |
|---|---|---|
| `FIX!` | explicit slicer retracts up to X mm (Bowden era) — they OVERRIDE your tuned direct-drive retraction and cannot be live-tuned | `RetFix file` (one click) |
| `can X.Xmm` | explicit slicer retracts, moderate length | `RetFix file` only if you WANT firmware retraction to rule them live |
| `fixed` | already rewritten to G10/G11 — your retraction rules | nothing |
| `fw` | the slicer itself uses G10/G11 | nothing |

Old v4-tagged files show `--` until retagged (see below) — the verdict line
also explains itself in the console when clicked.

**Decision table — what happens when**

| You have… | The system… | You click… |
|---|---|---|
| a normal Klipper file from any of the 13 slicers | tags it, previews it, offers the start dialog | PRINT |
| a file with NO `;TYPE:` tags at all | geometry classifier derives walls/infill/surfaces (marked DERIVED, 0.7 confidence) — live tuning works on it | PRINT |
| a file asking more flow than your hotend does | file info shows MAXRATE + a hint | `Fix flow cap` with a sane cap |
| a v4-tagged file (tagged before .86) | fully functional — but the info line predates MAXRATE/SEAM/CFG replay/retract verdict (file check lists it as STALE) | System > File check > `RETAG` (2×) — 20 files per run, `.r2bak` backup each, never during a print |
| a Marlin-flavor file, no volumetric, normal retracts | same — LEGACY flow (mesh, purge, L1/L2) | AS LEGACY |
| a Marlin-volumetric file | flags it loudly (file info + alarm at start) | `Vol->mm fix`, then PRINT |
| an old Bowden-era file | tags it; long retracts stay as-is until you say so | `RetFix file` (or Pre-Print > Fixes > RetFix ON for all future uploads) |
| a file calling its own `START_PRINT` | real legacy start: homing, heat, purge — then your rules | decision in the dialog |
| pure movement data (no heaters, no macros) | net probe catches it: home + heat + purge first | nothing — it just works |


### 3.9 Slicing for this system — the settings that unlock everything

Why does G-code written for other firmware or machines print here at all?
Because the system does not trust the file — it READS it: the post-processor
normalizes 12 slicer families' dialects into one language (layer comments →
`LAYER_MARK`, feature names → the 16 internal codes, header → file info), the
interceptors translate Marlin habits on the fly (M104/M106/M140/M109/M204/
M220/SET_RETRACTION/SET_PRESSURE_ADVANCE are OUR macros), and PRINT_START/
PRINT_END wrap every file in the same choreography. What the system cannot
translate it DETECTS and offers a fix for (volumetric E, Bowden-era retracts).

**What you get when you slice the RIGHT way — the full package:**

| Requirement | What it unlocks |
|---|---|
| `;TYPE:` feature comments (default in every modern slicer) | the 16 feature overrides + Live Tuning showing the feature printing RIGHT NOW + measured per-feature originals in the file info |
| layer comments (`;LAYER_CHANGE` / `;LAYER:` / `;CHANGE_LAYER`) | layer counting, L1/L2 temp system, fan-from-layer-2, pause-at-layer, Stop@, the Range generator |
| Klipper flavor, absolute or relative E (both fine) | clean values everywhere; Marlin-volumetric works but needs the Vol->mm fix first |
| start gcode calls `PRINT_START` with the file's values (templates below) | the full start choreography: dialog, mesh, purge, first-layer rules |
| end gcode calls `PRINT_END` | park, stats, fanfare, cooldown — never a parked hot nozzle |
| "label objects" / per-object G-code enabled | KAMP adaptive mesh, object skip (2× confirm), smart park |
| no M220/M221 spam from custom scripts | the clean-global system (Live Tuning > Velocity keeps the global honest) |

**Start/end g-code that fills everything in** (Orca / Prusa / SuperSlicer /
Bambu / Elegoo — same placeholders):

```text
PRINT_START MATERIAL=[filament_type] BED=[first_layer_bed_temperature]
HOTEND_FIRST=[first_layer_temperature] HOTEND_AFTER=[temperature]
LAYER_HEIGHT=[layer_height] TOTAL_LAYERS=[num_layers]
OUTER_WALL_SPEED=[outer_wall_speed] SUPPORT_SPEED=[support_speed]
IRONING_SPEED=[ironing_speed]
PRINT_END
```

Cura (same idea, Cura placeholders): `PRINT_START MATERIAL={material_type}
BED={material_bed_temperature_layer_0} HOTEND_FIRST={material_print_temperature_layer_0}
HOTEND_AFTER={material_print_temperature} LAYER_HEIGHT={layer_height}` …
`PRINT_END`. Kiri:Moto, AstroPrint, SliceBeam, ideaMaker, Simplify3D, FlashPrint:
put the same PRINT_START/PRINT_END calls in their start/end g-code boxes with
their own placeholder names — the step-by-step for Orca and Cura lives in
`slicer/ORCA.md` and `slicer/CURA.md`.

**The per-slicer checklist (all 12 families)**

| Slicer | Flavor | Watch out for |
|---|---|---|
| OrcaSlicer | Klipper | the reference — works out of the box; enable "label objects" |
| PrusaSlicer / SuperSlicer | Klipper | same as Orca (config at the file tail is parsed too) |
| Bambu Studio | Klipper | export WITHOUT the Bambu-specific header macros; keep "type" comments on |
| Elegoo Slicer | Klipper | Orca fork — behaves like Orca |
| Cura | Klipper or Marlin | use the CURA.md start gcode; if the file says "Marlin (Volumetric)", run the Vol->mm fix once |
| Kiri:Moto | Klipper | layer comments are on by default; check that `;TYPE:` lines exist |
| AstroPrint | — | start/end gcode boxes: PRINT_START/PRINT_END manually |
| SliceBeam | Klipper | Orca-relative; verify feature comments in the preview |
| ideaMaker | Marlin default | set G-code flavor to Klipper; older profiles bake in long retracts → RetFix file |
| Simplify3D | Marlin default | set flavor Klipper; add PRINT_END (its default end script is minimal) |
| FlashPrint | Marlin | slicer is detected as FlashForge/FlashPrint; expect LEGACY start flow |

**Limits — what NO translation can fix (honest list)**

- The machine is still this machine: a file sliced for a bigger bed, a Delta,
  or 15 mm/s² accelerations will run — but clamped to YOUR limits (that is a
  safety feature, not a bug).
- M-codes the firmware does not know stop the print (Klipper errors on
  unknown commands) — slicer scripts with exotic Marlin tool changes are the
  usual suspect; move that logic to macros.
- Filament-runout logic of other firmwares (M600 variants) is replaced by the
  system's own filament handling.
- Arcs (G2/G3) are supported; nothing to do.
- AS SLICED means 1:1: overrides OFF, first-layer rules shape layer 1 (per your
  switch), Live Tuning still works (live commands are not overrides). From
  layer 2 the file's own temperatures stand — your armed L2 override wins.

## 4. Scenario library — every file type walked through

Real situations, start to finish. Each scenario lists the clicks and what the
system does in the background.

**Scenario A — correctly sliced, print by layer (the normal case)**
Slice with the R2 profile (the post-processing script is optional — the service
tags the file anyway). Upload → select → start dialog → **AS LEGACY**.
Homing, bed temp, adaptive mesh, nozzle wipe, purge, then layer 1 with L1
temps, fan off and the first-layer brake; at layer 2: L2 temps (your override
if armed, else the file's value, else the material preset — .121), the file's
fan value, 100 % speed. Feature overrides (speed/accel per feature) work
because the file carries `APPLY_TYPE` markers.
*LCD:* Start Print? > AS LEGACY. *Console:* `PRINT_AS_LEGACY`.

**Scenario B — correctly sliced, print by object (sequential)**
Same start as A. At every object change (Z falling edge) the system pauses
briefly, sets L1 temps + L1 speed, waits only if a heater must actually move,
then continues; the next object's layer 2 switches back to L2. The layer
counter re-anchors at every object start — per-object layer rules stay exact.

**Scenario C — legacy file, print by layer (old profile, foreign download)**
The watcher detects the file without markers → pause + start dialog titled
`Start? LEGACY`. **AS LEGACY** = system takeover: homing → bed temp → mesh
("Old files" ON) → hotend to L1 temp → purge → L1 speed → gapless continue
(the pause position is restored after the purge — no park/return dance). The
Z tracker counts layers — layer 2 brings L2 temps + fan + 100 % (same ladder:
your override > file value > material preset — works in both start
modes). File M104/M220 are redirected layer-strictly. **AS SLICED** = the file
rules 1:1 — its own start gcode runs, nothing is injected (live tuning stays
available; your armed L2 override still wins from layer 2).

**Scenario D — legacy file, print by object**
C plus the sequential falling edge per object (choose AS LEGACY — AS SLICED
never injects object handling).

**Scenario E — sliced file, but started AS LEGACY**
System takeover on a correctly sliced file: overrides ON, Z counting, feature
markers still fire. Useful to print a well-sliced file with your current
material preset.

**Scenario F — same file, different material (no re-slicing)**
You have a PLA-sliced file and want it in PETG:
1. Pre-Print > Material > LOAD NOW the PETG preset (or edit the values — the
   active material edits apply live).
2. Check Temperatures: your L1/L2 temps are ON, the file's temps lose.
3. Start AS LEGACY. Temps, fan curve, PA, retraction and flow come from the
   preset; the geometry stays the file's.
Only the material-related parameters are taken over — speeds and accelerations
stay the file's unless you override them in Features.

**Scenario G — printing a RANGE (partial print)**
A 6-hour vase broke at layer 200 of 626? Make the section a real part:
1. Select the SOURCE file (its layer count appears in the menu).
2. Pre-Print > Range/Stop: From 125, To 225, Floor 5, Brim 4 (example).
3. > Create — a few seconds later `Vase_L125-225.gcode` exists AND selects
   itself (the source file's selection is replaced, nothing is deleted).
4. Start dialog → **AS LEGACY** → the excerpt prints on a generated raft with
   a brim, ends with a proper PRINT_END (park, stats, fanfare).
Details and all parameters: ch. 5.1.

**Scenario H — printing LABELS (name tags without a slicer)**
1. Tools > Labels > Text: pick line 1–3, position, rotate to the character, click —
   the text assembles live on the display.
2. Tools > Labels > Settings: size (default 50×15), font (SMOOTH / MONO / COND /
   NARROW / CAPS), hole side + diameter, stroke = letter line width.
3. Job > Add label — repeat for several DIFFERENT labels (queue shows n/24).
4. Job > Create (press 2× — arm, then start) — the watcher builds
   `Vnn_<text>.gcode` and beeps.
5. Start it like any file. Two colors: print pauses with M600 after all base
   plates — load color 2, RESUME purges into the purge tower, the text goes
   on top. Every label is an exclude object (skip single labels live).
Details: ch. 5.2.

**Scenario I — plotting an image (pen instead of nozzle)**
1. Mount a pen (Tools > Plotter > Pen offset X/Y/Z tells the system where it sits).
2. Upload `bild.png` (or .jpg/.svg/.pdf/.txt) — plain, **no `.gcode` tail**
   anymore. Select it in the file list → the watcher generates
   `V01_Plot_bild.gcode` on demand (settings: Tools > Plotter;
   auto-contrast finds the ink on any paper tint, dark boards invert
   automatically; Maintenance > gen-out decides selected-for-start vs
   preview only).
3. Start dialog for the generated file (a plot file: AS SLICED = pure pen
   run, AS LEGACY heats only if the extruder is ON).
4. Multi-color plots pause (M0) at every pen change — swap pens, RESUME.
5. Live Tuning > Plotter while plotting: pen speed %, pen Z ±0.05, X/Y shifts.
Details: ch. 5.3.

**Scenario J — re-printing a section to test the critical middle**
Same as G, but with Floor 0 / Top 2 / no brim: the section prints directly on
the bed with a solid cap on top — the fastest way to test overhangs or
clearances in the middle of a long part without printing the whole thing.

**Filament change mid-print (M600)**
Live Tuning > Pause & Control > Change (M600) → parks hot, unloads, waits with
sound → load until the sensor clicks → RESUME purges (PURGE_MORE for
15 mm more) → continues.

**Typical console session (Mainsail)**

```
SET_MATERIAL MATERIAL=PETG                      # load preset
SET_OVERRIDE_VALUE NAME=hotend_first VALUE=235  # + ON automatically
TOGGLE_OVERRIDE NAME=hotend_first               # ... or off again
SHOW_STATUS                                    # mode + file type + file parameters
SET_LIVE_MINIMUM_CRUISE_RATIO VALUE=0.5         # confirms: [OK] ... -> Klipper
# during the print (every mode):
SET_GLOBAL_SPEED PERCENT=80
SET_LIVE_RETRACTION LENGTH=1.0                  # one parameter, others stay
PAUSE_AT_LAYER LAYER=17
CANCEL_PRINT                                    # twice within 60 s
```

## 5. The generators: Range, Labels, Plotter, Cable ties, Angles, Lithophanes (+ Spray stencils), ColorPic, Gaskets, Frames, Bricks, Kits & Figures, String Art, Geometry, Scale/Taper, Twist, Mirror, OBJ export, Toolchain (preset chains)

Thirteen generators turn the printer into a manufacturing tool of its own:
partial prints from any G-code, label plates from typed text, pen plots from
images, cable ties, angle plates / flat connectors, lithophanes and color
pictures from photos, sealing gaskets, picture frames / display cases,
building bricks with the exact system geometry, brick KITS from any sliced
file and assemble-it-yourself figures. All of them write
normal G-code files into the gcodes folder (the watcher builds them in the
background — niced, single-pass, a few seconds), all of them run through the
NORMAL start flow, and all generated objects are exclude-objects (skippable
live).

**The job queue (.136u):** heavy builds (string art, lithophanes, color
pictures) run one at a time in the background. If the printer is busy or the
host runs low on RAM, a job *parks* — the console says so every 2 minutes,
and it starts on its own the moment the machine idles. A job that wedges is
dropped and reported after 20 minutes. **System > Gen jobs** shows the live
state (BUILDING / idle) and has **Clear queue** (double-press) to drop every
pending job at once — settings are never touched. If the display ever says
"Wait: generating" on a print start after a crash: clear the queue, then
restart the *Pi* (a firmware restart frees no RAM).

**Mainsail metadata (.136k):** every file the system generates or derives
carries an `R2-META v1` block right behind the stamp — a 128×128 PNG
**thumbnail** (rendered from the file's own moves), the **estimated
printing time** and the **filament used**, so the Mainsail file browser
shows generated files exactly like sliced ones. Range excerpts copy the
**source's** thumbnail (a slicer original keeps its own picture) and
compute their own honest time from their own moves. Slicer uploads are
never touched: the hook is eligibility-guarded (R2-GEN stamp, generator
folders, `optimized/` only) and files that already carry a slicer
thumbnail stay hands-off.

One quality rule applies to every one of them (field-log rule): **the nozzle
never travels over an open hole or slot without retracting — no matter how
short the hop.** Every opening is a registered keep-out: label and screw
holes, the cable-tie head channel and the loop slot, the gasket groove, the
backplate keyhole and stud holes, the frame view opening and the
bridge-test spans. FLAT gaskets and lithophanes have no openings at all —
one continuous bead per layer, nothing to cross.

### 5.0b Generated files: names, versions, select + delete

**Names & versions.** Every generated file is named
`V<number>_<name>.gcode` — the running number LEADS, free of a `00_`
prefix — three more name characters fit the 15-character
display: `V07_R2-D2.gcode`, `V03_Bridge_150mm_40pct.gcode`,
`V01_Figure_s100_SINGLE.gcode`. Why: the LCD shows only the first ~15
characters of a file name — with the number at the end a
regeneration looks exactly like its predecessor and frame plates A/B are
indistinguishable. The leading number alone tells any two files apart,
and the number is ONE folder-wide counter: it never repeats inside a folder,
regenerating never overwrites an older file (a deleted highest number gets
reused), and it continues above every legacy file that still
sits in the same folder. The counter is two digits: from the 100th version
(V99) the generator refuses with a cleanup hint instead of overwriting. Both LCD browsers additionally hide the `.gcode`
tail — 6 more characters of real name per line.

**Output folders.** Every generator writes into its OWN subfolder of
the gcodes directory — `Labels/`, `CableTies/`, `Angles/`, `Gaskets/`,
`Frames/`, `Litho/`, `ColorPic/`, `Bricks/`, `Kit/`, `Figures/`, `Plot/`,
`Range/`, `Texture/`, `Towers/` (calibration/test prints) — and since
.136n: `Shapes/`, `Scale/`, `Twist/`, `STL/` (geometry generator, the
scale/taper tool, the twist tool, the OBJ export). The root stays
clean for your sliced files and sources. The LCD file browser and Mainsail
navigate the folders natively; the Gen files list shows the file name and
selects/deletes via the relative path. **Sort order:** the ROOT lists
folders first, then files A–Z — inside a SUBFOLDER the NEWEST file sits on
top (modification time, newest first), folders below it. Long folders page
through 40 entries per page. Nothing moves on the update: existing
outputs stay in the root and keep working — numbering is folder-local
(each folder counts its own `Vnn_` files plus the legacy
`00_Name_Vnn` files inside it and takes the next free number).

**Tools > Gen files.** Every generator output — the 24 newest —
right on the display: press a slot to SELECT that file (the start dialog catches it —
nothing prints unasked), or open **Delete file** and press a slot TWICE
(first press arms, second deletes). Only generated files (`Vnn_`/`00_`
names) can ever be deleted this way — your own sliced files are untouchable.

### 5.0 After generating: QUEUE or PREVIEW only

Every generator (range, labels, plotter, cable ties, angles, lithophane,
colorpic, gasket, frame, bricks, brick kit, figures, texture, bridging test,
resonance plots) finishes by asking
one question: what should happen with the new file? **Tools > After gen**
sets the sticky answer — and every generator takes a per-run `OUT=` to
override it once:

| Mode | What happens |
|---|---|
| **QUEUE** (default) | the new file lands in the print queue: it is selected for printing right away — the LCD start selection jumps to it, you press Print and the start dialog opens. If the generator worked ON a selected file (range excerpt, texture), the new file REPLACES the selection |
| **PREVIEW** | the file is only written and selected for the 3-D preview on the Pi (Mainsail/Fluidd) — nothing is queued, the current selection stays untouched |

Console/Mainsail: `_GEN_OUT_SET OUT=QUEUE` (or `OUT=PREVIEW`,
`OUT=SELECT`, `OUT=1/0`), per run e.g. `GEN_CABLE_TIES COUNT=8 OUT=PREVIEW`.
The setting survives a reboot (default QUEUE — the pre-.84 behavior).

**My presets — every generator.** Texture, lithophane, labels,
frames and plotter each carry a **My presets** submenu: Save stores ALL of
that generator's settings under a name of your choice (PHOTO-180, fuzzy, A45 …), Load/Delete work per slot, 8 slots per page with Page</>, the
list itself is unlimited — and the presets survive reboots. The frame's
old numbered slots remain loadable as they were. **.136l:** saving a
TEXTURE preset numbers the name — `grid01`, `grid02`, `wave01` …
(texture name + running two-digit number, so the list shows at a glance
how many variants exist and nothing is ever overwritten); the other
generators keep the classic scheme (name, name_2, name_3 …).

### 5.1 Range — print a section of an existing file

Perfect for re-printing a broken section, testing the critical middle of a
long print, or making a part from just a few layers. Find it in
**Pre-Print > Range/Stop** (the planned stop-at-layer lives in the same menu;
Live Tuning > Pause & Control has the Stop@ shortcut).

**Operation**

1. Select the source file — the menu caps From/To to the file's REAL layer
   count (shown as `File: 123 L`).
2. Set **From** / **To** (From clamps to ≥ 2, To to the file's total).
3. Optional: **Floor**, **Top**, **Brim** and their shapes/fills.
4. > **Create** — a beep confirms; the watcher builds
   `<name>_L<from>-<to>.gcode` and the file AUTO-SELECTS itself (the source
   file's selection is replaced — nothing is deleted).
5. Start dialog → AS LEGACY (recommended: mesh + purge + your pre-print
   settings) or AS SLICED (source temperatures 1:1).

**What the excerpt contains**

- layer FROM prints as the FIRST layer at Z 0.2 ON THE BED (always 0.2,
  whatever the source layer height is — global Z shift, original spacing kept)
- a `PRINT_START` header with the source temperatures → the NORMAL start flow
  (dialog, mesh, purge, first-layer rules: fan off, L1 temps, speed brake)
- its own `_FILE_INFO` at the TOP — Live Tuning > File (G-code) shows the excerpt's values
  from layer 1
- the source fan returns from layer 2 — layer 1 prints without fan (a Fan
  LIVE override beats the layer-1 rule — chain in ch. 14)
- a real `PRINT_END` at the end: park, stats, fanfare, cooldown — the nozzle
  never stays parked ON the finished print
- the source file's `EXCLUDE_OBJECT_DEFINE` blocks are carried over

**Floor — the glue base under the section (0–10 layers)**

The section usually has no floor of its own; Floor prints a generated raft
under it so it sticks to the bed — the raft edge sits flush with the model
walls (zero gap, it welds directly to the section).

| Parameter | Values | What it looks like |
|---|---|---|
| F.Shape | **FOOTPRINT** | the convex hull of the layer — concavities are bridged over, a compact solid base |
| | **OUTLINE** | the TRUE outline of the layer — concavities and holes stay open, the raft follows the model wall exactly |
| F.Fill | **GRID** | hatch lattice at 45°/135° alternating — the classic look, prints fast |
| | **SOLID** | dense lines that overlap into a solid surface |

**Top — the solid cap over the last layer (0–10 layers)**

Same two switches (T.Shape FOOTPRINT/OUTLINE, T.Fill GRID/SOLID — Top defaults
to SOLID). Prints over the last range layer at the original layer spacing.

**Floor hole — a centered hole in the base (Fl.hole, 0–80 mm)**

For cable feeds — or a lamp: a centered hole with a THICK boss ring around
it, printed as ONE continuous spiral from the hole edge outwards — one bead
of plastic per revolution, no seams, no travel breaks, no strings over the
void (travels that cross the open hole retract first). The hatch stops at the
ring's outer edge. The diameter auto-clamps to the section's REAL outline
(footprint hull or true outline, whichever the floor fills) + a 2 mm margin —
on L-shaped, round or oval sections the boss NEVER sticks out into air; if the
center leaves no room at all the hole is skipped with a console note (every
change is reported).

| Preset | Diameter | Fits |
|---|---|---|
| cable feed | 3–12 mm | zip ties, sensor cables, mains cable with gland |
| **E14** | 15.0 mm | E14 thread passes through (14 mm + tolerance) |
| **E27** | 28.0 mm | E27 thread passes through (27 mm + tolerance) |
| socket body | measure + 0.3 | if the whole lampholder BODY must pass: typical E14 body ~24 mm, E27 ~33 mm — measure YOUR socket |

Print tips: PETG for lamp parts, and for a press-fit thread start 0.2–0.3 mm
below the measured diameter — the boss gives the thread something to bite.

**Top hole — a centered hole in the cap (Top hole, 0–80 mm)**

The tricky one — a hole in a horizontal ceiling means printing over open air.
The generator does it BRIDGE-FIRST: cap layer 1 bridges over the void with an
anchor ring exactly at the hole edge — every clipped hatch line welds onto
that ring, so the edge cannot sag and the hole stays OPEN from layer 1. Layers
2+ open the hole with the same spiral boss as the floor. A top hole auto-raises
Top to 3 layers (bridge + 2 solid) — more Top layers = thicker rim.

**Brim — loops around the start (0–10)**

N loops around the outline, zero gap — the first loop's inner edge touches
the model wall. Key-ring style adhesion helper — printed on the **first
layer** (right at the start of raft layer 1, not after the raft).

**Notes**

- The generated raft counts as INFILL-SOLID, the brim as BRIM — feature
  overrides (speed/accel/flow) work on the generated geometry like on any
  sliced section.
- The excerpt OPENS with the feature that was active at the cut (a
  vase-style source states its `;TYPE:` once in layer 1 — the excerpt
  re-asserts it, so the section never prints as the raft's solid infill).
- The file info (Pre-Print > File info) describes what the EXCERPT really
  contains: features from layers outside the range show as n/a, and the
  per-feature speeds are measured from the excerpt's own layers.
- `;TYPE:` names from OrcaSlicer/Bambu (`gap fill`), PrusaSlicer
  (`External perimeter`, `top solid infill`, …) and Cura (`WALL-OUTER`) all
  map — since R95 also `Overhang perimeter`, `Internal bridge`,
  `Prime tower`/`Wipe tower` and `custom` sections to their features.
- An UNKNOWN `;TYPE:` spelling stays **CUSTOM** — but numbered (.136l /
  R213): every distinct unknown block becomes its own slot **C1, C2, …
  C9** with the usual regulators (ON, speed %, accel, flow, PA). The
  field reasoning: the old blanket classification of wall-shaped
  unknowns as outer wall could print a **bridge** far too fast — an
  unrecognized block now carries its OWN values, tuned per slot, never
  inherited. Blocks that repeat across layers (same shape, ±12 % length,
  ±1.2 mm bounding box, same speed set) share their number — a purge
  cross on 40 layers is ONE slot, not 40. Identical blocks WITHOUT any
  extrusion (pure travel/macro filler) get NO slot — nothing to tune.
  More than 9 distinct shapes stay plain CUSTOM (unnumbered, prints
  1:1). A slot only appears in the menus while the selected file
  actually carries that group (`CUSTOMGROUPS` in `_FILE_INFO`); the
  texture tool never touches tags (proven over the 13-dialect corpus):
  if a textured+ranged file shows the outer wall as CUSTOM, the SOURCE
  file's slicer uses a spelling we do not know yet — send the first
  lines of the original and it becomes a mapped feature.
- The excerpt's layer 1 = always 0.2 mm high, whatever the source layer
  height; following layers keep the source spacing.
- Every parameter is also available per console:
  `SET_LAYER_RANGE START=125 END=225 FLOOR=5 FLOOR_SHAPE=1 FLOOR_FILL=1 TOP=3 BRIM=4 FLOOR_HOLE=15 TOP_HOLE=28`
  (shape 0 = FOOTPRINT / 1 = OUTLINE, fill 0 = GRID / 1 = SOLID — the same
  numbers the Range/Stop menu shows as F.Shp/F.Fill)
- E and Z of the body are shifted so the section prints as a standalone part
  in the file's own extrusion mode (relative or absolute E — both work).
- Works with any tagged source file, including multi-object files (EXCLUDE
  handling cleans up cut artifacts at the section borders).

**Stop@ — the planned normal end**

**Stop@ N** (Pre-Print > Range/Stop, or Live Tuning > Pause & Control) ends the print
NORMALLY when layer N begins — stats, fanfare, cooldown, like a finished
print, not a cancel. The natural partner for "print only the first 50 layers".

### 5.2 Labels — the built-in label maker

**Mirror X / Mirror Y** flip the text in its own label — mirrored
text is what a **stamp** needs. **Stamp** prints a body with the snap
socket under the text (exactly ONE label per job, the label hole is off —
the socket is the mount), **Handle 1/2** adds/reprints the snap handle.
Same fit system as the litho stamp (see 5.6).

Name tags, key fobs, drawer labels, cable markers — engraved text, no slicer,
entirely from the LCD (or one console line).

**The workflow**

1. **Tools > Labels > Text**: up to **5 lines per label** — pick the line (1–5),
   pick the position (Pos 1–N), rotate to the character (Chr), click. A–Z a–z
   0–9 space ÄÖÜäöüß and the common symbols are available; the text prints
   correctly even where the 12864 display can only hint at umlauts. Only
   FILLED lines print — one line simply centers in the free area.
2. **Tools > Labels > Settings**: size, font, stroke, layers, hole … (table below).
3. **Job > Add label** — repeat Text+Add for several DIFFERENT labels (same
   text twice = two identical plates). The queue shows n/24.
4. **Job > Create (press 2×)** — the watcher generates `Vnn_<text>.gcode` (beeps
   when ready) and the file auto-selects. Start it like any file: start
   dialog, adaptive mesh over the labels, purge, your overrides. The same
   generation bumps the version (V01, V02, …) — an existing file is never
   overwritten; a deleted highest number gets reused, so experiments never
   pile up as duplicates. The uploaded original is never touched.
5. Print sequence is **by layer**: all base plates in color 1 → **M600
   pause** (park, unload — you load color 2) → RESUME purges into the purge
   tower, the text goes on top. Every label is an exclude object, the tower
   too.
6. **Layout**: the hole sits 2 mm from the edge (key rings clip through), the
   text block centers between the three free sides — several lines center as a
   block with gaps that keep the stroke width clear, safe margins to the edge
   and the hole. Max count follows from bed and label size (Fit shows it,
   e.g. `12 (5x3)`); the grid fills left→right, centered; the purge tower is
   placed automatically with 15 mm clearance, on the side your probe does
   NOT sweep (right of the grid — the probe hangs ~43 mm left of the nozzle,
   a tower corner there could catch it and shift layers).

**Settings**

| Setting | Range / values | Meaning |
|---|---|---|
| W × H | label size, default **50×15** | the plate in mm — keychain tags up to near-bed signs (220×220) |
| Font | **SMOOTH · MONO · COND · NARROW · CAPS · SCRIPT · HAND · PLATE · PIXEL** (nine) | see the font table below |
| Lines | 1–5 | text lines per label |
| Size | 0 = auto, or a cap height in mm | 0: the font fills the label (~94 %). An explicit cap height is a TARGET — the label GROWS so it fits |
| Spc | letter spacing in mm | extra spacing between letters |
| Stroke | 0 = auto, or mm | the letter LINE WIDTH. 0 = auto (three extrusion lines, solid letters) or your nozzle diameter (0.6 = single-line letters). Capped automatically at ⅕ of the cap height — thicker strokes would merge the letters |
| ~ | auto | the version in the file name bumps ITSELF (V01, V02, ...) - regenerating never overwrites an older file |
| Base / Text layers | e.g. 4 + 2 | plate thickness and text depth — **text_layers is the TOTAL text depth in layers (2–4, .136ac)**: 2 = the FLUSH inlay (letter contours burn into the solid layer B-1 in plate color, the fills sit level with the top layer B in text color — layer 1 prints the letters integrated into the bottom), 3/4 = flush inlay PLUS raised layers on top; print order per layer: area + contours first, then letters + border, ONE M600 total |
| LH / 1st | layer heights | base layer height / first layer |
| Ironing | ON/OFF | smooths the text surface |
| Hole | NONE/LEFT/RIGHT/TOP/BOTTOM + diameter | the key-ring hole, 2 mm from the edge |
| Brim, 2 colors, Gap | — | adhesion, two-color mode, spacing in the grid |

**Auto-fit and auto-grow:** the font is sized to use ~94 % of the label with a
5–10 % margin to the border AND the hole. If the letters would drop below
~2.8 mm caps — or an explicit size does not fit — the LABEL GROWS (width
first, then height, up to bed size) instead of erroring. The text is never
shortened; the "needs X mm" errors of old versions are gone. Between glyphs
the head retracts (discrete letters, no ooze ghost lines); the stroke never
exceeds ⅕ of the cap height (anti-merge). The console shows the final
(possibly grown) size and the effective stroke when it was capped.

**The nine fonts** (specimen page in the PDF manual)

| Font | Character | Best for |
|---|---|---|
| **SMOOTH** | proportional, handwriting-like — the all-rounder | normal labels, mixed case |
| **MONO** | even single-line strokes, technical | numbers, codes, alignment |
| **COND** | Oswald: condensed, tall x-height | SMALL text — more characters per mm at the same readability; the small-label workhorse |
| **NARROW** | Roboto Condensed: clean, narrow, neutral | small text with a technical look |
| **CAPS** | Bebas Neue: display capitals — everything prints as capitals (`Garage!` → `GARAGE!`) | key fobs, name plates |
| **SCRIPT** | Dancing Script: flowing handwriting with swashes | decorative labels, gifts, signatures |
| **HAND** | Caveat: casual marker handwriting | quick notes, informal tags |
| **PLATE** | D-DIN: clean technical plate lettering | name plates, machine labels |
| **PIXEL** | Press Start 2P: 8-bit pixel blocks | retro, gaming, model codes |

COND, NARROW and CAPS are the small-text fonts: narrow glyphs with a tall
x-height keep their readability at 2.8–3 mm caps where SMOOTH starts to blur.
**Fit preview (Tools > Labels > Settings > `Preview fit?`):** answers with the REAL
numbers the generator will print — final label size including growth, cap
height, effective stroke, ~characters per line, and for a fixed Size the
MINIMUM label size it needs (e.g. `for 12mm caps make the label >= 228x17mm`),
plus warnings (stroke capped, purge tower does not fit, plate exceeds the
bed). The LCD keeps the short form (e.g. `80x17+ 3.7`). The instant estimate
in Tools > Labels > Text is a rough guess — the exact numbers follow ~2 s later in
the console.

**Console one-liner (everything optional):**

```
GEN_LABELS TEXT="WERKSTATT~KELLER|VASE" W=60 H=30 FONT=COND SIZE=8 SPACING=1 LINES=2 HOLE=LEFT HOLE_D=5
```

(`~` = line break within a label; `|` separates several labels of one job)

**The label generator — layout, live fit, split, handles:**

- **LIVE FIT (no button anymore):** Settings shows `Now: 80x17mm Caps 3.7`
  at the very top — it updates ~2 s after EVERY text/font/size/shape/hole
  change. GROW shows the size the print will really have (grown, INCLUDING
  the hole); FIXED shows W/H with the auto-fitted cap height. The W/H input
  minimums follow live (they never block the size your text needs).
- **The 1 cm labels are real:** H goes down to **10 mm** (was locked at 15),
  W down to 12 mm. `Gap` has a **10 mm floor** in every direction — your
  rule from the field report, checked against the printer's bed.
- **NO MORE OVERLAPS (field report .128):** grown and per-job labels kept
  their shelf positions but the uniform grid overwrote them — labels
  printed on TOP of each other (a 94 mm label ended 21.6 mm inside its
  neighbor). Fixed + proven: 14 mixed jobs (one grown to 94 mm) → zero
  overlaps, ≥ 12 mm clearance everywhere.
- **OVERFLOW SPLITS (your choice):** too many/too big labels no longer
  error — the job splits into part files in reading order (`..._T1`,
  `..._T2`, every part a complete plate with its own purge tower). The job
  message names every part, and the Queue row shows `14 -> 2 files` LIVE
  while you build the queue.
- **Handle 0–3 (your choice, Labels AND Litho use the same numbering):**
  `0` none · `1` **ON THE PLATE** with the stamp — printed LAST on every
  layer (the nozzle never finishes on a label it could rip off), z-hop
  approach, 12 mm clearance, its own GRIFF exclude object, own brim,
  bridged bore ceiling · `2` separate handle file (as before) · `3` handle
  ONLY (reprint a lost one). Litho refuses `1` with a pointer (its plate is
  FLAT — the handle lives in its own file there).
- **Loud errors:** label refusals show their REASON on the display
  (`M117 Err: Stamp = exactly ONE label …`), and the job menu carries a
  `! Stamp needs 1 label` guard row while the queue breaks the rule.

### 5.3 Plotter — images, photos and text with a pen

Mount a pen instead of (or next to) the nozzle and plot images, photos,
vector graphics or text — no slicer involved.

**Files — the name is the switch**

| Select in the file list | What the watcher generates |
|---|---|
| `photo.png` | PNG → `V01_Plot_photo.gcode` (pen lines) |
| `foto.jpg` | JPEG (baseline; progressive photos refuse — export as PNG) |
| `drawing.svg` | SVG vector graphics |
| `plan.pdf` | vector PDF |
| `notes.txt` | text → auto-wrapping, auto-shrinking page |
| options in the name | `bild.c3.s035.png` = 3 shades, 0.35 mm hatch (defaults c2 / s040) |

**What the converter does for you**

- **Auto-contrast (Otsu)** finds the paper/background — yellowed, grey grid
  paper, light blue — and makes it white: only the dark ink gets plotted.
  Photographs of hand sketches just work.
- **Dark backgrounds just work**: digital writing boards (black background,
  greyish writing), chalk photos, negatives — the converter samples the image
  border; a dark border with a brighter interior means INVERT, the bright
  strokes become the ink. `Invert: AUTO/ON/OFF` in the menu (applies at
  conversion time); the decision is logged in the file header.
- **Text files**: auto-wraps and auto-shrinks to fit ONE page (letters 7 mm
  down to 1.8 mm), umlauts print correctly, unknown characters become `?`.
- **Status on paper**: Tools > Plotter > **> Plot status** (`PLOT_STATUS`) draws the
  SHOW_STATUS report — version, mode, material, temps, PA, flow, speed, accel,
  input shaper, mesh, active overrides — on one page.

**Plotter menu** (in **Tools**)

- DRAW lines vs **DOTS stipple** (fine pencil lines), dot gap
- pen **offset X/Y/Z** (pen next to the nozzle), **scale X/Y in %** (auto-
  capped at the bed limits — you can never scale beyond the bed), bed corner
  limits, **extruder ON/OFF** (draw with filament instead of a pen — heats up
  then), Z up/down, speeds, max size, auto-contrast
- **Drive frame test** drives the pen around your configured bed frame once —
  verify the limits with a real line
- **Start (overrides)**: speed %, pen Z, X/Y shift applied at every plot start
- **Plot text file**: LCD name editor for `PLOT_TEXT FILE=...`
- everything is centered on the bed automatically

**Plotting**

1. Select the file → start dialog: AS SLICED = pure pen (no purge); AS LEGACY
   heats when the extruder is ON.
2. Multi-color plots pause (M0) at every pen change — swap, RESUME.
3. **Live tuning works while plotting**: speed %, acceleration, pen Z ±0.05,
   X/Y ±0.5 shifts (Live Tuning > Plotter). Pen pressure = the usual
   babystepping Z entries.

**Resonance plates and other generated plots:** the calibration chapter
(10.4) shows how the shaper diagrams are PLOTTED or printed as thin plates —
the plotter is part of the calibration toolset too.

### 5.4 Cable ties — the built-in cable-tie maker

Printable cable ties in ONE file, straight from the LCD — no slicer, no
modeling. Each tie is a flat strap with a normal, small closure head like a
shop-bought cable tie: thread the chamfered tip in, pull tight, cut off the
excess. Head size, slot clearance, tooth pitch and bead spacing ALL
auto-scale with the strap width — you never tune the mechanism itself.

**Two closure variants (Setting: Closure)**

| Variant | How it closes | How it opens |
|---|---|---|
| **CLASSIC** | the normal cable tie: a small pawl in the head reaches into the slot, the strap's teeth ratchet past it — pulls tight, locks at every tooth | one-way: cut to remove |
| **LOOP** | a frame loop with an open slot plus beads along the strap — pull the tip through, it snaps over each bead | lift the strap back out of the loop — adjustable at every bead, **reusable** |

**The workflow (LCD: `Tools > Cable ties`)**

1. **Settings** — Count, Length, Width, Layers (strap thickness), LH (layer
   height), Closure, Brim, Vers (see table below).
2. **Create (press twice)** — the first press arms (`Again = start` on
   the display, 10 s window), the second starts the build with a short
   start chirp; then the watcher builds
   the file in the background (niced, ~1–3 s). The happy tune plays and the
   file **auto-selects**: `Vnn_Ties_<len>x<wid>_<CLA|LOO>.gcode` — it
   sorts to the TOP of the file list.
3. Start it like any file: start dialog → AS LEGACY or AS SLICED. The message
   lists everything that was auto-adapted (head size, slot, tooth pitch).

**Settings**

| Setting | Range | Meaning |
|---|---|---|
| Count | 1–24 | ties in ONE project file; the grid arranges them automatically (all fit the bed or you get a clear error) |
| Len | 50–300 mm | strap length. Rule of thumb: bundle circumference + head + a few cm of pull-in reserve |
| Width | 2–12 mm | strap width. The head auto-scales: at width 8 the head is ~12.5×10.6 mm, the slot is width + 0.5 mm, the tooth pitch ~0.45×width. Under 3.6 mm a 0.4 nozzle prints the teeth crisper (the message reminds you) |
| Layers | 3–6 | strap thickness in layers. 3 = flexible, 6 = stiff, strong band |
| LH | 0.12–0.32 mm | layer height. 0.12–0.16 = smoother teeth (finer ratchet steps) |
| Closure | CLASSIC / LOOP | one-way pawl vs adjustable bead loop (see table above) |
| Brim | ON/OFF | loops around each head on layer 1 — the thin head sticks better |
| ~ | auto | the version in the file name bumps ITSELF (V01, V02, ...) - regenerating never overwrites an older file |

**What prints** — CLASSIC: each tie gets a small box head (solid floor, two
channel walls, a ceiling) with a pawl strip at the channel entry, plus the
strap with stepped teeth on top (a low ramp climbs in, the steep flank
locks). LOOP: a frame with an open slot and a strap with diamond beads —
each bead is a light snap-fit detent that still holds under pull. Every tie
is an **exclude object** (`TIE_1..n`) — skip a failed one live in Objects.

**Material matters (thin flexing parts):** PETG or TPU bend best and hold
tight loops; PLA works for gentle curves and fixed mounts only. Print slow
on layer 1 (the standard first-layer brake applies) and let the fan run from
layer 2 (the file sets it itself).

**Console one-liner (Mainsail — every parameter optional):**

```
GEN_CABLE_TIES COUNT=6 LENGTH=120 WIDTH=8 LAYERS=3 VARIANT=CLASSIC LAYER_H=0.2 BRIM=1
```

`VARIANT=CLASSIC` (one-way) or `VARIANT=LOOP` (adjustable, reusable). Example:
`GEN_CABLE_TIES COUNT=12 LENGTH=100 WIDTH=3 VARIANT=LOOP` = a dozen fine
reusable 100 mm ties for cable management.

### 5.5 Angles & flat connectors — structural plates

Angle plates (L-brackets in ANY angle, equal or unequal legs) and flat
connectors (two boards joined side by side) — screw-on, printable, with a
fully automatic hole layout. LCD: `Tools > Angles+Flat`.

**Mode (the first menu entry)**

| Mode | What it builds | Typical use |
|---|---|---|
| **Angle (L)** | two legs at the set angle (30–170°), leg lengths A and B independently | inside corners, frames, kickers, brackets |
| **Flat splice** | one straight strip of length A+B | joining two boards flat: LEFT/RIGHT = the two halves, each screwed with the SAME hole pattern |

**The hole system — auto-arranged, auto-clamped, never broken**

- Holes sit on each leg's centerline, evenly spaced between the corner zone
  and the leg end — you set only the COUNT and the DIAMETER.
- The diameter can never exceed the leg: it is clamped to `width − 6 mm`
  (≥ 3 mm material around every hole) and to 10 mm. If it was clamped, the
  result message says so.
- If the leg is too short for the requested count, the count drops
  automatically (e.g. 3 → 1 on a short B leg) — the message lists every
  reduction.
- In FLAT mode both halves carry the SAME pattern (mirrored): the parameters
  of one side transfer to the other, so both boards always match.
- **Countersink ON/OFF:** ON adds a two-step cone (two top layers) so
  flat-head screws sit flush; OFF = straight hole for screw head + nut.

**Walls, infill, ironing — the strength dial**

- **Walls 1–6**: concentric loops per layer (outer + inner walls). Wall
  thickness = walls × line width — 4 walls at a 0.6 nozzle ≈ 2.6 mm. The
  number auto-reduces when the leg is too narrow (console reports it).
- **Infill 20–100 %**: 100 prints the classic solid hatch; lower values widen
  the line spacing — lighter plates that stay strong because the walls carry
  the load around the holes. 40–60 % is a good everyday setting.
- **Ironing ON**: one slow, low-flow pass over the top face after the last
  layer — smooth, even surface (skips the countersink cones automatically).
- The hatch inside the walls alternates 45°/135° per layer (cross-lamination)
  and every hole keeps its keep-out — stability = walls + cross-hatch + rib.

**Stiffener (angle mode only; hidden in FLAT mode)**

| Value | What it adds |
|---|---|
| 0 — None | flat plate, the thinnest option |
| 1 — Gusset rib | a triangle over the corner on top of the plate — the standard stiffening; roughly half the plate height |
| 2 — Stepped rib | gusset plus a second, smaller one on top — strongest, for large angles under load |

**Settings (all of them, in menu order)**

| Setting | Range | Meaning |
|---|---|---|
| Mode | Angle / Flat | bracket vs straight splice (see above) |
| Angle | 30–170° | only in Angle mode — hidden in Flat mode |
| Leg A / Left | 20–150 mm | first leg (from the corner) / left half of a flat splice |
| Leg B / Right | 20–150 mm | second leg / right half — set both equal for a symmetric splice |
| Width | 8–60 mm | leg width (the plate's depth) |
| Layers | 4–12 | plate thickness in layers |
| LH | 0.12–0.32 mm | layer height |
| Holes | 0–6 per leg | screw holes per leg (auto-reduced if they do not fit) |
| Hole D | 2–10 mm | hole diameter (auto-clamped to the leg width) |
| Holes: countersunk / normal | toggle | flush flat-head screws vs straight through-hole |
| Rib | None / Gusset / Stepped | corner stiffening (angle mode only) |
| Walls | 1–6 | concentric wall loops per layer — wall thickness = walls × line width (auto-reduced on narrow legs) |
| Infill | 20–100 % | 100 = solid hatch, lower = wider line spacing (the walls carry the load) |
| Ironing | ON / off | one slow, low-flow pass over the top face — smooth finish. The **flow** row is the slicer's own ironing flow in percent — 5–100, typical **15–20**, default 15; the LCD shows and sets exactly the value the pass runs with (no 100 % multiplier, one flow entry per menu) |
| Count | 1–12 | plates in ONE project file |
| ~ | auto | the version in the file name bumps ITSELF (V01, V02, ...) - regenerating never overwrites an older file |

**The workflow**

1. Mode → Settings → **Create (press 2×)** — first press arms
   (`Again = start`), second press starts (start chirp). The file appears
   after ~1–2 s,
   auto-selected: `V<nn>_Angle_<deg>deg_<A>x<B>.gcode` or
   `V<nn>_Flat_<A+B>x<width>.gcode` (the running number leads, no 00 prefix).
2. The ready-message summarizes the plate AND every automatic adjustment
   (clamped diameter, reduced hole count) — nothing adjusts silently.
3. Start like any file; each plate is an **exclude object** (`PLATE_1..n`).

**Sizing rule of thumb:** the corner zone of an angle is as wide as the leg
(the legs overlap there) — the first hole sits ~width + hole/2 + 1.5 mm from
the corner. For a 90°/40/40 bracket with 4 mm screws that leaves ~1–2 holes
per leg; use longer legs for more screws.

**Console one-liner (Mainsail — every parameter optional):**

```
GEN_ANGLES COUNT=2 ANGLE=90 LEG_A=60 LEG_B=60 WIDTH=25 LAYERS=6 HOLES=2 HOLE_D=4 CS=1 STIFFENER=1 WALLS=4 INFILL=60 IRONING=1 FLAT=0
```

`CS=1` = countersunk, `CS=0` = normal holes. `FLAT=1` switches to the flat
connector (ANGLE is then ignored). Examples:
`GEN_ANGLES ANGLE=135 LEG_A=70 LEG_B=40 WIDTH=30 HOLES=3 STIFFENER=2` = heavy
135° bracket with stepped rib; `GEN_ANGLES FLAT=1 LEG_A=50 LEG_B=50 WIDTH=25
HOLES=2 HOLE_D=5 CS=0` = plain 100 mm splice strip.


### 5.6 Lithophanes — photos that glow

Turn any picture into a back-lit relief print: dark areas print thick, light
areas thin — held against a lamp or window the photo appears. No slicer, no
modeling, no manual image editing: the generator takes the picture as-is and
does the optimization itself (contrast stretch, smoothing, mirror for the
correct viewing side).

**Stamp mode** — press photos into clay, wax or soap: set
**Stamp ON + Mirror X ON** (FLAT). The generator prints a ~5 mm body with
a snap socket in its underside under the mirrored relief; the optional
**handle** (own file, `Handle 1`) snaps in and holds firm for stamping —
push in until the tip rests on the socket ceiling and the lip clicks into
the groove. Text stamps: **Labels** can do the same (`Labels > Settings >
Stamp`, one label per job, mirrored text).

**The workflow (LCD: `Tools > Lithophane`)**

1. **Upload a picture** — drop any `.png`/`.jpg`/`.jpeg` into the gcodes
   folder (Mainsail drag & drop). The **Images** list refreshes on its own
   (newest first, 10 slots). Pictures you uploaded for **pen plotting are in
   the same list** — the original is never touched, plotting keeps working.
2. **Settings** — Orient, Height/Size, Layer, Levels, Colors, Frame, Brim,
   Ironing (see table).
3. **Slot press = Create (press 2×)** — first press arms the slot, second
   press starts it (start chirp); the watcher generates in its own
   background thread (big pictures ~a minute, the printer keeps serving
   previews meanwhile), the happy tune plays and the file **auto-selects**:
   `00_Litho_<name>_V<xx>.gcode`.
4. Start it like any file. The message reports the plate size, layer count,
   thickness range and the level count.

**Settings**

| Setting | Range | Meaning |
|---|---|---|
| Orient | STANDING / FLAT | STANDING (default): on edge, the classic recipe — most detail, layer lines run with the image. FLAT (step print): the plate lies on the bed — back glass-flat, the top carries the image as clean gray STEPS (full layers, no wavy relief; optional Ironing smooths each step). Ideal as a frame Disc: set Size to the photo size |
| Height / Size | 30–200 mm | **the picture, in the bed plane (FLAT: XY)** — the value is the picture's Y side in mm, X follows the image's aspect ratio (both clamp to the bed). STANDING: the value is the picture height = the print height in Z (one image row per layer). The height in Z is never a size input: **it is the relief — layer count × layer height** (0.7–3.0 mm) |
| Layer | 0.08–0.2 mm | 0.12 = default; 0.08 = maximum detail, roughly double the print time |
| Levels | 0–12 | 0 = continuous grey shades (photo look). 2–12 = posterized: the picture is reduced to N brightness steps — chunky retro look at 2–4, subtle terraces at 8–12 |
| Color swap | OFF / LAST / EACH | FLAT only: OFF = one filament for every step. LAST = M600 right before the DARKEST step — the classic: white body, black contour lines. EACH = M600 at every step boundary. Whenever swaps are on, a purge tower (12×12 mm, 15 mm probe clearance) prints alongside and takes prime + wipe after every change |
| StepL | 1–30 | layers per gray step (FLAT): step 0 = the whole light background as full layers, every darker step prints its region on top, the darkest = the contour lines |
| Frame | ON/OFF | border frame that holds the thin plate straight (recommended) |
| Side stands | ON/OFF (.136m, default ON, STANDING only) | **upright support**: two triangular fins LEFT + RIGHT of the plate, docking at the BACK of the solid frame border (the thickest edge — the light from behind stays unblocked). Right triangle in the side view: vertical seam along the plate (full height), foot on the bed (~55 % of the picture height), hypotenuse rising. The fin body is a **~5 mm perforated grid** (vertical ribs every layer + one bridging rib every ~5 mm of height) — stable to print, quick to remove. Break-off seam 1.2 mm: pliers free the plate, or leave the fins on as a **deco stand**. Needs the frame border — frame OFF disables the stands with an honest note |
| Brim | 0–10 loops | anchors the plate — STANDING to the bed, FLAT against warping (the fins get their own mini brim on layer 1) |
| Ironing | ON/OFF | slow smoothing pass over the light side (STANDING: front; FLAT: every step cap) |
| Border | 0–10 mm | FLAT: a picture frame around the plate at full height — 0 = off (the old Frame switch maps to 2.4 mm) |
| Corner | 0–20 mm | FLAT: rounded frame corners (0 = square; only with a border) |
| Contrast | ON/OFF | extra contrast boost after the stretch — pushes midtones apart so level edges stand out (sketches, logos, text). OFF = the raw gray values |
| Mirror X | ON/OFF | flips the picture left-right — **a stamp prints MIRRORED**: the relief is pressed face-down, only a mirrored plate stamps a correct imprint |
| Mirror Y | ON/OFF | flips the picture up-down |
| Contour | 0–3 | (FLAT only) 0 = walls + fill (default). 1 = the LAST layer prints only the top step's contours (outer AND holes), no fill. 2 = **CONTOUR RELIEF**: step 0 stays a clean solid plane, every darker step prints only its contour lines as raised walls on it — taller = darker, like a topographic map; holes get their own inner contour (a ring prints BOTH contours). 3 = fill as always, but the step walls become the true contours (holes walled too) |
| Stamp | ON/OFF | (FLAT only) a **stamp body** prints under the picture: ~5 mm tall (StampH), ~10 % infill, solid top skin — and a centered **snap socket** in the underside. Press the finished stamp into clay, wax, soap… The header notes it when the picture is UNMIRRORED (your choice, no hidden flip) |
| StampH | 4–12 mm | the stamp body height (the socket sits inside it, auto-raised if too thin) |
| StampFit | 0.10–0.50 mm | the socket's radial clearance per side — 0.25 = standard: looser = easier snap, tighter = firmer hold. The fit is MEASURED from the generated g-code (tools/r168_stampcheck.py), not believed |
| Handle | 0–3 | 0 = none. 1 = ON THE PLATE (label stamps only — refused for the litho stamp). 2 = an extra **handle file** (own g-code — print it when you want it, it never wastes filament with the stamp). 3 = handle ONLY (reprint a lost one). Same numbering as the label stamp. The handle snaps into the socket — no rotation, no thread: a hollow tipped spigot with a groove locks under the socket lip; every surface is vertical or 45° |
| ~ | auto | the version in the file name bumps ITSELF (V01, V02, ...) - regenerating never overwrites an older file |

**How it prints (STANDING)** — upright, one picture row per layer (the layer
lines run WITH the image, that is what keeps the detail). Thickness runs
from 0.7 mm (brightest, glows first) to 3.0 mm (shadows), 100 % solid —
the file sets everything itself: slow walls, fan curve, PRINT_START. The
plate is one **exclude object**.

**How it prints (FLAT, step print)** — lying on the bed: the
back is glass-flat, and the picture is quantized into `Levels` gray steps
that print ONE AFTER ANOTHER as full layers: step 0 = the whole light
background (one clean surface — iron it), every darker step its (nested)
region on top, the darkest step = the black contour lines. Nothing ever
prints over air (each region lies completely on the step below), the nozzle
never dives into a wavy relief and the probe never catches on steps. The
file is `00_LithoF_<name>…`. The classic sketch recipe: white background
image + Levels 3 + Color swap LAST = white body with black lines.
**Sizes:** the Size input sets the picture in **XY** (the bed plane) —
X follows the image aspect, both clamp to the bed. The height in **Z is
not a size**: it is the relief — the layer count × layer height (the
thickness range dark→light). Both modes hard-clamp to the bed (aspect
kept) — a value can never produce an oversized plate.

**Material & light:** white or natural PLA glows best. The effect unfolds
with back-light 20–50 mm behind the plate (window, LED, tea light with a
diffuser). Big plates above ~120 mm can be printed in two halves and glued.

**Housekeeping** — `Delete image` (2-press confirm: press the slot, press it
again) removes the picture from the folder. Its **plotter `.gcode` stays** in
the file list — only the image goes away. Console: `LITHO_CREATE INDEX=0`
(first image slot) or `LITHO_DEL_SLOT INDEX=2`.

**Spray stencils (R267)** — the same images, cut into tone bands
(LCD: `Tools > Stencil`, reuses the lithophane image list): the picture is
quantized into **2–4 tone bands** (`Bands` setting) and EVERY band becomes
its own flat stencil plate — the cutouts are exactly that tone, so you
spray **lightest first, darkest last**, stacking the plates on pins.
Design agreed with the user: bridges are **automatic at 3× nozzle**
(floating plate pieces — the center of an "O" — stay attached, thin enough
to hardly show when spraying), every plate is a **rectangle with 4
registration holes D4.2 mm at the SAME position** (stack on M4 pins,
same corner orientation), and **Negative ON** adds one extra plate where
the motif stands and the background sprays through (two-color companion).
If the image cannot fill the requested band count (flat-color logos),
the generator honestly makes FEWER, healthy plates and says so. Settings:
Bands 2–4, Edge 40–220 mm (longer picture edge; aspect follows), Thick
0.4–2 mm, Negative. Console: `STENCIL_CREATE INDEX=0`.

### 5.7 Gaskets — the built-in seal maker

Sealing rings straight from the LCD: outer/inner diameter and height, with a
flat face or a groove that raises the contact pressure. One continuous
spiral per band — no seam, no start-stop blob where a seal would leak, and
no string ever dragged across the open groove (crossings retract, even the
short band-to-band hop between the lips).

**The workflow (LCD: `Tools > Gaskets`)**

1. **Settings** — OD, ID, Height, Face (FLAT/NUT), Ironing, LH, Vers.
2. **Create (press 2×)** — arm, then start; the watcher builds the file in
   seconds, the happy
   tune plays and the file **auto-selects**:
   `00_Seal_<od>x<id>x<h>_V<xx>.gcode`.
3. Start it like any file.

**Settings**

| Setting | Range | Meaning |
|---|---|---|
| OD | 12–200 mm | outer diameter — measure the flange face, not the pipe |
| ID | 6–190 mm | inner diameter; the ring band must be ≥ 2.4 mm wide |
| Height | 0.4–6 mm | 1.2 mm = standard flat gasket; 2 mm+ recommended for NUT |
| Face | FLAT / NUT | FLAT = full contact face. NUT = a groove in the face leaves two raised sealing lips — higher pressure, seals better on uneven/flanged surfaces (falls back to FLAT with a note if the band is too narrow) |
| Ironing | ON/OFF | slow smoothing pass over the sealing face |
| LH | 0.12–0.32 mm | layer height; 0.12–0.16 = smoother face |
| ~ | auto | the version in the file name bumps ITSELF (V01, V02, ...) - regenerating never overwrites an older file |

**Material:** TPU seals best (the file already prints at 15 mm/s), PETG
works, PLA only for dry, low-pressure lids. Dry the filament — moisture
bubbles are the #1 seal killer.

**Console one-liner (Mainsail):**

```
GEN_SEAL OD=40 ID=20 HEIGHT=1.2 PROFILE=FLAT IRONING=0
```


### 5.8 Frames — picture frames & display cases

A frame for a photo, or a deep display case for a collectible — printed in
one piece with its backplate, stand and hidden hanging options. The main
design goal: a **uniform, smooth front face** — the frame prints lying on its
back, the visible face points up and gets the ironing pass.

**Placement & first layer (field log .74):** every plate — one-piece, multi
Part A/B, split kit — sits **centered on the usable bed**, never crammed
into the x0/y0 corner. If the frame alone would not fit, the border
hard-clamps to what the bed offers (minimum 6 mm) before the
generator ever thinks about splitting — and the W/H inputs never accept
values above the build volume. The first layer of every part prints in a fixed
discipline: **brim → inner wall → outer wall → one continuous zigzag fill**
(back-and-forth with extruded connectors — singly printed lines curled up at
their starts/ends and frayed the borders). The only travels inside that fill
cross open holes (keyhole, stud holes, cable slot) — and those retract.

**The workflow (LCD: `Tools > Frames`)**

1. **Settings** — Preset (9x13 · 10x15 · 13x18 · A6) or custom W/H, Depth,
   Border, Corner r, Shape, Closure, Hang, Stand, Surface (Front), Disc,
   Cable, Infill, Walls, Vers — each topic is its own submenu, plus
   **Presets** (save/load/delete your own complete frame configurations,
   8 slots).
2. **Create (press 2×)** — arm, then start; the watcher checks the bed fit
   while generating
   (≈ 1 s), the happy tune plays and the file **auto-selects**:
   `V01_Frame_<preset>_FLATx8.gcode` (Part A when the bed needs two
   plates — one beep per plate, the number of beeps = number of files).
3. Start it like any file. Multi-plate: after the last layer of Part A the
   console + LCD say which file is next — **nothing auto-starts**, load and
   start Part B yourself (same material, same settings).

**What a frame consists of**

| Part | Job |
|---|---|
| FRAME | the ring: solid back band → photo groove (with the closure nubs) → bridge shelf → front face with the view opening; the front's last layer is ironed |
| BACKPLATE | 0.8 mm cover plate — 0.35 mm play per side through the photo shaft (measured fit round, field log .125), snaps under the 4 wall nubs; hidden keyhole (TOP/BOTTOM/LEFT/RIGHT) and, with Stand, two D2.7 stud holes |
| STAND | easel leg with two studs that plug into the backplate holes (24 mm apart) |
| STRIP_T/B/L/R | only in the split KIT: the four frame walls as glue strips |
| Part A / B | multi-plate: when frame + backplate do not fit side by side, the generator writes two files — `Vnn_A_Frame_….gcode` (frame) and the next number `Vnn_B_…` (backplate + stand) — the plate letter sits DIRECTLY behind the version, so the 15-character LCD shows the role (the old tail suffix was cut off); consecutive numbers tell any two files apart at a glance. Part A auto-selects, the end-of-plate hint (console + LCD + beeps) names Part B, no auto-start |

**Settings**

| Setting | Range | Meaning |
|---|---|---|
| Preset / W·H | 40–230 mm | photo inner size (9x13 stays one file up to border 10; 10x15/13x18/A6 print as 2 plates on the 220 mm bed) |
| Depth | 3–60 mm | under 15 = flat photo frame, 15+ = deep display case (same closure system) |
| Border | 4–30 mm | frame width around the photo |
| Corner r | 0–30 mm | corner radius (RECT only; a split kit drops it to 0 with a note) |
| Shape | RECT / OVAL | OVAL = ellipse from W×H (two diameters); no kit split for ovals |
| Closure | BACK / SIDE | BACK = snap-in backplate: the plate has **0.35 mm play per side** measured against the photo shaft's LIGHT size (wall lines print with their center on the contour — the shaft is one line width narrower than the photo contour, the plate half a line wider than its own). Drop it in, the 4 wall nubs click over its edge with a 0.2 mm overlap — the nubs grow out of the wall at ≤45° over two layers. SIDE = photo + plate slide together through the slot in the left wall |
| Hang | TOP/BOTTOM/LEFT/RIGHT/OFF | keyhole position in the backplate — **invisible from the front** |
| Stand | ON/OFF | easel leg; auto-dropped with a note if the bed has no room |
| Front (Surface) | Ironed / Bed texture / Lines / Waves / Honeycomb | the visible face: classic ironing pass, the flipped print (bed texture = the face, no ironing) or a structured border band |
| — structure | Depth 0.4–2.4 mm · Spacing 2–15 mm · Angle 0–90° · Wave amp 0.3–3 mm · Cell 4–20 mm · Dir IN/OUT | Lines/Waves/Honeycomb parameters; OUT = ridges proud of the face, IN = grooves cut into it (RECT only, replaces ironing) |
| Disc | NONE / GLASS / PLEXI / FOIL / LITHO · Side FRONT/BACK · Thick 0.4–6 mm | optional disc insert: FRONT = in front of the photo, captured by a 1.2 mm lip; BACK = behind the photo on the back band (backlit litho) — the groove grows by the disc thickness |
| Cable | ON/OFF | hidden 6 mm cable duct through the bottom bar (display CASE only, depth 15+) — opens 2.5 mm behind the back face straight into the interior, invisible from the front |
| Ironing | ON/OFF | the smooth shiny front pass (only with Front = Ironed) |
| Infill | 5–100 % | frame body infill (the solid faces stay solid; below 100 % the body prints as SPARSE infill — its own feature tag) |
| Top layers | auto / 1–15 | solid layers of the FRONT face (auto = the classic ~1 mm band) — independent of the front effect and the orientation |
| Bottom layers | 0–15 | solid skin at the BACK face (default 2; 0 = infill from layer 1) |

**Bed-fit logic (automatic, real bed 220×220 from `[gcode_macro _R2_CONFIG]`):**

1. frame + backplate side by side fit → **one file** (small formats).
2. they don't, but the frame alone fits → **two plates**: Part A =
   frame, Part B = backplate (+ stand). Nothing is glued, the finished
   frame is identical to the one-piece print.
3. even the frame alone overflows the bed (RECT only) → **4-strip glue
   kit** (strips on plate A, backplate on plate B; every part an exclude
   object, the notes say: glue the butt joints with wood glue).
4. still too big, or OVAL that doesn't fit → a clear console message with
   the border limit — the guard beeps and shows on the LCD, nothing
   half-fits and no file is written.

**Assembly (BACK):** photo lies flat onto the back band, backplate goes in
with its edge notches at the left/right nubs, slide 2.5 mm — locked, no
tools, no flex. **(SIDE):** photo + cover plate slide together into the left
wall slot. The hang keyhole works with a normal nail or screw head.

**Console one-liner (Mainsail):**

```
GEN_FRAME PRESET=10x15 DEPTH=8 BORDER=12 SHAPE=RECT CLOSURE=BACK HANG=TOP STAND=1
GEN_FRAME PRESET=10x15 DEPTH=20 CABLE=1 DISC=PLEXI DISC_T=1 DISC_SIDE=BACK
GEN_FRAME PRESET=9x13 FRONT=HEX S_SIZE=9 S_DIR=IN
```


### 5.9 Texture: fuzzy skin & shaped bumps (any g-code file)

**Vorlagen library + full documentation (.136m):** Texture > Vorlagen
holds **55 ready looks** named after their APPEARANCE — Rattan,
Sandstein, Seil, Ziegelmauer, Wellblech, Honigwabe … One per pattern
(55 total), every entry carries the complete parameter set. One press loads
ALL settings and the answer names them (`Rattan (library) loaded:
mode=BUMPS, pattern=BASKET, scale=6.0, zsize=6.0, amp=0.30, dir=OUT`) —
the same rule for every generator with presets: **loading always adapts
and shows the settings** (older, slimmer presets say which settings they
do not carry instead of silently leaving them). Library looks are
read-only; saving under a library name numbers itself. The complete
catalog with a preview per pattern — sampled from the real pattern
functions — plus the exact parameter mapping lives in **TEXTURING.pdf**.

The only generator that does not create a part — it rewrites the **outer
wall of a file you already have**. The source is **the file you selected in
the file list** — with its subfolder path, taken the moment you press (works
right after selecting, even while the display preview is still catching up).
Two looks:

- **FUZZY** — every outer-wall vertex gets a random offset (a seeded
  scatter, same file + same settings = same result). That is the classic
  "fuzzy skin": matte, grippy, hides small wall flaws.
  **: files sliced with **arc fitting** (G2/G3 — vases, cylinders) get
  their arcs flattened into short textured chords first — the texture now
  runs seamlessly around the WHOLE part instead of only in the few straight
  bits between arcs (field log .74: "only the corners"). Each chord carries
  its exact share of the arc's extrusion.

**Fuzzy presets** *(sized after OrcaSlicer's fuzzy skin — thickness
0.3 mm / point distance 0.8 mm by default)*:

| Preset | Thick | Density | After Orca's use case |
|---|---|---|---|
| ORCA def | 0.30 mm | 100 % | standard fuzzy skin (Orca default) |
| Hide layers | 0.25 mm | 100 % | hides layer lines (Orca: 0.2–0.3 mm) |
| Subtle | 0.15 mm | 60 % | subtle matte surface (Orca: 0.1–0.2 mm) |
| Grip | 0.50 mm | 100 % | aggressive grip (Orca: 0.5–0.8 mm) |

LCD: Pre-Print > Texture > **Fixed presets** (Orca / Hide layers / Subtle /
Grip, one press each) and **My presets** — your own named
presets, unlimited. **.136v adds three shaped presets**: **Rope** (3-strand
twist, 14 mm / depth 0.5), **Basket** (interlaced weave, 10 mm / 0.35) and
**Chess** (soft chessboard, 12 mm / 0.4) — they switch the mode to BUMPS
and set the full parameter set, like the library looks.
The thickness range is 0.05–1.5 mm (Orca-sized).
- **BUMPS** — the offset follows a **pattern from the library**:
  **55 patterns on 7 pages — 54 shaped ones plus MAP**, every page also
  names the active one (a `*` marks it):

  | Pattern | What it looks like | Reach for it when |
  |---|---|---|
  | Ridges | vertical flutes around the object | vases, cups — grip without bulk |
  | Waves | diagonal waves (the classic) | the safe default on any shape |
  | Grid | crosshatch egg-crate | technical parts, panels |
  | Hatch | hard diagonal hatching | fast, graphic look |
  | Checker | soft checkerboard | playful boxes, lids |
  | Hex | organic 3-fold honeycomb-ish | rounded organic surfaces |
  | Honeycomb | true hex cells (distance field) | real honeycomb geometry |
  | Basket | woven over/under weave | baskets, boxes, rattan look |
  | Rope | twisted strands | handles, tubes, tool grips |
  | Planks | vertical boards, seeded stagger, grooved seams | crates, wooden boxes |
  | Bricks | running-bond courses with mortar grooves | walls, planters |
  | Sandstone | fine 2-octave noise | cast stone, terracotta |
  | Concrete | coarse noise + seeded pores | architectural models |
  | Clay | soft overlapping thumb dents | pottery, hand-made look |
  | Crepe | high-frequency crumple × mid wave | paper, packaging |
  | Fabric | pleats — sharp valleys, wide backs | cloth, curtains |
  | Plush | dense short fine noise | velvet, soft-touch grips |
  | Hilbert | REAL order-3 space-filling curve, tiled into a labyrinth | maze look, tech surfaces |
  | Scratch | anisotropic scratches around the circumference | worn metal, used tools |
  | Glitch | seeded per-band steps (the melt / shifted-layer look) | sculptures, artistic |
  | Knit | nested V-loops in staggered columns | knitted sleeves, sweaters |
  | Fluted | vertical half-round flutes | **kills Z-banding on cylinders** |
  | Bark | vertical ridged cracks | turns tubes into tree trunks |
  | Scales | staggered domed shingles | reptile look, grippy |
  | Facets | diamond low-poly relief crosses | modern / futuristic clean |
  | Macrame | two twisted cord families into a net | planters, hanging baskets |
  | Stonewall | stone courses, mortar beds, staggered joints | garden walls, planters, ruins |
  | Rubble | voronoi boulders in a deep mortar bed | dry-stone / natural stone look |
  | Tiles | flat tiles, chamfered edges, recessed grout | kitchens, bathrooms, mosaics |
  | Parquet | chevron parquet — direction flips per column | wood floors, decor panels |
  | Laminate | V-bevel planks with fine along-grain | clean wood panels, furniture |
  | Maze | perfect maze — every corridor reachable | puzzles, artistic grips |
  | Perforation | round dimples, staggered grid (no through-holes) | perforated sheet, sieve look |
  | Vent | square recesses, staggered grid | enclosure vents, speaker grilles |
  | Carbon | 2/2 twill weave, diagonal gloss bands | carbon-fibre look, tech parts |
  | Pindots | hemisphere knobs in a square matrix | grips, control panels, decor |
  | Octagons | octagon trays + corner squares, size jitter | model trays, tech surfaces |
  | Chainlink | woven fence — two 45° wire families, over/under | fence look, props |
  | Netgrid | round threads + knots, deep open meshes | netting, bags, organics |
  | Rings | wood cross-cut - growth rings around, wandering widths | turned wood look, decor vases |
  | Oak | coarse grain - wandering pore streaks over flame waves | oak furniture look, rustic |
  | Beech | the quiet wood - fine dense vertical fibre, almost poreless | clean wood surfaces |
  | Knot | burl - fibre deflects around seeded knot eyes | deluxe wood, knife handles |
  | Oldbark | ancient bark - long plates in DEEP furrows (**depth 2–3.5 mm**) | the old tree trunk (deep relief) |
  | Leather | padded - diamond-quilted cushions, stitch seams, fine grain | seats, boxes, upscale |
  | Orange | peel - fine irregular micro dimples (**small depth 0.1–0.25 mm**) | matte grip, organic |
  | Cracks | dried mud - narrow deep wandering cracks, crowned plates | desert/soil look, artistic |
  | Wrinkle | heavy folds - big soft drapes with sharp crests | crushed fabric/foil, dramatic |
  | Hearts | candy-box decor - raised hearts, staggered grid | ornaments, gifts, kitsch |
  | Golf | golf ball - dense round dimples, no rim | grips, balls, haptics |
  | Basketball | smooth channels over fine pebble grain | sports look, grips |
  | Woodchip | Raufaser - flat face, sparse fibre chunks | calm walls, paintable look |
  | Rooftiles | roof tiles - overlapping courses, side folds run straight through | roofs, facades, decor |
  | Crochet | knotty stitches with deep eyelets | cozy look, openwork |
  | MAP | your own image wrapped around (dark = deep) | photos, logos, lettering |

  **Seamless by design:** your mm
  values are guidelines — the tool lays WHOLE grooves around the perimeter
  and WHOLE repeats in Z (the top edge ends flush, no half brick) and
  reports the effective size, e.g. `[seamless: 9 ridges x 2 Z-repeats
  (eff. 8.4mm x 2.9mm)]`. Same **seed** = same look (matters for
  Sandstone/Glitch). A lithophane (no wall markers) falls back to "every
  path is the geometry" and says so in the file header.

Everything else stays **byte-identical**: `;TYPE:` tags, EXCLUDE_OBJECT,
APPLY_TYPE/LAYER_MARK markers, and the Z/F of every move — infill,
ironing and supports print exactly as sliced. The E of every untouched
move stays too; in DEEP RELIEF (below) the E of the displaced chords
rides their real length instead (per-move totals kept). On
arc-fitted files each flattened chord carries its exact share of the
arc's E (the total per arc stays — the E is redistributed, not the
inner geometry). **Inner walls (.136v):** in BUMPS mode they FOLLOW the
embossing — same angle, same pattern value, so the wall stack moves as
one. An untouched inner wall sits one line width behind the surface and
would CAP the valleys of a deep texture (the pattern reads washed out);
following keeps it invisible behind the outer skin while the walls keep
contact (the gap stays one line width, measured — even when the slicer
runs the inner loop the opposite way round; the tool detects the winding
per layer and realigns). FUZZY stays Orca-honest: only the outer wall
jitters, exactly like Orca's fuzzy skin.

**DEEP RELIEF (depth above 1 mm, up to 4):** the same patterns, but
honest about the physics of a deep embossing. A displaced chord has a
REAL length — stretched flanks would print thin with the slicer's E. On
relative-E sections (the M83 norm) every chord's E now rides its real
length (`E_new = E_old × L_new/L_old`, clamped to 0.45–1.8× so a cliff
cannot over-extrude; the per-move total stays). Steep flanks are
subdivided to ~0.4 mm height steps so the relief resolves. The wall
stays closed — the displacement is continuous and inner walls keep
following. Steep sections print as overhangs, like any stylized model:
slow outer walls and cooling handle that. On absolute-E files the E stays
slicer-true and the file header says so. Regression-tested: at depth
≤ 1 mm the output is byte-identical to the previous engine.

**Workflow (LCD):**

1. select the file as always (file list — Mainsail or the LCD; the
   selection preview shows the target),
2. **Pre-Print > Texture**, pick the mode + parameters,
3. **> Apply (beeps)** — the watcher builds the result in the background,
4. a **NEW file** `Vnn_<name>_TX.gcode` appears (the number counts up if you apply
   again — the source is never touched),
5. **check it in the 3D viewer** — nothing auto-starts, by design,
6. print the `_TX` file like any other (AS SLICED keeps the texture).

 Steps 5–6 follow **After gen** (ch. 5.0): QUEUE selects the `_TX`
result for printing and REPLACES the source file's selection (the source
itself stays on disk, untouched); PREVIEW ONLY leaves the selection alone.
In both modes nothing ever starts printing by itself.

| Parameter | Range | Meaning |
|---|---|---|
| Mode | OFF / FUZZY / BUMPS | OFF = the menu is inert (Apply refuses with a hint) |
| Fuz thick | 0.05–1.5 mm | scatter radius (fuzzy; the Orca-sized window
  is 0.15–0.5) |
| Fuz dens | 10–100 % | share of vertices that scatter (100 = all) |
| Pattern | library: 54 + MAP | 7 pages (see the table above); MAP = own image, wrapped seamlessly |
| Around | 3–60 mm | groove size around the perimeter (guideline — snapped to whole grooves) |
| Height | 0.4–20 mm | pattern repeat in Z (guideline — snapped to whole repeats, ends flush) |
| Depth | 0.05–4 mm | groove/bump depth — **above 1 mm = DEEP RELIEF** (E follows the real path, see below) |
| Seed | 1–999 | same seed = same look (Sandstone/Glitch) |
| Img | root image | MAP source — pick a picture in the SD browser |
| Dir | OUT / IN | OUT = grows away from the part, IN = cuts into it |

**What the tool will never do:** overwrite the source file · auto-start
the result · move anything but outer-wall vertices · leave the bed
(clamping with a counter) · touch Z/F values (deep relief lets the E of a
displaced chord ride its real length — the per-move total stays) · run
without guards (bad mode/pattern/direction, missing file, all 99 versions
used → clear error, nothing half-done).

**Special cases (tested):** a file without outer walls (infill-only
parts) → zero shifts, no crash · the very first outer vertex of a file and
zero-length restarts after a retract have **no approach direction** — they
stay untextured instead of guessing one · absolute-E files (M82),
E-only retract lines, G0 travels and CRLF line endings pass through
untouched · OrcaSlicer/Bambu spellings (`;TYPE:Outer wall` in any case)
are recognized.

**Console one-liner (Mainsail):**

```
TEXTURE_APPLY FILE=myfile.gcode MODE=FUZZY THICK=0.3 DENSITY=100
TEXTURE_APPLY FILE=myfile.gcode MODE=BUMPS PATTERN=WAVES SCALE=10 AMP=0.35 DIR=OUT
```

FILE may be omitted — then the **selected** file is the target (same as
the LCD). The result beeps when done (`r2_done`) and shows a console
summary; on error the alarm sounds and the LCD says what to fix.


### 5.10 Building bricks — the exact system geometry

The printer becomes a brick factory: bricks, plates and tiles with the
**exact geometry of the building-block system** — printed parts clamp to
each other AND to original bricks. No modeling, no slicer: pick parts from
the catalog, CREATE, print.

**Why the parts fit (the three numbers that matter)**

| Element | Measure | Effect |
|---|---|---|
| body | n·8 − 0.2 mm | the 0.2 mm play is the clamp: two parts side by side grip each other, printed next to original parts they clamp the same |
| stud | Ø4.8 × 1.8 mm, hollow (1.2 mm wall) | stacks like the original, prints without a solid blob on top |
| underside tube | Ø6.31 at every inner grid crossing | the tube walls spread over the stud below — the clutch comes out exactly right |
| brick / plate / tile | 9.6 / 3.2 mm heights, tile = smooth plate | layer heights that do not divide evenly snap to whole layers (noted in the file header) |
| underside | **open from layer 1** | wall ring + tube rings start on the bed — the parts really stack. 1xN parts keep a hollow core (studs clamp between the long walls); round parts keep a hollow core up to the cap. Brim anchors the outline |
| technic holes | Ø4.9 through BOTH long sides | the channel walls run segmented between the hole cutouts, the bridge layer above closes the roof — an axle passes clean through |

**The catalog (90 codes)** — `B`=brick 9.6 mm, `P`=plate 3.2 mm, `T`=tile
(smooth plate): 1x1 … 8x8 — first the width in studs, then the length.
Plus the families: `J1x2` jumper, round family `R1x1` / `RP1x1` /
`RT1x1`, `C1x1` cone, slopes `S` (steep 2-long, shallow 3+ with studs on
the back row), inverted slopes `I`, arches `A1x3..A1x6`, technic bricks
`H1x2..H1x8` with the Ø4.9 side holes.

**Baseplates, gears, axles & organic shapes:**

| Code | Part | Geometry |
|---|---|---|
| **BP8x8** … **BP24x24** | baseplates | thin 1.2 mm exact-grid base (n·8, NO play — it IS the ground), smooth underside, full stud grid on top |
| **BP11x16**, **BP16x22** | frame-matched baseplates | drop into the **9x13 / 13x18 Frames** exactly — a mosaic field for the picture frame |
| **G12** … **G40** | spur gears | module 1 (tip Ø = teeth+2 mm), trapezoid teeth, Ø4.9 axle bore — meshes across the 8 mm grid (G12+G24 centers 3 studs apart, …) |
| **AX2** / **AX4** / **AX6** | cross axles | standing print, technic cross profile Ø4.6, length 16/32/48 mm, tapered tip |
| **AH2x2** | axle stand | 2x2 brick with a **vertical Ø4.9 through-socket** — an axle drops in from above and spins |
| **D2x2** | dome | 2x2 stacking base (open underside) + solid hemisphere cap — the first organic shape |

**The workflow (LCD: `Tools > Bricks`)**

1. **Catalog** — every code is an entry; the press bumps its count
   (same codes merge, max 120 parts per plate).
2. **Settings** — Layer (0.08–0.32) and Vers, shared with the other
   generators.
3. **CREATE** — the watcher builds the file in its background thread
   (beeps + auto-select): `V01_Bricks.gcode`.

One file = **one color**, every part its own **exclude object** — a failed
brick can be skipped live and reprinted later. Console/Mainsail:
`GEN_BRICKS CODES="B2x4:3|P2x2:2"` (sets the queue and creates in one go).

### 5.11 Brick kit — a sliced file becomes a building kit

The kit generator reads **any sliced print file** and rebuilds it as a
stylized brick kit: the object is rasterized onto the stud grid and
decomposed into 2-wide bricks (the kit look), printed as plates A, B, C…

**What flows in — and what never does:** ONLY the object. Support,
support interface, brim, skirt and prime-tower moves are filtered out
before the geometry is even built (field rule: the kit is the CLEAN
object). Foreign slicer files work — `;TYPE:` comments and our
`APPLY_TYPE` markers are both understood.

**How the object becomes bricks**

| Step | What happens |
|---|---|
| Voxelizing | the object moves are sampled at 0.8 mm — the system's base unit |
| Bands | MICRO/SMALL: brick bands of 9.6 mm (merged 3 plate layers); BIG: plate bands of 3.2 mm (fine steps) |
| Solid or shell | closed bodies fill solid; hollow bodies (vases, sparse infill < 15 %) become **ring walls** — the silhouette stays, print time drops |
| Decomposition | greedy 2-wide bricks first (2x8 down to 1x1), orientation-resolved |
| Detail AUTO | ≤ 10 studs → MICRO, ≤ 26 → SMALL, else BIG |

**Colors 1–8** (grey, black, red, blue, yellow, green, orange, purple) and
two print strategies:

- **BY_LAYER (plates)** — one color per plate, the plate change IS the
  color change: **zero M600**. Print plate A in grey, plate B in black…
- **BY_OBJECT** — parts print one after another (the file says
  `BY_OBJECT=1`), sorted so that all parts of one color run together:
  M600 only at the color boundaries.

Up to **800 parts**, ~110 per plate; every part its own exclude object.
**The workflow (LCD: `Tools > Bricks > Kit from file`)** — Source (the 5
newest sliced jobs, generator outputs (Vnn_/00_ names) skipped; SRC=filename
via Mainsail),
Detail, Mode, Colors, CREATE. Console:
`GEN_BRICKKIT SRC=box.gcode DETAIL=AUTO MODE=BY_LAYER COLORS=3`.

### 5.12 Figures — assemble-it-yourself

Stylized figures in the classic proportions (caliper-measured head, torso,
legs) mapped onto the building system: **5 parts per figure** — legs, torso,
two arms, head. Assembly without glue: the torso presses onto the hip tenon,
the arms slide onto the shoulder pins (**they swing**), the head presses
onto the neck post (**it turns**).

**100 % = original size AND system-true:** the hands grip Ø4.8 studs and
axes, hats sit on the head stud, the feet click onto studs (anti-studs
underneath). Other scales (25–300 %) are display figures — only 100 %
mates with the system. Count 1–24, one color, every part its own exclude
object, ~39 mm tall at 100 %.

**The workflow (LCD: `Tools > Bricks > Figures`)** — Scale (25–300 %,
5 % steps), Count, CREATE → `V01_Figures_s100.gcode`. Console:
`GEN_FIGURES SCALE=100 COUNT=2`.

### 5.13 ColorPic — photos in full color, no backlight

The color sibling of the lithophane: the photo prints **flat** as stacked
color bands, lightest first — every darker band prints only its (nested)
region on top, so the picture needs NO backlight and works from every
angle. The image pipeline is the proven one (percentile contrast stretch +
optional boost), then the picture is quantized into 2–8 luminance bands.

**The workflow (LCD: `Tools > ColorPicture`)** — same image list as the
lithophane (upload a `.png`/`.jpg` into the gcodes folder), Width, Bands,
Band height, Colors (per-band palette, light→dark; auto ramps when empty),
Layer, Ironing, Brim, **Swap**, **Contrast**, Vers → CREATE →
`V01_ColorPic_<name>.gcode`.

| Setting | Meaning |
|---|---|
| Bands | 2–8 luminance levels — band 0 = the lightest color and covers the whole area (the base) |
| Band height | each band's thickness in mm (total height = bands × band height) |
| Colors | comma palette codes light→dark (WHT GRY BLK RED ORG YEL GRN BLU PUR BRN PNK CYA GLD SIL); fewer codes than bands = auto-filled |
| Swap | ON (default): M600 at every band boundary — the nozzle light dims while you swap, the **purge tower** (12×12 mm, 15 mm probe clearance) takes prime + wipe after every change. OFF: every band prints without a filament change (one color) |
| Contrast | extra boost after the stretch — band edges stand out (sketches, logos, text) |
| Ironing | smoothing pass over every band cap |

Console/Mainsail: `GEN_COLORPIC SRC=photo.png WIDTH=120 BANDS=4
COLORS=WHT,GRY,BLK BANDH=0.8 SWAP=1 CONTRAST=1`.

### 5.14 String Art — a picture woven from strands

The field proof (a generic StringArt3D file, 180 mm ring / 600
anchors / 1700 strands, printed beautifully) is now a native generator.
An **anchor ring** prints first — **two walls on every layer, 3 solid
bottom layers + 3 solid top layers + 5 % sparse infill between** (.136n:
the old all-solid ring wasted half a spool), brim, first layer fan-off;
then thin **strands** (0.5 mm wide, ~0.07 mm thick) shoot from anchor to
anchor in **six Z bands** above the ring — crossings in the same band
fuse, later bands clear the earlier ones (the proven ladder
+0.20/+0.40/+0.55/+0.60/+0.75/+0.95). Two finishing loops and a cover
ring tie the strand ends down.

**.136n field round** (the string-art test print brought seven
findings, all fixed):

- **Flow**: every E value is filament mm again — the old numbers were
  volumetric scale, the print came out ~2.4× over-extruded.
- **Temps**: the file carries its temperatures (PRINT_START
  BED/HOTEND) — the preheat no longer falls back to filament-swap
  level.
- **The bow**: each strand runs as a **2 mm bow in Z** (up from the
  band, over, back down — `Bow:` row, 0 = flat) and the
  strand-to-strand travel hops OVER the bows: the nozzle never drags
  through the strands laid before.
- **Direction**: strands are pulled from **alternating directions**,
  and consecutive strand starts keep **≥ 15° apart** — not thread after
  thread from the same corner (the ring softened there in the field
  print).
- **Frame**: `Shape: RECT` + the **photo-size presets 9x13 / 10x15 /
  13x18 / 15x20 / 18x24** (the Frames sizes) build a rectangular ring —
  string art drops into the Frames system. `W:`/`H:` for custom sizes,
  clamped to the bed.
- **Aspect lock (.136ac)**: with a PHOTO picked, the **`AR lock`** row
  keeps W and H coupled to the image's aspect ratio — change `W:` and `H:`
  follows (and back); picking an image adapts H to the photo at the
  current W. The lock row frees both for the classic fixed frames.
- **Ring height**: `RingH:` 1.2–6 mm (was fixed at ~2.4).
- **Photo builds are Pi-friendly (.136ac)**: the planner decodes at most
  288 px (its grid is ≤220 cells anyway), the JPEG IDCT runs separable
  (bit-identical, a quarter of the work) and the luma handoff drops RGB
  rows as it converts — a 1700-strand/600-anchor photo build peaks around
  **37 MB** instead of pushing the host into swap (the .136z field log:
  klippy reactor stalls during a photo build). Grayscale JPEGs decode
  again (they crashed above 512 px).

**The workflow (LCD: `Tools > ArtisticStrings`)**

1. **Pattern** — SPIRAL (the classic winding, no image needed — the
   ideal first test) or PHOTO (a root image becomes the weave:
   dark areas get dense threads, seeded = reproducible).
2. **Shape** — ROUND (the classic circle, `Ring:` diameter 60–400 mm,
   clamped to the bed) or RECT (photo preset or custom W/H — the
   frame ring).
3. **Ring / Anchors / Strands / RingH / Bow** — anchors 24–720 (field
   proof: 600 on 180 mm), strands 50–4000, ring height 1.2–6 mm,
   strand bow 0–4 mm.
4. **PHOTO only: `Img:`** — cycles the root image list (the same list
   as the lithophane, newest first; upload or pick via the SD browser).
5. **`> Weave it`** — press twice (arm + start). The file lands in the
   **StringArt** folder as `V01_StringArt_…` (RECT names carry the
   size, e.g. `_102x152`) and auto-selects.

**Print notes:** strands run at 60 mm/s (field-proven at exactly that
speed — the bows keep them tame; the file writes FS_BRIDGE, so the
Pre-Print > Spd/Acc/feature row can slow them live if your filament
strings), leave the fan to the file (first layer off, then a ramp per
band), no ironing. My presets saves every value.

### 5.15 Scale X/Y — resize with honest flow (with the TAPER option)

Scale the SELECTED file per axis, **25–300 %** — and the flow stays honest:
E is recomputed **per move** as (L′/L)·(w′/w) — axis moves scale with X·Y,
45° moves with (X²+Y²)/2, uniform scaling gives X² everywhere. Layer
height stays untouched, the result is centered on the bed, G2/G3 arcs
flatten to scaled chords, and the **new 100 % flow baseline is the new
file** (`name_SXXX-YYY.gcode` in the `Scale/` folder, numbered copies,
never overwrites). The bed guard names the required size if it does not
fit. LCD: Pre-Print > Tools > Scale X/Y — X/Y inputs, `How? (E/flow)`
explains the math, `> Apply` (2×). Console:
`SCALE_APPLY X=150 Y=150 FILE=myfile.gcode`.

**Taper (.136n)** — an OPTION of Scale X/Y, not a tool of its own:
**Top X / Top Y** (0 = off, else 25–300 %) set the scale at the TOP of
the object while X/Y stay the bottom scale. The factor interpolates
**linearly in Z over the extruding span** — travel hops do not water
the top factor down — and E is recomputed **per move** with the local
factor, so a taper to 60 % really prints 60 % walls at the top. Output
name: `name_S100-100T60-60.gcode` (bottom-bottom-top-top). The bed
guard checks with the LARGER of the two factors. Console:
`SCALE_APPLY X=100 Y=100 TOP_X=60 TOP_Y=60`.

### 5.16 Cake cut — split a print with a plane

Slice the SELECTED file with a plane: **pitch / roll** on the 0.5° grid
(front-back / left-right tilt — .136v: **yaw is gone**, it only said
where the tilt points and pitch/roll say that alone) and **Z plane** =
the plane's height at the bed center. Every move splits exactly at the
plane (t = w0/(w0−w1) from the signed distance — exact, not searched),
E divides by length share, arcs flatten first. **LOWER** keeps its
place; **UPPER** becomes its own file — dropped to the file's first layer
height, or with **Reorient ON** rotated so the **cut face lies flat on the
bed** (the natural way to print a top piece). Output:
`name_CUT-U.gcode` / `name_CUT-L.gcode` in the `Cake/` folder; PART picks
UPPER / LOWER / **BOTH = two separate files (Lower + Upper), each prints
standalone with its own E baseline** (.136v). Guards refuse planes
above/below the object.
LCD: Pre-Print > Tools > Cake cut. Console:
`CAKE_APPLY PITCH=15 Z=5 PART=BOTH REORIENT=1`.
The full methodology — plane mathematics, the two-pass architecture,
stream separation, Rodrigues reorientation and a worked example with
real numbers from a real run — lives in **CUTSPLIT.pdf**.

### 5.17 Twist — rotate around the Z axis (.136n)

Twist the SELECTED file around its own axis: **Deg** (−720…720, sign =
direction) — 0° at the bottom, your angle at the top, everything in
between rotates linearly in Z. Every layer rotates **around the
object's own center** and the object lands **centered on the bed**;
**E stays verbatim** — a rotation is isometric, the extrusion lengths
never change. G2/G3 arcs flatten to chords first (each chord carries
its exact length share of the arc's E). The bed guard checks the
**circumscribed circle** (the diagonal), because a twisted corner
sweeps wider than the object. Output: `name_TWR90.gcode` in the
`Twist/` folder, numbered copies, never overwrites. LCD: Pre-Print >
Tools > Twist — Deg input, `How? (E stays)`, `> Apply` (2×). Console:
`TWIST_APPLY DEG=90 FILE=myfile.gcode`. Combine freely: scale/taper
first, twist the result (or the other way round) — both tools pass
E honestly through.

### 5.18 Geometry — triangles, polygons, cylinders & vases (.136n)

The geometry generator (Generator > Geometry) prints simple solid
bodies without a slicer: **TRIANGLE / SQUARE / POLY 3–12 corners /
CYLINDER** (round = 48 segments, or your own count — hexagonal, …),
**X/Y size 8–200 mm**, height 2–180 mm, **walls 1–8** (loops),
**wall thickness in mm** (overrides the loop count: 1.9 mm @ 0.65 line
= 3 loops), **infill 0–100 %** (0 = hollow, 100 = solid, between =
sparse grid), base and top surface layers. **Walls = 1 is VASE MODE**:
solid floor (base layers), then ONE continuous spiral wall with
steadily rising Z — no top, no infill, the classic vase. Output:
`V01_Shape_Cylinder_40x40x20.gcode` (vases carry `_vase`) in the
`Shapes/` folder. Console: `GEN_SHAPE SHAPE=CYLINDER X=40 Y=40 Z=20
WALLS=1 INFILL=0 BASE=3`.

### 5.19 OBJ export — a g-code file back into the slicer (.136n / R2.14)

Pre-Print > File > OBJ: the SELECTED R2-generated file (labels,
gaskets, angles, figures, shapes — every generator output) becomes a
**watertight Wavefront OBJ mesh** again — one solid per EXCLUDE_OBJECT,
real extrusion widths as wall thicknesses, floors and top surfaces closed.
The mesh opens in every common 3D program (Blender, PrusaSlicer,
Cura, Fusion). R2.14: the STL export was REMOVED completely — OBJ is the
only object export (same triangles, vertex-deduped). Start sound +
LCD notify when the file is done; output lands next to the source in
the `STL/` folder — named `name_object.obj.gcode`: Mainsail
shows it in the file list, one click downloads it, strip the `.gcode`
ending and every 3D program opens it.

### 5.20 Mirror — flip on X or Y, exactly in place

Flips the SELECTED file around the **object's own center** — unlike
scale/twist (which re-center on the bed) the object stays **exactly
where it was**: every X (or Y) coordinate mirrors around the geometry
bbox center, the bed footprint is bit-identical. **E stays verbatim**
(a flip is isometric), G2/G3 arcs flatten to mirrored chords.
`EXCLUDE_OBJECT_DEFINE` CENTER + POLYGON flip with the same plane — KAMP mesh
and object exclusion stay honest. Multi-object files
(print-by-object): `OBJ=` flips ONE object around **its own** center,
the rest stays untouched. Output: `name_MIRX.gcode` /
`name_MIRY.gcode` in the `Mirror/` folder, numbered copies, never
overwrites. LCD: Pre-Print > Tools > Mirror — axis X/Y, `How? (E
stays)`, `> Apply` (2×). Console: `MIRROR_APPLY AXIS=Y FILE=myfile.gcode
OBJ=LEFT`.

### 5.21 Toolchain — chain the tools with a preset file (R259)

Chains the **real tools**: every step feeds the next (Scale → Twist →
…), **one** background job, only the **last** output stays (intermediate
steps die after handover). The preset is a **file** — click a `.json`
in the SD browser to pick it, no JSON typing at the dial. An example
ships in the `Toolchain/` folder (`Scale up + twist`); make your own on
the PC and drop it in via Mainsail — any subfolder works. Preset files
survive umlauts in their *name* (display only); generated *file* names
transliterate (ä→ae, ö→oe, ü→ue, ß→ss — `Groesser_Rahmen` reads on
every LCD).

The chain runs on the **selected file** (root folder or any subfolder —
a Range output chains just fine), shows its **progress per step**
(`Chain 2/3: Twist`), waits for printer idle like every generator (a
print start is refused with `Wait: generating` until the chain beeps
done) and lands the result in the `Toolchain/` folder as
`V<nn>_<name>_<PresetName>.gcode` — numbered, never overwrites, newest
first in the folder listing. Deleting a preset file: the SD browser's
**Del** mode (2× press, same as every file). LCD: Pre-Print > Tools >
Toolchain — Preset/File info, `How? (chain)`, `> Apply` (2×). Console:
`TOOLCHAIN_APPLY PRESET=Toolchain/scale-twist.json FILE=myfile.gcode
OUT=PREVIEW` (OUT=QUEUE selects the result for the next start,
OUT=PREVIEW just drops it in the list — same as every generator).

**Limits, honest:** chainable tools are Range, Scale, Texture, Twist,
Mirror, plus single-half Mold and Blank-Mold steps (`part` TOP or BOTTOM,
`sectors` 0 — multi-file BOTH and multi-piece sector sets belong in the
generator menu). Cake cut (two output files) is not chainable; the preset
validator says so in plain text before anything runs.

### 5.22 Casting molds — negative molds & parametric blanks (R270–R273, vertical standing molds: R290)

Turns the **selected G-code file** into a printable casting mold (silicone,
soap, wax, plaster, resin) — or builds a **parametric blank mold** without any
source file at all. Everything lands in the `Molds/` folder
(`V<nn>_FormLinks_<name>.gcode` + `V<nn>_FormRechts_<name>.gcode` for the
vertical mold, `V<nn>_FormUnten_<name>.gcode` + `V<nn>_FormOben_<name>.gcode`
for the flat one, optional `V<nn>_Master_<name>.gcode` or
`V<nn>_FormObenA…_<name>.gcode`), numbered and never overwriting.

**How the file mold works (LCD: `Tools > Casting molds`)**

1. Select the source print in `Pre-Print > File info` (same workflow as Cake
   cut and Texture). Support, skirt, brim, prime tower and ironing moves are
   ignored automatically; the outer silhouette per Z band defines the cavity
   (enclosed through-holes cast solid — noted honestly in the console).
2. **Both halves print mating-face UP:** the parting face is the top surface
   of each block (the smoothest surface an FDM printer makes, zero cavity
   walls over air). The top half is mirrored in Y so you flip it over like a
   lid onto the bottom half; four dowel holes (`Pin D` + 0.3 mm clearance,
   default D3 mm = a piece of filament or M3 pin) sit at identical bed
   positions and align both halves.
3. **Pour channel, conical funnel & vents:** carved from the back face into
   the cavity's highest region, plus parting-seam vent grooves.
4. **Honest undercut & wall checks:** every half is checked layer by layer in
   pull direction. If the cavity shrinks toward the parting face beyond the
   tolerance gap (`Gap`, 0.05–0.30 mm), or if dowel holes do not fit `Wall`
   (`Pin D + 1.5 mm <= Wall`), or if the block exceeds the bed, the generator
   **refuses and writes nothing**, naming the exact layer or millimeter limit.
5. **3- and 4-part sector molds (R271):** `Sectors` (1 cut = 3-part, 2 cuts =
   4-part) splits the undercut half with vertical planes at the cavity thirds
   so outer pieces slide off sideways and the middle piece lifts straight up
   (registered by horizontal dowel tunnels; cavity ceiling bridges are counted
   and refused above 25 mm span).
6. **Surface modes (R272):** STANDARD (60 mm/s), FINE (parting face smoothed
   with 15% flow ironing passes + 20 mm/s print speed), or FUZZY (deterministic
   inward-only wall jitter up to 0.12 mm — matte cast, easier demolding, zero
   undercut penalty).

**Vertical standing molds (R290 — the tool decides the layout itself)**

With `LAYOUT=AUTO` (the default) the generator tries the **vertical
side-split mold first** — the professional figure mold:

* **The figure STANDS.** The source keeps its print orientation; the parting
  plane is vertical (perpendicular to X). The two plates **FormLinks** and
  **FormRechts** print mating-face UP like the flat halves and **open
  sideways** — no fighting a deep flat shell.
* **The pour sits at the TOP edge.** The pour channel and up to two vent
  channels are half-round grooves carved INTO both parting faces; assembled
  they form round channels from the seam's top edge into the cavity's highest
  region (the conical funnel widens the opening). The dowel registry and the
  parting-face vent grooves work exactly like the flat mold's.
* **The split position is computed, not guessed.** The object rasterizes into
  x-slabs (one per print layer); every (y,z) column's solid run must touch
  its plate's parting face — the intersection over all columns is the exact
  release window, and inside it the split rides the silhouette equator. A
  shape whose silhouette hooks in X (a dumbbell, a C-clip) has no such window
  and **refuses with the reason** — AUTO then builds the classic flat mold
  automatically. Master, pocket and sector requests are flat features and
  route the same way: **AUTO always lands on its feet.**
* `LAYOUT=VSPLIT` forces the vertical mold (a refusal stays a refusal),
  `LAYOUT=FLAT` pins the classic equator mold. With the vertical mold the
  **PLANE**/**z_off** knobs address the X axis (MID = the x middle, OFF = z_off mm
  from the object's smallest x).
* **Assembly:** lay the plates face to face like closing a book (FormRechts
  prints mirrored so the fold aligns), stand the pair up — the seam is
  vertical, the pour opening on top. Clamp or tape, pour, open sideways.
  Thin flat pieces (medallions, plaques) automatically stay with the flat
  mold — a side split needs a standing body (≥ 6 mm in X).

**Parametric blank molds & relief seat (R273 — LCD: `Tools > Casting molds > Blank molds`)**

No source file needed: pick MEDALLION (`Diameter` 15–100 mm × `Thickness`
4–25 mm), PLAQUE (`Plaque W` × `Plaque H` 20–150 mm, `Corner R` 0–12 mm), or
tapered BAR (`Bar L` 30–180 × `Bar W` 15–90 × `Bar H` 10–60 mm, `Taper`
0.50–1.00). With `Seat depth` > 0 (POCKET_T), a flat vertical-walled boss is
stamped onto the cavity floor so the cast gets a **flush relief pocket** in
its top face — drop a printed Lithophane, ColorPicture or StringArt tile onto
the boss before pouring and it embeds flush. Refuses honestly if the rim is
under 4 mm, the floor under 2 mm, or the boss lacks 2 cells of wall clearance.

Console: `MOLD_INFO`, `MOLD_CREATE PART=BOTH LAYOUT=AUTO PLANE=AUTO SURFACE=STANDARD`,
`MOLD_BLANK_INFO`, `MOLD_BLANK_CREATE SHAPE=MEDALLION DIA=50 THICK=10 POCKET_T=2`.

## 6. During the print: tuning, pauses, objects

Everything that happens between "print started" and "print finished". Live
tuning works in EVERY start mode — including AS SLICED and while plotting.

### 6.1 Live tuning reference

```
Speeds:  SET_GLOBAL_SPEED PERCENT=20..300 (never capped) — ONE global factor; the
         running feature's % re-applies on top immediately
Feature: SET_OVERRIDE_VALUE NAME=feat_spd_<code> VALUE= · NAME=feat_acc_<code> VALUE= · NAME=feat_on_<code> VALUE=1|0
         (16 feature codes) · SET_IRONING_FLOW PERCENT=
Accel:   SET_GLOBAL_ACCEL ACCEL= — the global accel; a feature with its own accel
         keeps it (feature beats the global)
Limits:  SET_LIVE_VELOCITY VELOCITY= (caps the FASTEST moves = travels) · SET_LIVE_ACCEL ACCEL= (global cap,
         travels included) · SET_LIVE_MINIMUM_CRUISE_RATIO VALUE= (each confirms "[OK] … -> Klipper") ·
         SET_LIVE_SQUARE_CORNER VALUE=
Z-Hop:   SET_Z_HOP ENABLE=1|0 HEIGHT=0.1..3 — lifts Z on every firmware retract (G10/G11), lowers
         before the unretract: nozzle-crash protection for towers, text, small parts
Pre-Print > Features > Custom Code / Overhang Wall / Internal Bridge /
Prime Tower carry the full set (On / File / Speed / Flow / Accel / PA)
like every feature; while a print runs the same five regulators sit in the
four Live quick lists.

Feature PA: SET_FEAT_PA FEATURE=<code> PA=<0..0.3> — pressure advance for ONE feature
         (e.g. wallouter 0.055, infillsparse 0.08); applied at every boundary of that
         feature, the global PA returns when it ends. 0 = off. LCD: Live Tuning > PA per feat > <feature>
Shaper: SET_FEAT_SHAPER_OFF FEATURE=<code> STATE=1|0 — input shaper OFF while that one
         feature prints (sharp corners on slow outer walls), frequencies restored when it
         ends and at PRINT_END/cancel (safety net _FEAT_TUNING_RESTORE). Needs [input_shaper]
         LCD: Live Tuning > Spd per feat > `ShpOff: …` (row below FeatOn) — it acts on the
         feature that prints RIGHT NOW, the label shows `off`, `ON @ <feat>` or
         `n/a (no shaper)`. One press = shaper off/on for that segment.
Fan LIVE: SET_FAN_LIVE PERCENT= — YOUR absolute fan %, it beats
         everything: hold, scale, clamp AND the layer-1 fan-off rule (you turned
         the dial). SET_FAN_LIVE ON=0 hands control back to the file. LCD:
         Live Tuning > Temps & Fan > `Fan: NN% (LIVE)` + the LIVE on/off row;
         `How? (fan math)` prints the whole chain with the live numbers.
         Chain (strongest first): LIVE > layer-1 fan-off > HOLD > SCALE > CLAMP.
Fan curve: SET_FAN_CLAMP ON=1|0 MIN=0..100 MAX=0..100 BRIDGE=0..100 — every M106 of the
         file runs clamped between MIN/MAX percent (a file that wants 100 % gives 90 %), BRIDGE
         lifts the fan while a bridge section prints (0 = off). .126: clamp changes apply
         IMMEDIATELY (they used to wait for the file's next M106 — generated files send ONE per
         print, nothing ever visibly changed) and the BRIDGE boost fires at the feature boundary
         itself (files send M106 at the layer start, never at the bridge), restoring the file
         value when the bridge ends. LCD: Live Tuning > Temps & Fan > Clamp/FMin/FMax/FBrdg
Drive: SET_EXTRUDER_DRIVE TYPE=DIRECT|BOWDEN — the retraction STARTING-POINT profile
         (direct 0.6mm @ 40mm/s + z-hop off / bowden 4.5mm @ 30mm/s). Only a starting point:
         length, speeds, unretract extra + z-hop stay freely editable in BOTH directions,
         pre-print and mid-print. Independent from RetractFix (that repairs old FILES).
         LCD: Pre-Print > Velocity > Retraction > Drive
Unretract: SET_UNRETRACT_EXTRA EXTRA=-1..3 — every unretract adds EXTRA mm of filament
         (seals the dot after a travel; 0 = off). Firmware retraction only
Extrusion: SET_FLOW_RATE PERCENT=1..300 · SET_LIVE_PRESSURE_ADVANCE VALUE= ·
         SET_LIVE_PA_SMOOTH TIME= · SET_LIVE_RETRACTION LENGTH= SPEED= UNRETRACT_SPEED= EXTRA=
Temps:   SET_LIVE_HOTEND_TEMP T= · SET_LIVE_BED_TEMP T=
Fan:     SET_FAN_LIVE PERCENT=/ON= (your absolute %, beats all) ·
         SET_FAN_SCALE (25–150 % × the file value)      Babystep: BABYSTEP_UP/DOWN[_FINE]
Objects: SKIP_OBJECT NAME=name (2x) · SKIP_CURRENT_OBJECT · SHOW_OBJECTS
Compat:  SET_INNER_WALL_SPEED / SET_INFILL_* remain feature-less (inner wall and
         infill print 1:1 - use the global factor)
```

SET_LIVE_RETRACTION mirrors all four values in _STATE — the LCD shows LIVE
values and changing one parameter never clobbers the others.

**Where does a value come from?** `PARAM_SOURCES` (LCD: Live Tuning >
Sources) prints the full provenance for every parameter: **file | your
pre-print override | LIVE in Klipper now** — including PA, velocity, min
cruise ratio, corner velocity, flow, retraction, fan and the L1/L2 temps. The
LCD inputs for flow/accel read the LIVE Klipper values, so a change made in
Mainsail shows on the display and vice versa. Each quick menu opens with a
title row (**== SPEED ==**, **== ACCEL ==**, **== PRESSURE ADV ==**,
**== FLOW ==**) so you always know which flow you are in, followed by the
**Now:** line naming the feature that is printing right now. Editing a
feature's own value happens in that feature's row of the list below — one
place per setting, not two. The **FeatOn** switch (Speeds / Accels) flips the
feature that is printing right now; if nothing feature-marked is printing
(raft or unmarked section) it says so instead of silently doing nothing.

**Feature overrides the file cannot use:** at the print start every enabled
feature override whose type is not in the file (TYPES from the file info) is
parked for this print — the console lists them ("Not in this file (overrides
parked for this print): …"). Your switches stay intact for the next file that
really contains those features.

**One global factor.** LCD > Live Tuning > Spd/Acc per feat has exactly one
global entry each (Glob % / Acc) — works on EVERY file, in both takeover
modes and AS SLICED alike. Switch features off individually (never as a
burst — the safe way on a small Pi).

### 6.2 All pauses explained

Every pause parks the same safe way (6.4). They differ in WHEN they fire:

| Pause | Trigger / Condition | After |
|---|---|---|
| User pause | LCD "PAUSE NOW", PAUSE, QUICK_PAUSE, M0/M1 (slicer) | parked, waits for RESUME |
| Start dialog hold | file calls PRINT_START | AS SLICED / AS LEGACY / CANCEL |
| Planned: next layer | PAUSE_NEXT_LAYER | fires at the next boundary; one-shot |
| Planned: at layer N | PAUSE_AT_LAYER LAYER=n (n>1) | one-shot at layer n |

Planned pauses are **cleared at every PRINT_START** — a leftover plan from an
earlier print can never fire right after the purge line of the next one (the
console notes it when something was cleared).
| Runout | sensor empty → next layer boundary → filament mode | load → RESUME purges |
| Filament change | M600 / CHANGE_FILAMENT (printing or idle, heats ≥200 °C) | filament mode; RESUME purges |
| Legacy dialog | old file detected, start_confirm ON | asks AS SLICED / AS LEGACY / CANCEL within seconds (M190/M109 only preheat in the background while it waits) |
| Legacy prep | old file + AS LEGACY, "Old files" ON — once per file | homes, heats bed, meshes, heats to L1 (file value > preset), purges, L1 speed — then GAPLESS continue (pause position restored, no park/return dance, no ooze). Anti-ooze: a hotend already at print temp drops to 170 °C standby during bed + mesh and re-heats for the purge |
| Sequential object | Z falling edge (high-water ≥1.6 → <0.75 mm), layer ≥2; z-hops ≤1 mm are un-ratcheted and never trigger | L1 temps + L1 speed; pauses only if a heater must move, then self-resumes |
| Cancel 1st press | CANCEL_PRINT once | arms; 2nd press within 60 s cancels; RESUME disarms; the arm expires after 60 s — printing OR paused |

**While paused:** heaters KEEP targets · idle timeout "infinite" · filament
sensor disabled · LCD shows the reason. Self-healing: if our mode
disagrees with Klipper, the watcher re-syncs after ~5 s.

### 6.3 Resume & cancel

**RESUME — step by step**

1. disarms cancel/skip confirmations
2. returns XY first (safe height), then Z slowly (F300)
3. re-primes ooze compensation (E3 + E0.8 slow) if the hotend is hot
4. re-enables sensor, restores idle timeout
5. re-applies the current feature type (APPLY_TYPE)
6. **re-applies the L1 speed brake while layer 1 runs** — in AS SLICED the
   brake stays OFF (the file rules 1:1 there); it guards LEGACY prints whose
   L1 speed override is armed
7. sound + continue; held files continue via M24

**CANCEL_PRINT (2×):** 1st press pauses + arms; 2nd press within 60 s: lift,
park, heaters off, stats, sad sound. The arm expires after 60 s — printing OR
paused: a forgotten first press can never become an instant cancel later.
Override switches stay as you set them.

**After EVERY end — cancel, PRINT_END, or a legacy file finishing:
_PRINT_CLEANUP** resets all per-print state: cancel/skip/mesh arming, legacy &
as-sliced flags, file type, file-held flag, pause bookkeeping, live tuning
(M220/M221 → 100 %), planned pauses, layer tracking. Deliberately KEPT: your
pre-print settings, the selected material and the loaded bed mesh. The next
print starts CLEAN.

### 6.4 Parking & safe movement

- lift +5 mm, capped below Z max — never rams the frame
- XY to the corner FARTHEST from the objects (file polygons; fallback front
  left)
- anti-ooze retract −3 mm only if the hotend is ≥170 °C
- sensor off, idle timeout infinite
- every move checks homed_axes — unhomed axes are never moved
- Z high-water re-anchored at PAUSE and at every object start — parking can
  never fake an object change

**Homing — when what moves, and who guards it**

- Every start path homes first (G28) — before bed heat, mesh, hotend and
  purge. Afterwards the gantry can sync itself (SYNC_GANTRY — [force_move]
  required; toggles for boot/print start).
- Z offset lives in the probe: Leveling > probe offset (paper method, TESTZ
  ±0.04/±0.12) → SAVE_CONFIG.
- Babystepping during a print (SET_GCODE_OFFSET Z_ADJUST MOVE=1) is
  runtime-only — the saved offset never changes.
- Guard rail: every park/move macro checks homed_axes — unhomed axes never
  move; PAUSE, M600, M0/M1 inherit the same guard.
- START_PRINT (the old macro name): marked files = no-op (PRINT_START prepared
  everything); legacy files = REAL legacy start (home/heat/purge) — old mod
  files depend on it.
- "Must home axis first": the real error is usually ABOVE it in the console
  (ch. 22).

### 6.5 Skipping objects & ending a print early

**Skip a single object** (multi-object prints): Live Tuning > Objects (or
`SKIP_OBJECT NAME=name`, 2× confirm — `SKIP_CURRENT_OBJECT` skips the one
printing right now, `SKIP_DISARM` cancels a pending skip, `SHOW_OBJECTS`
lists all objects with their state). The rest of the print continues; KAMP's
adaptive mesh and the smart parking already know the remaining objects. Works
for sliced multi-object files AND for generated files (labels, ranges,
bridging towers — every generated part is an exclude object).

**End the print normally at a planned layer:** Pre-Print > Range/Stop >
**Stop@ N** (or Live Tuning > Pause & Control > Stop@) — when layer N begins, the
print ends like a FINISHED print: park, stats, fanfare, cooldown — not a
cancel. Combined with the range generator (ch. 5.1) this covers "print only
part of it" in both directions: from the file start up to N, or a standalone
section From–To.

## 7. Filament: load / unload / change / runout / cold pull

- temperatures always right: print temp kept during prints; idle heats ≥200 °C
- load_length 60 mm (LCD 20-150) feeds LOAD_FILAMENT · unload_length 90 mm
  (LCD 40-150) feeds unload AND change — both settable
- **color-change purge:** the 15 mm flush after a change lands as a FLAT
  0.3 mm strip beside the objects (front edge, probe-safe window) — never as a
  blob at the park corner where the micro probe would catch it on the next
  mesh. PURGE_MORE lays another strip the same way.
- repeat runout events while armed are ignored
- **BTT SFS V2.0 (two-part sensor):** switch part `[filament_switch_sensor
  filament_sensor]` = filament end → alarm + planned pause at the layer boundary
  (direct drive still has filament); encoder part `[filament_motion_sensor
  encoder_sensor]` = clog/tangle → immediate safe PAUSE (a clog cannot wait).
  `SET_FILAMENT_SENSOR` takes the SECTION name — the `switch_sensor` from the
  BTT example is INVALID if your section is named `filament_sensor` (it aborted
  the whole runout chain). PAUSE/RESUME/CANCEL also
  switch the encoder part (guarded) — the clog protection survives runouts.
- **Cold pull** (Maintenance > Filament): Heat-to (PLA ~240) / Pull-at (PLA ~100,
  PETG/ABS 120-140) → "1) Prep + PULL" heats, extrudes 25 mm, fan-cools → ALARM
  → pull in ONE firm motion → "2) Finish" verifies. Idle only.
- **Retraction test:** retract/unretract pairs at temperature to compare stringing

## 8. Temperature system L1/L2

- **Two temperatures per heater:** Layer 1 (L1) and from-layer-2 (L2).
  **One priority ladder for BOTH: your override (ON) > file value >
  material preset** — what stands at each layer:
  - **L1**: the start paths heat to your L1 override if armed, else the file's
    own first-layer value, else the material preset (when L1 rules are ON).
  - **L2**: at the layer-2 boundary the system switches to your L2 override
    if armed, else the file's own layer-2 value (from its M104/M140 or the
    file info), else the material preset — **in BOTH start modes**, marked
    files (LAYER_MARK) and unmarked ones (Z tracker) alike. Generated and
    range files (no own M104/M140) switch through the material preset too —
    the bed no longer stays at its layer-1 value (field fix .121).
- purge + layer 1 = L1 (the start paths heat the hotend to the L1 value for the purge)
- **Interceptors:** file M104/M109/M140/M190 are handled BY LAYER —
  - **AS LEGACY**: layer 1 → L1 value; layer ≥ 2 → your armed L2 override
    rewrites the command, otherwise the file's own value passes unchanged.
  - **AS SLICED**: layer 1 → the first-layer rules (material preset) shape it,
    your armed override wins if set; layer ≥ 2 → truly 1:1 (the file's own
    command stands) — except your armed L2 override, which still wins
    (`M104: 215C -> YOUR L2 override -> 240C (AS SLICED, layer 2)`).
  - Every rewrite is idempotent (only written when the target really moves
    > 0.5 °C) and logged once on the console.
- layer 2 = L2 — switched by LAYER_MARK (marked) or the Z tracker (legacy / AS
  LEGACY), identical values; the held layer-1 fan comes back at the boundary
  (`M106 S<file value>`) and your material fan scale re-applies
- sequential: every object restarts with L1
- live temps: `SET_LIVE_HOTEND_TEMP T=` / `SET_LIVE_BED_TEMP T=`
- idle filament handling heats to ≥200 °C (or preset)

**Safety:** heaters off at print end + on shutdown/cancel; pauses keep targets on
purpose; hotend fan cool-down (cooldown_fan_time, 30 s default).

## 9. Speed, acceleration & machine limits

**First-layer speed (default 75%, 0 = off)**

- global M220 brake during layer 1 — set at the start, re-applied after EVERY
  resume (Klipper restores the speed factor from pause time — that back door is
  closed) and at every object change
- the file's own M220 commands are capped to the limit while layer 1 runs
- AS SLICED: not applied · restored at layer 2 (marker or Z-tracked)

**Global = the ONE overall regulator (one model, all three parameters):**

- **Speed:** global % (LCD, L1 brake, file M220) scales everything — stored
  clean as `g_speed_clean`, never multiplied by anything else. Feature speed
  = percent **x global** (global 80 + wall 80 -> wall runs at 64, the next
  feature is back at 80 — no decay). Example: feature base 60 mm/s, feature
  200% -> 120; global 150% -> 180 mm/s, feature stays 200%.
- **Flow:** the exact same shape. Global flow (SET_FLOW_RATE / pre-print
  override) is the one regulator; a feature flow % always **refers to the
  global**: global 98% x feature 110% = 107.8% effective. Raising the global
  raises every feature's effective flow with it — the feature percentages
  themselves never move — a feature flow always MULTIPLIES with the global.
- **Accel:** feature values are **hard limits** (absolute mm/s²) — the global
  accel never overrides them; it rules everything without its own feature
  accel (travel/unknown). ON TOP of that there is ONE global percent scaler
  (`Feat x%`, `SET_GLOBAL_ACCEL_PERCENT PERCENT=150`) that scales ALL feature
  limits in the same ratio (1500 at 150%) without touching the global accel —
  Live Tuning > Acc per feat shows the current feature's effective value live
  (`Eff: 1500mm/s2`), and Live Tuning > Extrusion > Flow sources shows the flow model.

Two rules keep it intuitive when BOTH are set: every global change re-applies
the running feature on the spot (global 100 -> 150 with wall at 200% moves
the wall from 200 to 300%, not back to 150), and a feature with its own accel
KEEPS it — the global accel rules everything that prints without one.

**Why the redesign (field log):** the old
APPLY_TYPE ran through the M220 interceptor — 75% brake x 80% wall multiplied
on the ALREADY scaled factor, feature by feature: 75x80 -> 60 -> 48 -> ... ->
19%. Since then feature values go straight to Klipper via the BASE commands
(M99220/M99221/M99204) — the interceptor (and with it the global value) is
never touched by a feature.

**16 features:** outer/inner wall, overhang wall, sparse/solid infill,
top/bottom surface, bridge, internal bridge, gap fill, support, ironing
(+own flow), skirt, brim, prime tower, custom code — every one with its OWN
ON switch + speed % + accel (Pre-Print > Features, one submenu each) — and
live in the four quick lists of Live Tuning, which show the CURRENTLY
printing feature as "Now:" and toggle its override with FeatOn. Post-processor v4 maps every slicer family's
;TYPE: spellings (census table in ch. 3) — since R95 including Overhang
perimeter, Internal bridge, Prime/Wipe tower and custom G-code sections.

**Originals, availability & OFF-reset:** the post-processor MEASURES the
real values from the g-code itself — the most frequent F value per feature
segment (= its speed in mm/s) and the M204 in effect there (= its accel).
They are shown everywhere (the "File:" rows in Spd/Acc/PA per feat)
and they are what "OFF" returns to: switching a feature override OFF resets
the stored speed to 100% (= 1:1 with the file × global) and the stored accel
to the file's M204 (0 if the file sends none). Only features that really
occur in the file are editable — the activator rows of absent features show
"n/a" and every input refuses with "not in this file" (unknown/legacy files
without TYPES data stay fully editable as before).

**Machine limits**

| Parameter | Override (Pre-Print > Velocity) | Live command | Klipper setting |
|---|---|---|---|
| Max acceleration | accel (ON + value) | SET_GLOBAL_ACCEL | max_accel |
| Max velocity | velocity (ON + value) | SET_LIVE_VELOCITY | max_velocity |
| Minimum cruise ratio | min_cruise (ON + value) | SET_LIVE_MINIMUM_CRUISE_RATIO | minimum_cruise_ratio (replaced a2d) |
| Square corner velocity | square_corner (ON + value) | SET_LIVE_SQUARE_CORNER | square_corner_velocity |

Overrides apply at print start ONLY when ON + value > 0 — everything OFF means
Klipper's [printer] limits and the file rule untouched (no forced 4000 anywhere).

## 10. Calibration — the ladder to good prints

Calibration only works in the right order: every step builds on the ones
before it (flow measured with a wrong E-step or unshaped motion is simply
wrong). The Maintenance menu on the LCD follows this ladder top to bottom —
walk it in menu order and you walk it correctly.

```
ONCE PER PRINTER                     PER MATERIAL
────────────────                     ───────────
1. PID tuning          ──┐           6. temperature tower
2. leveling (Z offset)  ─┼─ layer 1  7. pressure advance (+ smooth time)
3. bed mesh check       ─┘ looks right8. flow (extrusion multiplier)
4. extruder steps       ──┐          9. retraction
5. input shaper         ──┴─ motion  10. bridging
   is honest                        11. ironing card
```

### 10.1 PID tuning (Maintenance > PID Tuning)

First — everything temperature-dependent needs stable heaters. Hotend at
print temp WITH the part fan % it will actually run (own submenu), then bed.
`TUNE_PID HEATER=extruder TARGET=215 FAN=100` / `TUNE_PID HEATER=heater_bed TARGET=60` (FAN = the % the part fan will run at).

### 10.2 Leveling (Maintenance > Leveling)

Probe Z offset by the paper method: TESTZ ±0.04/±0.12, accept → SAVE_CONFIG.
Bed screws: turn per the console report (screws_tilt_adjust). This is what
makes layer 1 look right — do it before any material calibration.

**.136n — the bed-screw round, guided on the LCD (Mainsail's flow):**
Maintenance > Bed Screws > `Start` homes, raises the probe and moves to
**screw 1 (the base)** — then `Next` walks you from screw to screw, the
LCD showing `current screw → next` and the measured deviation of the
CURRENT position in clock notation (`01:20` = one full turn + 20 minutes;
CW/CCW = which way to turn). Turn the screw, press `Next`, repeat
until the display says `:ok` — `Round` starts a fresh measuring round,
`Done` ends with the report (max deviation named), `Cancel` leaves
without saving anything. The base screw shows `:base`; a screw within
0.001 mm of nominal reads `00:00`. The console keeps the full report.

### 10.3 Bed mesh (Maintenance > Bed Mesh)

A fresh mesh runs at EVERY print start (at bed temp). ADAPTIVE over the
real objects needs the file's object data — and object processing ON
(files without it get a full-bed mesh; on the Pi Zero 2 W OFF is the
recommended compromise, ch. 19b). Here you set: Mesh ON/AUTO/OFF, adaptive, travel cap while meshing,
save/load profiles. A mesh check print (Leveling) shows how the first layer
sits — details in ch. 6.

### 10.4 Extruder steps (Maintenance > Extruder Cal.)

Mark 120 mm → extrude 100 → enter what is left → the calculator sets the
rotation distance. Do this BEFORE flow and PA — both assume the extruder
moves exactly what it is told.

### 10.5 Input shaper (Maintenance > Vibration Cal.)

The motion foundation — PA and flow tests at speed are meaningless with
resonances in the data.

1. **Calibrate X / Y / X+Y** (`CALIBRATE_SHAPER AXIS=…`, frequency range and
   max smoothing editable) — the accelerometer records, Klipper recommends.
2. **Diagram (print) / (plot)** (`RESONANCE_DIAGRAM MODE=PRINT/PLOT`): builds
   a plate (or pen plot) per axis with the PSD curve, all 5 shaper response
   curves, the peak marker with Hz and the SHAPER TABLE (shaper / freq /
   remaining vibrations / smoothing) — the recommended shaper is boxed and
   marked OK. The print runs through the NORMAL start procedure.
3. **Apply result > X/Y > shaper** — the stored frequency of that shaper is
   applied, SET_INPUT_SHAPER runs live AND is saved as the boot override
   (survives every restart, printer.cfg untouched). No math, just pick.
4. **Manual** (Maintenance > Vibration Cal. > Manual) — the same thing
   WITHOUT an accelerometer. Steps 1–3 need `[resonance_tester]`; Manual only
   needs `[input_shaper]`. The status row says what Klipper RUNS now and what
   the override holds. Per axis:
   - `Override: ON/off` — one press switches the manual override off (back to
     the printer.cfg value) or on again with the stored type + frequency.
   - `Shaper` — ZV / MZV / EI / 2HUMP_EI / 3HUMP_EI (take the best row from
     your printed diagram or the SHAPER TABLE) or `printer.cfg`, which
     restores the file's type, frequency AND damping ratio and turns the
     override off.
   - `Freq` — 5 … 200 Hz in 0.5 Hz steps, pre-filled with the value in use.
   Every pick runs SET_INPUT_SHAPER live and stores the boot override
   (`ishaper_ov_*`, re-applied at every start). Refused: an unknown type or a
   frequency outside 5–200 Hz — the LCD says so instead of silently doing
   nothing. Without an `[input_shaper]` section it says there is nothing to
   set (an unshaped printer has no shaper to override).
5. Console: `SHAPER_RESULT` (table), `SHAPER_RESULT AXIS=X TYPE=MZV`,
   `… TYPE=EI FREQ=58` (manual fine tuning). The fit is a faithful port of
   Klipper's shaper_calibrate (ZV/MZV/EI/2HUMP/3HUMP).
   `SHAPER_MANUAL AXIS=X TYPE=MZV FREQ=52` = the Manual menu from the
   console; `SHAPER_MANUAL AXIS=X TYPE=CONFIG` = back to printer.cfg,
   `SHAPER_MANUAL AXIS=X ON=0` = override off only.
6. Recalibrate after mechanical changes (the status line at the top of the
   menu shows the active shapers + frequencies).

### 10.6 Temperature tower (Maintenance > Temp Tower)

Per material, FIRST — the right temperature is the base for PA, flow and
retraction. Two ways:

- **Band control on a sliced tower:** Start/End/Step/Band adjustable, "Plan
  (calc)" shows the band plan, "Start tower" changes the hotend temp every
  BAND layers (works with marked AND legacy files), "Stop tower" ends it.
- **Generated standalone tower ("Print tower"):** no sliced file needed —
  blocks × BLOCK_HEIGHT, one temperature per block. The TOWER steers the
  hotend directly while it runs (SET_HEATER_TEMPERATURE — no interceptor
  interferes, your overrides stay untouched); AFTER the tower, "Best"
  optionally adopts the winning block as the hotend override (L1+L2, ON).
  Fan %, mesh + prime included.

### 10.7 Pressure advance (Maintenance > PA Cal.)

The Orca-style line test, generated on the printer: all parameters editable
(temp/bed/start/step/lines/len/slow/fast/accel/layer/spacing + velocity,
cruise ratio, corner, retraction len/spd/unretract, flow — synced with
Pre-Print/Live Tuning), mesh first. Read the best line → "Best line" sets the
PA override. Babystepping stays available.

**.136n — Pattern & base:** `PATTERN=LINES` (the classic line test) or
`PATTERN=ANGLE` (a 5-stroke sawtooth that auto-fits the bed — for judging
PA on corners and direction changes). **BASE 0–10 layers**: an optional
solid base under the pattern (3 by default) so the test sits on real
plastic — 0 prints directly on the bed for cold/quick runs. Every pattern
prints inside a **2 mm frame** (also on the base) — the enclosure marks
the test area, the nozzle never leaves it, and the frame walls make the
corners readable. LCD: PA Cal. > Pattern (toggle) + Base (0–10); console:
`CALIBRATE_PA PATTERN=ANGLE BASE=3`.

**PA Smooth Cal.** (own submenu): PA prefilled + editable, smooth time
0.020–0.200 s in 0.010 steps (19 lines — the TOWER's test range; the
running default is 0.04 s) — "Best line" → smooth override ON.
Both calibrations run with YOUR motion parameters.

### 10.8 Flow (Maintenance > Flow Cal.)

"Print cube" GENERATES the single-wall cube — SIZE/HEIGHT/LAYER/FLOW% in the
menu, FLOW% baked into E (independent of the flow override), mesh + prime +
your motion values included. Then: measure the wall, Wall: value GO →
suggested flow % → Apply flow (override ON).

### 10.9 Retraction (Maintenance > Retract Tower)

GENERATED two-mast tower: the retract length rises block by block
(slicer-style `G1 E-` retracts — the deliberate exception to the G10/G11
generator rule: a retract TEST must send real retract moves). Params:
START/STEP/BLOCK/BLOCKS/DIST (mast distance)/TOWER (mast size)/
RETRACT_SPEED/LAYER/SPEED/TRAVEL_SPEED + temps; mesh + prime included.
"Best" → the block's retract length becomes the retract override (ON).

### 10.10 Bridging (Maintenance > Bridging)

GENERATED test: LEN (long span, default 160 mm), SHORT % (10–50 % of it),
tower heights, tower size, bridge layers, bridge speed, bridge fan %.
"> Create file" builds `Bridge_<len>mm_<pct>pct.gcode`: two tall towers
diagonally across the bed with the long bridge on top, plus one additional
SHORT span at SHORT % hanging clearly BELOW the long bridge on its own lower
tower — inspect both sags from the side. Normal start procedure, every tower
+ bridge is an exclude object. All bridging parameters are live: Live Tuning >
Features > BRIDGE (speed %), fan, flow.

### 10.11 Ironing card (Maintenance > Ironing Cal.)

CARDS cards (1–6, sizes auto-fit), each on BASE base layers — ironing starts
on layer BASE+1 (BASE 4 = ironing only after 4 solid layers, like a real top
surface). Each card = one flow%/speed pair (default F10/S20 … F20/S40; cards
4–6 via console F4/S4…F6/S6). Mesh + prime included. "Best" → ironing speed +
flow overrides ON.

### 10.12 The per-material recipe

1) temperature tower → 2) pressure advance → 3) PA smooth time → 4) flow →
5) retraction → 6) bridging → 7) ironing card → **Save as preset**
(Pre-Print > Material — a preset stores pa_smooth + unretract speed too).
Print a small model of the material's real use case between steps; the
generators make that cheap (a flow cube, a 30-layer range of a known file).

## 11. Bed mesh & KAMP

**The mesh strategy in one line:** a fresh, adaptive, at-temperature mesh at
every print start — never a stale saved one.

**What runs at print start (AS LEGACY, or marked files with mesh ON):**

1. bed heats to target first (mesh at temperature, not cold)
2. the mesh calibrates ADAPTIVELY over the real print area — with
   `EXCLUDE_OBJECT_DEFINE` data in the file, KAMP's adaptive meshing bounds
   the mesh to the objects (plus `adaptive_margin`, default 5 mm); without
   object data the full bed is meshed (console: "No objects detected! …
   Defaulting to regular meshing")
3. "Old files" ON: legacy files get the mesh too; OFF: homing → heat → purge
   → overrides only
4. Travel cap (Pre-Print > Bed Mesh): limits the speed WHILE meshing (default
   off) — a courtesy for the mechanics, the mesh quality does not depend on it

**Menu: Pre-Print > Bed Mesh / Maintenance > Bed Mesh** — Mesh ON/AUTO/OFF ·
Save after · Adaptive · Travel cap · Calibrate now · Load…/Delete… (profiles).
"Save after" stores the mesh as a profile at print end — useful if you
deliberately want to reuse one (e.g. for repeated small parts).

**KAMP settings (Maintenance > KAMP)** — the menu shows active/missing:

| Entry | Effect |
|---|---|
| KAMP mesh: ON / native | ON = adaptive meshing over the objects; native = Klipper's own full-bed mesh |
| KAMP purge: ON/OFF | replaces the own purge line with KAMP's |
| > LINE purge / > VORON purge | KAMP's line or the Voron-logo purge |
| Smart Park: ON/OFF | parks the nozzle inside the mesh area, warmed, instead of the corner |

**KAMP purge vs the own line:** KAMP's LINE purge is NOT probe-offset aware —
with a side probe offset > 10 mm it is skipped automatically (console says so)
and the probe-safe own line (ch. 6) runs instead.

**Adaptive mesh and exclude_object:** the object list is rebuilt at every
file OPEN (Klipper clears it) — skipped objects leave the mesh bounds cleanly
during a running print; the mesh stays as it was calibrated at start.

## 12. Purge / prime line

The prime line is what makes layer 1 clean: a wiped nozzle, a refilled molten
pocket and a fat line that proves flow before the part starts.

**The chain (every purge, own line and KAMP line/logo):**

1. **Nozzle wipe first** (`_NOZZLE_WIPE`): heat to 180 °C if the nozzle is
   cold, fast zigzag on the front-left silicone pad (X0–13 / Y0–13, max 4 mm
   down, 2 passes), then the nozzle parks HIGH again before the line is drawn.
   CLEAN_NOZZLE (Maintenance) does the same standalone; called cold it turns
   the heater back off afterwards.
2. **Flush 6 mm** (E F150) after a 3 s heat soak — refills the molten pocket
3. **Fat line** up to 110 mm, 1.2 mm wide (E from layer height) at F1200 —
   wipes the nozzle
4. **Retract −2.5 mm** — no blob on the first perimeter

The part fan is switched OFF after every purge — a cool-down fan from the
PREVIOUS print (PRINT_END runs it 100 % for 30 s) can no longer bleed into
the new first layer.

**Probe-safe geometry:** the line runs along X, STARTS at the RIGHT end and
is drawn toward x=0; Y only ever increases. The [probe] x_offset/y_offset is
respected — nozzle AND probe stay inside the bed with a 5 mm margin, so a
side-mounted probe can no longer slam into the bed frame. Placement: the
option with the LONGEST line wins — front strip 10 mm below the objects, left
of them, or right of them. `_PROBE_STOW` runs first — BLTouch/CR-Touch need
nothing, Klicky/Euclid users uncomment their DOCK_PROBE there.

**Edit spots:** 08 `_PRIME_LINE` (flush, width, length, margin) +
`_PROBE_STOW` (dock hook).

KAMP purge (LINE/VORON) replaces the line when enabled — see ch. 6.

## 13. Maintenance & care

The care side of the Maintenance menu — after the calibration ladder (ch. 9)
follow the care entries top to bottom.

**Clean Nozzle** — heats to 180 °C, zigzag wipe on the silicone pad
(X0–13/Y0–13 at max Z4, 2 passes), parks high. Runs in EVERY purge chain
automatically; standalone here for between prints.

**Filament** — load / load length / unload / unload length / change (M600);
also available before the print in Pre-Print. **Cold pull** lives here
(Maintenance > Filament): heats, pulls the filament cold to drag dirt out of
the nozzle — the classic fix for partial clogs and stringing after a material
change. Sequence: heat to the material's pull temp, advance fresh filament,
cool below the softening point, pull.

**Z Gantry Sync / Z Tilt** — the menu shows exactly what THIS printer has:
ONE Z stepper (or parallel-wired motors on one driver) → **Z Gantry Sync**
re-syncs both Z motors to a common zero (SET_KINEMATIC POSITION via
[force_move]); 2+ Z steppers → **Z Tilt** runs Klipper's Z_TILT_ADJUST over
the [z_tilt] probe points instead. Both have toggles for boot and print
start, Z Tilt additionally retries (0–5) and retry tolerance (0.005–0.2 mm)
— Maintenance > Z Tilt. Run either after mechanical work on the gantry or
when the X gantry visibly tilts. Z_TILT refuses politely (with a setup hint)
when [z_tilt] is missing from printer.cfg.

**KAMP** — mesh/purge/smart-park settings (ch. 6).

**Tests** — sound demo, self test, status: verify actuators after
wiring changes without heating anything.

**Regular checks (recommended rhythm)**

| When | What |
|---|---|
| every print | glance at layer 1 (purge line + first perimeter tell the whole story) |
| weekly / after ~1 kg | clean the nozzle, cold pull if stringing increases, check the bed for residue |
| monthly | belt tension (ping test), V-roller play, PTFE tube seat at the hotend, screws on the gantry |
| after any mechanical change | re-run the calibration ladder from step 5 (input shaper) — and steps 1–2 if the hotend or bed moved |
| after a heater/fan change | PID tuning again |

## 14. LCD menu reference

Seven top groups — in LCD order: **Start Print?** (appears in the waiting
state, position 1), **Live Tuning** (during a print, position 2), then
Pre-Print, Quick Macros, **Tools** (the six part generators:
Cable ties · Angles+Flat · Lithophane · ColorPic · Gaskets · Labels ·
Bricks (catalog, kit, figures) · Plotter · String art, each with its own sub-menu — plus **After gen** (QUEUE/PREVIEW, .84): what
happens to every generated file, see 5.0),
Maintenance, System. Klipper's own stock menus OctoPrint, Temperature and
Setup are hidden — everything they do exists in the R2 menus; **SD Card**
is Klipper's own list again (the G-Codes root, no subfolders, stock
Start/Resume/Pause/Cancel), **Control** and **Tune** stay. Start dialog and
live tuning sit right at the top. Every line fits the 16 characters
of the 12864 display — the value you edit is always visible (test-enforced).

**SD Card = Klipper's list, with EVERY folder in it.** The folder browser we
built stays PARKED (it kept its own copy of the whole folder tree inside
Klipper, and the display side of it could block the Reactor at exactly the
wrong moment at print start) - but the flat stock `vsdlist` is not a
limitation any more: the post-processor mirrors **every printable file of a
subfolder as a link in the gcodes root** (up to 200, three levels deep,
`<subfolder>_<name>.gcode` on a name clash; a real root file always wins, dead
links are swept, `.stl.gcode`/`.obj.gcode` exports never appear). Klipper opens the link
directly, so the stock list holds the whole library and M23 (our takeover of
the file tap) routes the pick into the normal start dialog. Nothing is copied
and nothing is moved - the file keeps its folder. Additionally, the two
folders a print actually comes from are one press away as submenus of SD
Card:
**Optimized** (the tuned library, 40 slots) and **Generated** (every
generator output, newest first, 20 slots). Nested folders, deleting and
paging = Mainsail; the generators themselves do not care where the display
looks — they write the same folders as before. Everything the browser
needed is still in the code base, switched off in ONE place (the switch
SD_BROWSER_ON in tools/r2_postproc.py plus the enable: {False} rows in
menus/lcd_menues.cfg), so it can come back without a rewrite.

#### The links in the root — how they work, what to watch

A **symbolic link** is not a copy. It is a tiny entry (a few dozen bytes) that
says "the file you mean is *over there*". For a file
`gcodes/Frames/V05_Frame_MINI_FLATx4.gcode` the post-processor creates
`gcodes/Frames_V05_Frame_MINI_FLATx4.gcode` as a link. The bytes of your
print still live in `Frames/`, in the same file, not touched, not moved:

```
gcodes/
├── Frames/                                  ← your file, unchanged
│   └── V05_Frame_MINI_FLATx4.gcode          ← the real 4.2 MB
└── Frames_V05_Frame_MINI_FLATx4.gcode       → link (points into Frames/)
```

What follows from that:

- **Deleting the link does NOT delete the print.** It disappears from the
  root list and comes back on the next pass of the watcher (the links are
  rebuilt every scan). To really delete, delete the file in its folder —
  on the LCD: SD Card > the submenu (**Optimized** / **Generated**), or in
  Mainsail under **Dateien → folder**.
- **Deleting the file makes the link dead.** The watcher sweeps dead links
  every pass, so the stale entry cleans itself up. Nothing else breaks.
- **Editing/starting a link edits/starts the original** — that is the point:
  one file, shown in two places. Do not be surprised that the mtime of the
  original changes after a print.
- **A real file with the same name always wins.** If you ever put a real
  `Frames_V05….gcode` in the root, the link is not created; the root copy is
  what prints.
- **Limits on purpose:** max 200 links, three folder levels deep, name clash
  → `<subfolder>_<name>.gcode`, `.stl.gcode`/`.obj.gcode` exports never appear (they are
  not print jobs). The watcher never processes a link (it would re-tag the
  original through the link on every pass) — the original is processed in its
  own folder, once.
- **Mainsail/Auto-refresh:** yes, the file list refreshes constantly — that
  is moonraker's file-manager metadata (every print start/end, every
  upload, every link rebuild changes it). The flip-flop you may see in the
  first seconds after a save is the watcher finishing a scan. It is
  harmless; if a list ever looks stuck, pull down to refresh (or press
  "Reload" in the browser) — never delete anything to "fix" a list.
- **Where a link may live:** only in the gcodes root. A link of your own
  somewhere else is never touched by the watcher.

Pattern: first line = ON/OFF toggle (value stays stored), then the values.

**Live rows everywhere:** file browser, generator outputs and optimized
copies have **no on/off conditions** — their names refresh while the menu is
open (~every 0.5 s), a free slot shows a single dot (nothing is hidden that
exists). **Confirmed rows leave the menu:** every generator/fix row that
confirms by double press (Create, Apply, Fix…) plays the start tune on the
second press and returns you to where you decide — no zombie rows after the
kick-off, no third press by accident.

**Menu order** — Pre-Print: File info (incl. `OBJ: shell`, .136m/R2.14) ·
Fixes (incl. the File check list — the same six entries as System > File
check, .136m — **plus `Fix: Quality` and `Fix: Speed`**, .136n) · Tools
(Offset, Texture, Range, **Scale X/Y with the Taper option**,
**Twist**, **Mirror**, **Toolchain (preset chains, R259)**, Cake cut,
Plotter, OBJ export) ·
**Material** (shows the current material — Load preset now / Save
current / Reset for PLA, PETG, TPU, ABS/ASA) · Temps ·
Motion · Features ·
utilities (Preheat/Mesh/Confirm/Overwrites) · Profiles LAST. Live Tuning:
Temps & Fan first, then Z-Hopping, Z-offset + babysteps, **the four
quick-access lists (Spd / Acc / PA / Flw per feat — directly under Live
Tuning, no Motion detour)**, Motion, Sources/File/Plotter — Exclude + Pause
at the very end. The separate *Live > Features* submenu is gone: everything
it could do is in those four lists (they cover all 16 feature codes incl.
Overhang, Internal Bridge, Prime Tower and Custom) and in Pre-Print >
Features. The SD browser has a **Del** row: one press switches the mode
on, then every file and folder needs **two presses** (arm + delete) — only
inside the G-Codes root, never during a print. The browser heals itself:
a folder the index does not know yet (stale mirror after a
restart) is REFUSED with a note instead of burying the path — an unknown
sub-folder keeps you on the deepest valid level, a dead path resets to
the G-Codes root, and the next index pass fills the gap (SDNAV_HOME
always goes to the top). With the browser parked these rows are
switched off — the SDNAV macros and the self-healing stay in the file for
the day the browser returns.

**Live Tuning (during a print, every mode)** — shows Klipper's REAL values:
the flow input reads the actual extrude factor (M221), PA reads
`pressure_advance`, smooth reads `smooth_time`, accel reads `max_accel`,
retraction reads the firmware values — what you see is what runs.

| Entry | Contents |
|---|---|
| Z +0.04 / +0.12 / −0.04 / −0.12 | babystepping right at the top |
| Hot / Bed / Fan / Zoff | cockpit: temperatures, fan %, Z-offset display · **Fan: NN% (LIVE)** — your absolute %, beats hold/scale/clamp AND the layer-1 rule · LIVE on/off · Hold · Scale (25–150 % × file) · Clamp (FMin/FMax/FBrdg) · How? (fan math) prints the chain |
| Spd per feat | **first entry after the babysteps** · title row **== SPEED ==** + Glob % (THE overall regulator) + "Now:" which feature is printing + FeatOn: its ON switch + **ShpOff** (input shaper off for the feature that prints right now; no ShpOff row in the other three lists) + Src info (file/overwrite/live) + all 16 feature % rows (TRV = travels) |
| Acc per feat | title row **== ACCEL ==** + global mm/s² + Feat x: scales every feature accel by % + the effective accel + "Now:" + all 16 feature accel rows |
| PA per feat | title row **== PRESSURE ADV ==** + Glob: the global PA + all 16 feature PA rows (input shaper PA lives per feature) |
| Flw per feat | title row **== FLOW ==** + Glob: the global flow % + all 16 feature flow rows — ironing's row IS the real slicer flow (5–100 %, typical 15–20) |
| File (G-code) | FULL mirror of the Pre-Print file info: measured originals (speed/accel per feature), 16 click-activators, temps, PA, retraction, fan, flow, MAXRATE (mm³/s) + seam position + DERIVED flag — everything during the print |
| Extrusion | Flow % (1–300), PA, PA smooth, RetLen / RetSpd / Unret, UnretExt, Ironing flow, **Z-Hop ON/OFF + height** (lifts over every retract — nozzle-crash protection) — every input shows what Klipper REALLY runs right now, Src info shows file/overwrite/live |
| Velocity | Velcap (max velocity — caps the fastest moves = travels) · Acccap (global accel cap, travels included) · MCR · corner — live, like Mainsail |
| Plotter | while plotting: pen speed %, pen Z ±0.05, X/Y ±0.5 shifts — appears ONLY while a plot file runs |
| Pause & Control | pause now / next layer / at layer / Stop@ (planned NORMAL end) / M600 / Filament (Load/Unload/Change while paused) / cancel (2×) |
| Objects | skip single objects (2× confirm) |
| Sources | PARAM_SOURCES: provenance of every parameter (ch. 14.1) |

#### Live > Temps & Fan — every row as you see it (R175c)

The fan entry is an absolute **dial**. Priority chain, strongest first:

**LIVE > layer-1 fan-off > HOLD > SCALE > CLAMP**

| LCD row | What it does |
|---|---|
| `Fan: NN% (LIVE)` | Dial 0–100, step 5. A positive value enables LIVE automatically; 0 disables LIVE and returns control to the normal chain (it is not a persistent fan-off lock). YOUR absolute part-fan % — beats Hold, Scale, Clamp and even the layer-1 fan-off rule (you turned the dial on purpose). Sets `f_fan_live` via `SET_FAN_LIVE PERCENT=`. |
| `LIVE: ON` / `LIVE: off` | The master switch for the LIVE stage. The dial only applies while ON (`SET_FAN_LIVE ON=`). OFF → the chain (Hold/Scale/Clamp, layer-1 rule) takes over again. |
| `How? (fan math)` | Prints the whole chain with the live numbers (`_FAN_CHAIN_NOW`): what the file asked for, LIVE/HOLD/SCALE/CLAMP, layer-1 state, and what the fan actually runs. |
| `Scale: NN% file` | 25–150 % — multiplies every M106 of the file (`SET_FAN_SCALE`). |
| `Clamp: ON fmin–fmax%` / `off` | Switch for the clamp window (`SET_FAN_CLAMP ON/OFF`). |
| `FMin: NN%` / `FMax: NN%` | The clamp window applied to every file M106 (`SET_FAN_CLAMP MIN/MAX=`). |
| `FBr: NN% 0=off` | Separate fan floor while a bridge section prints (`SET_FAN_CLAMP BRIDGE=`). |
| `Hold: NN%` | Absolute % replacing the file's M106 (`SET_FAN_HOLD`). 0 = the file rules again. |

The layer-1 fan-off rule (fan stays OFF on layer 1, default) lives in
`first_layer_rules` — toggle it under Pre-Print > Temperatures > L1 rules.
For the console equivalents (`SET_FAN_LIVE`, `SET_FAN_HOLD`, …) see ch. 6.1.

**Pre-Print**

| Entry | Contents |
|---|---|
| Offset X/Y/Z | X / Y / Z ±0.1 mm + each a fine row ±0.05 mm (halved steps, realtime MOVE=1) — SET_GCODE_OFFSET, the first thing you reach | (type, material, layer height × layers, line widths, flow ratio, by-object, nozzle × wall loops, ALL speeds, accels, L1/L2 temps, PA, retraction) + **sliced by <slicer> for <firmware>** (volumetric files get a loud warning) — shown from the MOMENT you select the file; the per-feature values are MEASURED from the g-code — PLUS 16 activator rows (OW…BM + OH/IB/PT/CU): each shows the file's REAL speed + o:ON state (ON also lists the non-neutral parameters — S speed, A accel, F flow, P PA); CLICK toggles that feature's override; features NOT in the file show 'n/a' and refuse · Flow line: MAXRATE + seam + *derived* marker · Cap (mm³/s) + Fix flow cap · TAcc + Fix travel accel |
| Material | LOAD NOW + all material values + Save as preset — editing a value of the ACTIVE material applies LIVE too |
| Profiles | Material (Load/Save/Reset PLA/PETG/TPU + ABS/ASA) · Defaults (Save/Info/Load 1–8/Delete 1–8) · This file (Save pre/Load pre/Load post/Del pre/Del post — only existing slots appear) + Auto-load toggle · From optimized (pick a copy → values become the Pre-Print starting point, .128) |
| Temperatures | Bed L1/L2, Hotend L1/L2, Fan L2 (ON/OFF each) + File H:/File B: = the file's own values |
| Velocity | retraction len/spd/unretract + File R: · **Drive: DIRECT/BOWDEN (swap)** (the retraction starting-point profile, every value stays free) · Accel + Vel + MCR + Corner (ON/OFF each; Accel/Vel are GLOBAL caps — travels included; the LIVE accel caps but never RAISES a slower file value) · Z-Hop ON/OFF + height — global PA moved to PA per feat. **retraction overrides apply IMMEDIATELY and at every print start** — generated files retract via G10/G11 and never send a SET_RETRACTION |
| Features | 16 submenus + the file's own C1..C9 custom slots (.136l): outer/inner wall, overhang wall, sparse/solid infill, top/bottom surface, bridge, internal bridge, gap fill, support, ironing (+flow), skirt, brim, prime tower, custom code — each shows the file's ORIGINAL (File:) + own ON switch + speed % (× global) + accel; only features the file really contains are editable — **a feature the file does not contain disappears from the menu entirely, an available-but-inactive one stays visible for live activation**; switching OFF resets the stored values to the file original — never touches the global values · PA input per feature + ShpOff toggle at the top · Custom Code submenu: How-it-works row + one slot per CUSTOMGROUP the file carries (On/Spd/Acc/Flw/PA) |
| Spd/Acc/PA/Flw per feat | four quick lists with the globals merged in: 1st-layer speed % (0 = off, default 75) · global accel + ON · global PA + smooth + File PA · global flow + ON · Now: the active feature — the former top-level Speeds/Accels/Flow menus, one level deeper but with everything in ONE place each |
| Bed Mesh | Level old files · Mesh ON/AUTO/OFF · Save after · Adaptive · Travel cap · Calibrate now · Load…/Delete… |
| Range/Stop | Stop@ layer + From/To (capped to the selected file's layer count!) + Floor/Top (each FOOTPRINT or OUTLINE, each GRID or SOLID fill) + Brim + Create excerpt (ch. C.1) |
| Filament | Load / Load length / Unload / Unload length / Change (M600) — available BEFORE the print too |
| File fixes (in File menu) | **Ret:** verdict line (FIX!/can/fixed/fw) · RetFix ON/OFF — auto-treats every NEW upload's clean retract pairs into G10/G11 (old Bowden-era files) · RetFix file (offered only for fix/can) + Vol->mm fix + Fix flow cap (Cap value) + Fix travel accel (TAcc value) — repair the SELECTED file directly on disk (start beep + done beep, markers survive) |
| OBJ: shell (.136m / R2.14) | **G-code → OBJ** of the selected file: every extrusion move becomes a ribbon of measured width + layer height — a mesh of the PURE OBJECT. Supports, skirt, brim, prime tower, custom helper blocks and the ironing pass are skipped (the summary names what went out). Result: `gcodes/STL/<name>_object.obj.gcode` — view it, re-slice it, share it. Idle only (the watcher reads the whole source). Console: `OBJ_EXPORT FILE=…` |
| Plotter | only when a plot file is selected: PEN FILE · pen speed % · Pen Z · Shift X/Y · Reset overrides — at the very END of Pre-Print |
| Texture | acts on the SELECTED file: File (shows the target) · Mode OFF/Fuzzy/Bumps · Fuz thick · Fuz dens · Pattern (**library of 54 + MAP**, 3 pages, seamless snap) · Around · Height · Depth · Seed · Img (MAP source) · **Fixed presets** (Orca/Hide/Subtle/Grip) · **Vorlagen** (.136m: the LIBRARY, 95 looks since R253 — appearance names like Rattan/Sandstein/Seil; one press loads ALL settings and the answer names them: pattern, size, depth, direction; delete refuses, your own save under such a name numbers itself; own page counter) + **My presets** · > Apply (2×) · How it works — writes a NEW `_TX` file (ch. 5.9), never auto-starts |

**Labels** (in Tools)

| Entry | Contents |
|---|---|
| Text | L1–L5 pickers · Show text · Pos 1–12 (cursor) · Chr (rotates A–Z a–z 0–9 space ÄÖÜäöüß and symbols) · Delete char · Clear text — the current text appears on the LCD with the cursor position; Fit gives a rough estimate, the exact preview follows ~2 s later |
| Settings | W/H (label size, default 50×15) · Font: SMOOTH / MONO / COND / NARROW / CAPS / SCRIPT / HAND / PLATE / PIXEL — nine fonts, the * marks the active one · Lines 1–5 · Size (0 = auto) · Spc letter spacing · Stroke = letter line width (0 = auto, 0.6 = nozzle) · Base/Text layers · LH / 1st · Ironing · Hole NONE/LEFT/RIGHT/TOP/BOTTOM · Hole D · Brim · 2 colors · Gap (grid spacing) |
| Job | Queue n/24 · Add label · Del last · Clear all (2×) · Create (press 2×) · Fit (how many fit the bed) · How it works |
| Settings | W/H · Lines 1–5 · Size (auto or cap mm) · Spc · Base/Text layers · LH/1st · Ironing · Hole · Stroke · **Preview fit?** (real numbers incl. growth + minimum size for a fixed font) |

**Plotter** (in Tools) — DRAW/DOTS, dot gap, pen offset X/Y/Z, scale X/Y %,
bed corner limits, extruder ON/OFF, Z up/down, speeds, max size, auto-
contrast, Invert AUTO/ON/OFF, Drive frame test, Start (overrides), Plot text
file, > Plot status. All baked into the file at conversion time; live entries
while plotting (ch. C.3).

**Cable ties** (in Tools — ch. 5.4)

| Entry | Contents |
|---|---|
| Info | every setting in one console listing + material tip |
| Settings | Count 1–24 · Len 50–300 mm · Width 2–12 mm · Layers 3–6 (strap thickness) · LH 0.12–0.32 (finer = smoother teeth) · Closure: CLASSIC (one-way pawl, `*` marks active) / LOOP (adjustable bead loop, reusable) · Brim ON/OFF |
| Create (press 2×) | validates, bumps the job counter — the watcher builds the file in the background, it beeps + auto-selects |
| How it works | the flow + PETG/TPU tip + the Mainsail one-liner, right on the LCD |

**Angles+Flat** (angles + flat connectors, in Tools — ch. 5.5)

| Entry | Contents |
|---|---|
| Info | every setting in one console listing + the auto-hole rules |
| Mode | Angle (L) / Flat splice — the `*` marks the active mode |
| Settings | Angle 30–170° (**hidden in Flat mode**) · Leg A/B 20–150 mm (renamed Left/Right in Flat mode) · Width 8–60 · Layers 4–12 · LH · Holes 0–6 per leg · Hole D 2–10 mm (auto-clamped to the leg width) · Holes: Countersunk/Normal · Rib None/Gusset/Stepped (**hidden in Flat mode**) · Count 1–12  Walls 1-6 · Infill 20-100% · Ironing on/off |
| Create (press 2×) | validates, bumps the job counter — ready in ~1–2 s with the full adjustment report |

**Lithophane** (picture → back-lit relief, in Tools — ch. 5.6)

| Entry | Contents |
|---|---|
| Info | every setting + how many images are ready |
| Images (Create) | the gcodes folder's `.png/.jpg` list (newest first, 10 slots; plotter uploads included) — slot press = Create |
| Delete image | same slots, **2-press confirm** (press, press again) — only the image goes away, its plotter `.gcode` stays |
| Settings | Orient STANDING/FLAT · Height (Size in FLAT) 30–200 mm · Layer 0.08–0.2 (0.12 default) · Levels 0–12 (0 = photo, 2–12 posterized) · Colors 1–4 + ColL 1–30 (FLAT color bands) · Frame ON/OFF · **Side stands** (.136m: ON by default — two triangular fins left+right docking at the BACK of the solid frame, ~5 mm perforated grid, break-off seam 1.2 mm or leave on as a deco stand; needs the frame, OFF says so honestly) · Brim 0–10 · Ironing ON/OFF |
| How it works | upload, slot press, standing print, white PLA tip, Mainsail one-liner |

**Gaskets** (in Tools — ch. 5.7)

| Entry | Contents |
|---|---|
| Info | every setting + material tips |
| Settings | OD 12–200 mm · ID 6–190 mm · Height 0.4–6 mm · Face: FLAT / NUT (groove + two sealing lips, `*` marks active) · Ironing ON/OFF · LH 0.12–0.32 |
| Create (press 2×) | validates, bumps the job counter — the watcher builds the file, it beeps + auto-selects |
| How it works | spiral-per-band, NUT fallback rule, TPU/PETG tip, Mainsail one-liner |

**Frames** (picture frames / display cases, in Tools — ch. 5.8)

| Entry | Contents |
|---|---|
| Info | every setting in one console listing + closure explanation |
| Settings | Preset: Custom/9x13/10x15/13x18/A6 (`*` marks active; picking one fills W/H as editable values) · W + H 40–230 (custom, max follows the build volume) · Depth 3–60 mm · Border 4–30 mm · Corner r 0–30 mm · Walls 1–4 (loops per side) · Shape RECT/OVAL · Closure BACK/SIDE · Hang TOP/BOTTOM/LEFT/RIGHT/OFF · Stand ON/OFF · Surf: Ironed/Bed texture/Lines/Waves/Honeycomb (+ Depth/Spacing/Angle/Wave amp/Cell/Dir) · Disc: None/Glass/Plexi/Foil/Litho (+ Side/Thick) · Cable ON/OFF · Infill 20–100 % · **Presets: Save current / Load 1–8 / Delete 1–8** (your complete frame configs) |
| Create (press 2×) | validates, bumps the job counter — the watcher checks the bed fit and builds the file, it beeps + auto-selects |
| How it works | workflow, kit logic, snap-in/side assembly, Mainsail one-liner |

**Bricks** (building bricks / kits / figures, in Tools — ch. 5.10–5.12)

| Entry | Contents |
|---|---|
| Info | queue + settings + geometry summary |
| Catalog | all 45 codes (B/P/T × 1x1…8x8) — press bumps the count, same codes merge, max 120 parts |
| Settings | Layer 0.08–0.32 |
| Create | builds `V01_Bricks.gcode` from the queue (beeps + selects) |
| Kit from file | Source: the file SELECTED in the file list (or SRC=/INDEX= via Mainsail; nothing selected = clear error) · Detail: AUTO/MICRO 4.8/SMALL 9.6/BIG 3.2 · Mode: By plate (1 color/plate, zero M600) / By object (M600 at color boundaries) · Colors 1–8 · CREATE kit |
| Figures | Scale 25–300 % (5 % steps) · Count 1–24 · CREATE figure |

**ColorPic** (color pictures, in Tools — ch. 5.13)

| Entry | Contents |
|---|---|
| Images | the shared image list (newest first, 10 slots) — slot press = Create |
| Settings | Width 25–230 mm · Bands 2–8 · Band height 0.4–3 mm · Band colors (per-band palette picker, light→dark, auto ramp) · Layer 0.08–0.3 · Ironing ON/OFF · Brim 0–8 · Swap ON/OFF · Contrast ON/OFF · Vers |
| How it works | the band principle, M600 + color swap, purge tower, Mainsail one-liner |

Dependency rules the menu enforces itself: Flat mode hides the Angle input
and the Rib submenu (a straight splice has neither), and the leg entries
rename to Left/Right so the halves are unambiguous. The hole count/diameter
never error out — the generator clamps and reports.

**Maintenance — in calibration order** (the ladder, ch. 9):

**PID Tuning** (hotend+fan% / bed) → **Leveling** (Z offset, bed screws) →
**Bed Mesh** (settings + profiles) → **Extruder Cal.** (E-steps) →
**Vibration Cal.** (shaper calibration, diagram print/plot, apply result,
manual shaper override without accelerometer) →
**Temp Tower** (band control + generated tower) → **PA Cal.** (line test +
**PA Smooth Cal.**) → **Flow Cal.** (generated cube + calculator) →
**Retract Tower** (generated) → **Bridging** (generated) → **Ironing Cal.**
(cards) → **Clean Nozzle** → **Filament** (load/unload/cold pull) →
**Z Gantry Sync / Z Tilt** (whichever this printer has) → **KAMP** →
**Tests** (sound/self test/status).

**Macros (Quick Macros):** load/unload, gantry sync / z tilt, status, sounds on/off,
(LED control removed - the nozzle light is no longer configurable via LCD)
R/G/B + presets.

**System:** File check (+ Retag old 2×), **Gen jobs** (queue state + clear,
.136u), restarts (2×), Pi shutdown (2×), **Force end print**, save config
(2×, warns that the LCD goes dark), **PP engine** (stable ⇄ experimental
post-processor, one press, plus an explain row), **Diagnostics > Log pack**
(collects the evidence file for a support round — nothing to type), **MCU
Recovery** (auto-recovery
ON/OFF — see ch. 19), status.

## 15. Overrides reference

Every override = value + OWN ON switch. SET_OVERRIDE_VALUE sets + ON ·
TOGGLE_OVERRIDE flips · CLEAR_OVERRIDES switches all off (values stay).
Naming: the console/LCD/Mainsail descriptions say **"Overwrite(s)"** (since
.31, your wording); the macro + variable names keep "override"
(SET_OVERRIDE_VALUE, ov_*) so existing buttons/scripts never break.

| Group | Keys | Defaults | Applied |
|---|---|---|---|
| Temps | bed, bed_after, hotend_first, hotend_after | 60/55 · 225/210 e.g. | start + intercepted M104/109/140/190 (by layer) |
| PA | pa, pa_smooth | 0.05 · 0.04 | from purge on |
| Retraction | retract_len, retract_speed, unretract_speed | 0.75 · 35 · 35 | from purge on |
| Machine limits | accel, velocity, min_cruise, square_corner | 4000 · 300 · 0.5 · 5 (OFF) | start, ONLY ON + value > 0 |
| Flow / Fan | flow, fan | 100 · 100 | flow global (M221) · fan scaled from the START — the file's M106 S0 stays 0, everything else is scaled by your % |
| Per feature | feat_spd_<code> + feat_acc_<code> + feat_on_<code> for 25 codes (wallouter, wallinner, infillsparse, infillsolid, surfacetop, surfacebottom, bridge, gaps, support, ironing, skirt, brim, overhangperim, internalbridge, primetower, custom + the numbered slots c1..c9, .136l); ironing + ironing_flow | 100 · 0 each | only while that feature prints (APPLY_TYPE): speed = % x CLEAN global, accel absolute — the global value itself never changes; feat_on=0 RESETS the values to the file original; unavailable features refuse |

The interceptors remember what the FILE asked for — file_hotend_first/after,
file_bed/after, file_retract_len/speed, file_fan, file_flow, file_accel,
file_speed — shown as File H:/File B:/File R:/File F:/File Fl:/File A: hints.
M221 (flow factor), M204 (accel) and M220 (speed factor) are intercepted too:
your overwrites win when ON, otherwise the file value passes 1:1 (/.35).

## 16. Sound reference

20 tunes as frequency:ms:volume triples (M300-based). PLAY_SOUND NAME=… ·
TOGGLE_SOUNDS · TEST_SOUNDS plays them all (Maintenance > Tests).

| Group | Tunes |
|---|---|
| UI / dialogs | r2_click · r2_confirm · r2_notice · r2_question (start dialog, repeats) · r2_pause · r2_resume |
| Start stages | r2_start · r2_leveling · r2_heating · r2_hot · r2_printing · r2_leveled |
| Tuning | r2_pid · r2_leveling |
| Filament | r2_filament (repeats) · r2_alarm |
| Endings | r2_done · r2_sad · r2_error · r2_happy |

**One melody set, one meaning** (project-wide): **r2_start** = work begins
(every create/fix press), **r2_gen** = a queued job starts building,
**r2_done** = success, **r2_confirm** = quick UI confirmations. Generator
and fix tunes play whenever no print is ACTIVE — the same events stay
silent during a print.

**Beep discipline during a print** **: every beep blocks the firmware
for its whole duration — on an active print the standing filament oozes a
purge blob into the part (micro pause → stutter). While the print is ACTIVE
the confirmation and feedback tunes stay **silent**: r2_confirm, r2_click,
r2_start / r2_gen / r2_done (work + queue + success), r2_happy,
r2_heating/r2_hot (live temperature changes) —
the NeoPixel effects carry the feedback instead. Critical tunes ALWAYS play:
pause, filament change, dialogs/questions, alarms, errors — and after the
print everything is back to normal.

Volume lives inside the tune triples (0.05-0.5 duty). Edit/add tunes in
02_sounds.cfg — 0 Hz = a pure pause.


## 17. Console messages

`[OK]` success · `[i]` info · `[!]` warning · `!!` error. M117 mirrors the
essence onto the LCD. Typical lines you will meet:

```
M104: 215C -> OVERWRITE -> 225C (layer 1)
M104: 215C -> YOUR L2 override -> 240C (AS SLICED, layer 2)
M220 S100% capped to 65% (layer 1)
Layer 1: speed brake re-applied (65% after resume)
Layer 2: hotend -> 205C (your override · file value · material PLA · Z-track — whichever wins)
Layer 2: bed -> 55C (…) · Layer 2: fan back on (file value S200)
Sequential print: next object (NAME) - back to LAYER-1 temperatures
Temp tower: layer 21 -> 215C
Print running (legacy file) - live tuning and overwrites ACTIVE
=== PRINT RUNNING === / Print finished: NAME (duration)
```

## 18. System: Klipper & Pi

| Command | Effect |
|---|---|
| SYS_FIRMWARE_RESTART CONFIRM=1 | Klipper restart (macros reload) — 2× |
| SYS_HOST_RESTART CONFIRM=1 | host service restart — 2× |
| SYS_SHUTDOWN CONFIRM=1 | heaters/fans off → Pi shutdown via moonraker |
| SYS_SAVE_CONFIG | guarded SAVE_CONFIG: refuses during a print, skips when nothing is pending, warns that the LCD goes DARK for up to 2 min before restarting (2×) |
| HOST_CHECK | **Pi health report**: throttle/undervoltage flags (now + since boot), CPU temp, load **vs. core count**, **RAM + swap**, disk, **iowait**, **TOP CPU/RAM processes (top 5)** and **who sits IN the swap** (VmSwap per process — names the RAM eater even when the top-RAM list looks innocent) + **service states** (klipper/moonraker/avahi/crowsnest/sonar/OctoEverywhere/pigpiod, with warnings: double webcam stack, avahi still on, cloud relay) — honest verdict: THROTTLED / SWAPPING / OVERLOADED / OK. The swap verdict measures **activity** (vmstat swap-in/out): quietly parked pages after boot are **OK** (normal on a small Pi), only real swap traffic counts as SWAPPING. LCD: System > Host check. Since .136 it also flags DUPLICATE r2-postproc watcher processes (they double every state push) with the fix command. Since .136m it counts **klippy's own load symptoms** from klippy.log — "Reactor: N stall(s) up to X s + N failed LED updates": many stalls mean the host repeatedly blocked klippy's reactor and the next homing can hit 'Timer too close' even with load/throttle looking fine |
| EMERGENCY_STOP | immediate halt |
| FILE_CHECK | **g-code inventory**: scans every file's tag version — how many are current, old (upgradeable), untouched (never processed) or plotter files — each file listed on the console with age + size. `FILE_CHECK RETAG=1` (2×/CONFIRM=1) additionally upgrades old + untouched files to the current markers: **.r2bak backup first**, never while printing, max 20 per run. LCD: System > File check + STALE (v4: functional, pre-.86 info line — RETAG adds the new keys) |
| SET_RECOVERY MODE=on/off | **MCU-shutdown auto-recovery** switch (default ON). LCD: System > MCU Recovery. Reads from the variables FILE — no macro can run while klippy is dead, so the switch must survive outside klippy's RAM |
| SET_PP_ENGINE MODE=stable\|next | **which post-processor runs**: `stable` = `tools/r2_postproc.py` (the engine of today), `next` = `tools/r2_postproc_next.py` (a byte-for-byte COPY of it — all new work happens there). The service always starts the stable file; it reads this switch from the variables FILE and hands over. A missing/broken copy, or a handover that died in the last 15 min, keeps the stable engine running. LCD: System > PP engine (one press flips it) — no restart needed |
| PP_ENGINE_INFO | shows switch / actually running engine / build, and how to go back |
| DOCTOR_PACK | **evidence pack** for a support round: one file with build stamps, host health, the three services + journals, the watcher state files, variables.cfg, printer.cfg, a compact **incident digest** cut out of klippy.log (every shutdown/probe failure, the worst Reactor stalls **with their stacks**, the MCU statistics around each shutdown), the last 3 MB of the raw log and the newest MCU snapshot. Lands in `gcodes/crash_archive/R2-DOCTOR-<date>.txt.gcode` (+ `.txt` twin) — Mainsail only lists printable files, hence the `.gcode` tail; the post-processor skips every `R2-DOCTOR-*` file, so it can never be printed. Idle-gated. LCD: System > Diagnostics > Log pack. No display: `python3 tools/r2_collect.py`. R253: the macro was called R2_DOCTOR in .142h, and that name halted the boot (Klipper rejects a digit in position 2); the old spelling still forwards here, so nothing that was written against .142h breaks |

All destructive paths need TWO presses (60 s window). Serial link: UART (ch. B.5).

**MCU-shutdown auto-recovery — the watcher as the calm hand:**
klippy cannot heal itself (it IS the patient) and moonraker deliberately
never restarts a shutdown klippy — but the watcher is an independent
process with the same moonraker API the UI buttons use. When the printer
hits `MCU 'mcu' shutdown`, the watcher walks an escalation ladder, every
step rate-limited: **L1** `FIRMWARE_RESTART` (what the UI button does —
klippy answers it even in shutdown state) · **L2** klipper service
restart via moonraker (host software died or L1 changed nothing) ·
**L3** full Pi reboot — only after 3.5 min dead, at most ONCE per hour
(the brake persists in `watcher_recovery.json` — a reboot never resets
its own rate limit), or immediately on the 3rd episode within 15 min.
**Only host/link classes auto-recover** (`Timer too close`, lost
communication/timeout, can-not-update-mcu, missed digital-out
scheduling — heaters are OFF in MCU shutdown anyway). **Heater, thermal
and config classes stay DOWN** with one log line — those need eyes, not
a restart loop. klippy.log is snapshotted to `crash_archive/` BEFORE the
first restart, so the forensics survive every rotation. Field score so
far: two production saves (100 s and 178 s from crash to ready).

**.136n — the R2 machine panel in Mainsail (WebUI):** the macro system
carries its own web page (`web/index.html`, served by moonraker) with a
**Machine panel styled like Mainsail's** — the system buttons
(Firmware restart, Host restart, Shutdown, Save config, Emergency stop)
live in **one dedicated section**, each guarded by the same 2-press
confirm as on the LCD. System status (mode, host check verdict,
watchdog state) polls every 3 s; the page never fights Mainsail for a
command — it routes everything through the same macros. **Log emptying**
(clearing klippy.log etc.) is a **checkbox selection menu** — nothing
wipes a log just because the page was opened; you tick what may go.

**Why FILE_CHECK exists:** markers (`APPLY_TYPE`, extended `_FILE_INFO`,
measured per-feature speeds) grew over the versions — a file uploaded long
ago prints, but the newer features (feature overrides, live preview,
measured originals) stay blind to it. `FILE_CHECK` shows exactly which
files those are, `RETAG` brings them up to date without a re-upload. The
direct SSH variant (no Klipper needed):

```
python3 tools/r2_postproc.py --file-check ~/printer_data/gcodes
```

### 19a. The MCU-shutdown watchdog

**What you see:** after an MCU shutdown the display
freezes — and the heated bed seems to stay ON until you press
FIRMWARE_RESTART. That feels dangerous — here is the proof + the safety net.

**How Klipper is built:** on an MCU shutdown klippy turns **every heater
OFF by design** — the host must confirm each heater activation every 3 s,
and the heater pins default to `shutdown_value: 0` with a max-duration
watchdog. That holds even when the host itself crashes. Your bed is 24 V DC
at the board — when klippy stops confirming, the MOSFET closes.

**What the watcher does now (your choices):** it polls klippy's state every
2 s. On `shutdown` it opens a **10-minute evidence window**: bed + hotend
temperatures (target vs. actual) land in
`logs/r2_shutdown_watchdog.log` every 5 s — if the bed curve DECAYS, power
was cut (evidence in writing); if it ever HOLDS at target, power is flowing
and you have a wiring/SSR fault worth fixing. Note the limits of that
evidence: it confirms the observed wiring behaved correctly during the
logged window — it is never a hardware clearance or a substitute for
measuring the actual installation. After **5 minutes** in
shutdown it sends the **FIRMWARE_RESTART itself** (max 2 per boot of the
watcher, at least 1 h apart — no restart loops). Every step is logged.

### 19a2. Sending evidence: the Log pack (no SSH, no hunting for files)

When something fails, the only thing that is ever needed is **one file**:

1. LCD: **System > Diagnostics > Log pack (for support)** — one press. (Or, if
   you are on SSH anyway:
   `python3 ~/printer_data/config/klipper-e3-r2d2/tools/r2_collect.py`.)
2. The display says `Log pack ready`. In Mainsail under **Dateien →
   crash_archive** there is now `R2-DOCTOR-<date>.txt.gcode` — download it and
   send that one file.

Why it is built this way: moonraker/Mainsail only LIST files they consider
printable, which is exactly why the old crash snapshots (`mcu-*.log`) were in
that folder and invisible. The pack therefore carries the `.gcode` tail, and
the post-processor skips every `R2-DOCTOR-*` name, so the file can never be
printed or tagged by accident. The `.txt` twin sits next to it for the case
that you read it on a PC.

What is inside (that is why one file is enough): build stamps of macros,
post-processor and Klipper · host (RAM, swap, disk, load, top processes,
throttling flags, dmesg tail) · klipper / moonraker / r2-postproc with their
journals · the watcher's own state files · `variables.cfg` and `printer.cfg` ·
an **incident digest** cut out of `klippy.log` (every shutdown and probe
failure in order, the **worst Reactor stalls with their stacks**, the MCU
statistics around each shutdown) · the last 3 MB of the raw log · the newest
MCU snapshot from `crash_archive/` · the file inventory of the gcodes folder.
It only reads — nothing is changed, no `sudo`, no service is touched — and it
waits for idle because it copies logs off the SD card.

### 19a3. Two post-processors: the switch (stable ⇄ experimental)

The post-processor (`tools/r2_postproc.py`) is the one part that rewrites your
G-code, so it is the one part that must never be "rebuilt while you are
printing". From .142h there are two files:

| File | Role |
|---|---|
| `tools/r2_postproc.py` | **stable** — the engine you have been printing with. Stays the entry point the service starts. |
| `tools/r2_postproc_next.py` | **experimental** — a byte-for-byte copy of it. Every new development happens here from now on. |

LCD: **System > PP engine: stable** — one press flips it to **EXPERIMENTAL**;
the row shows `runs: …` with what is really running, so you can see that the
switch took effect. **No restart, no `sudo`.** The way back is the same press:

- The service always starts the **stable** file. It reads the switch and hands
  over to the copy only when the switch says so.
- The copy is checked before the handover: **a syntax error keeps the stable
  engine running**, and a handover that actually died is **braked for 15
  minutes** (so a broken experiment cannot loop the daemon).
- `--engine=stable` on the command line beats the switch, for the case that
  the display is unreachable:
  `python3 tools/r2_postproc.py --watch ~/printer_data/gcodes --engine=stable`
- The diagnostics (`--file-check`, generators, `--obj`) always run on the
  **stable** code, so the troubleshooting tools work even while an experiment
  is broken.

### 19b. setup.sh / update.sh — wizards, backups, change modes

**The hardware profile — a second variables file.** `r2_hardware.cfg` (next to
printer.cfg, included by one line) carries everything that makes THIS printer
tick: build volume (bed min/max X/Y, Z height), probe offsets, nozzle-clean
(wipe) + part-presentation positions. It is
deliberately separate from `variables.cfg`: resetting your print settings
(deleting the normal variables file) can never lose machine compatibility —
and the LCD-editable hardware values persist into it. `HW_INFO`
(console / System > Hardware info) shows it at any time.

**The wizards.** `bash klipper-e3-r2d2/setup.sh` asks every hardware value in
English — each entry validated AND confirmed a second time (mistakes can be
corrected before anything is taken over), a summary + final confirmation
before the profile is written. `update.sh` asks FIRST whether to **keep**
the current hardware settings (default) or re-run the wizards. Since .135 it also
REFUSES an update zip without the `klipper-e3-r2d2/` top-level folder before
unpacking anything (the .134 zip was accidentally built flat: it scattered
`macros/`, `tools/` … next to printer.cfg while the package stayed .133 —
which is why .134 kept showing as .133 after that update), and it warns with
the exact cleanup list when it finds those flat-zip remains in your config
folder.

**Backup before anything.** Both scripts start by copying every file the run
might change (printer.cfg, moonraker.conf, KAMP_Settings.cfg,
r2_hardware.cfg, the service unit) into
`r2_backups/<timestamp>-setup|-update/` — and VERIFY each copy byte-identical
(`cmp`) before a single modification happens. A failed verify aborts the run.

**Every change is shown first — four ways to apply.** Nothing is ever silently
written into your printer.cfg / moonraker.conf:

| Mode | What happens |
|---|---|
| 1 — automatic | the lines are inserted (in printer.cfg always BEFORE the `#*#` block); your own conflicting lines are only COMMENTED OUT — never deleted |
| 2 — commented only | the lines go in commented (`# R2> `) — you remove the marker yourself when you want them |
| 3 — separate txt (default) | the lines land in `r2_manual_changes.txt` with target file + position — SAFEST: your files are not touched at all |
| 4 — skip | nothing |

**Object processing (moonraker).** Both wizards show the CURRENT state of
`enable_object_processing` and explain it: ON = moonraker analyses every
upload itself — files without slicer object data still get adaptive KAMP
meshes + the LCD Skip-Objects menu (fine on a strong host); OFF = recommended
on a Pi Zero 2 W / Pi 3 (the analysis costs RAM on every upload — with it off,
KAMP meshes full-bed on such files and the purge falls back to our own line).
Keep / turn on / turn off — the change goes through the four modes above.

## 19. Variables & editing the .cfg files

Persistent settings live in ~/printer_data/variables.cfg — change via LCD/console;
never edit the file while Klipper runs. Runtime state lives in _STATE (not persisted).

| Group (save_variables) | Keys |
|---|---|
| Material | material, mat_* (per-material presets) |
| Mesh | mesh_mode (ON/AUTO/OFF), mesh_always (fallback), mesh_adaptive, mesh_auto_save, mesh_last_profile, legacy_level |
| Print behavior | first_layer_speed (75), load_length (60), unload_length (90), pid_fan_percent |
| Overrides | all ov_* keys + ov_*_on switches (ch. 15) |
| PA calibration | pa_cal_* (temp, bed, start, step, lines, len, slow, fast, accel, layer, spacing) · smooth_test_start/step |
| Flow / tower / ironing | flow_cal_* · tt_start/end/step/band/active · iron_cal_temp |
| Cold pull / misc | cold_pull_hot, cold_pull_pull, cooldown_fan_time, heaters_off_at_end, motors_off_at_end |
| System | sound_on, start_confirm, gantry_sync_*, kamp_*, ishaper_* |
| Hardware profile (r2_hardware.cfg — survives a variables.cfg reset!) | bed limits + Z height · probe_x/y · present_x/y · wipe_x/y |
| Generators / texture | *_nonce job counters · texture_mode/thick/density/pattern/scale/amp/dir · file_check_retag |

**The LCD mirror lives in RAM (R246/.142):** rebuildable list data — the SD
tree (`sd_tree`), the browser view (`sd_view`), generator outputs
(`gen_files`), the optimized list (`opt_list`) and the lithophane image
lists (`litho_*`) — does **not** live in variables.cfg anymore. It lives in
the `_SDM` macro's variables (01_state.cfg) and is written with
`SET_GCODE_VARIABLE`: zero disk writes, zero file serialization inside
klippy's reactor. Why: every SAVE_VARIABLE rewrites the WHOLE variables.cfg
synchronously, and with the host deep in swap (49 MB free, Nov 10 field
log) those whole-file writes of the giant mirrors stalled the reactor into
MCU shutdowns — at print end, at file selection AND at the print-start
click. The watcher rescans and refills `_SDM` at boot and after every
change (one console line: `SD index ready: N entries in X.Xs`). Menus read
`printer['gcode_macro _SDM'].<name>`. Editing hint: nothing to edit — the
mirror is 100 % rebuildable; your variables.cfg keeps only true persistence
(the table above).

Nice edit spots per file:

| File | Edit spots |
|---|---|
| 05_materials.cfg | variable_presets — the shipped material defaults |
| 08_print_start_stop.cfg | _PRIME_LINE (flush 6 · width 1.2 · length 110 · margin 5 · direction right→x0) · _PROBE_STOW (dock hook: uncomment DOCK_PROBE for Klicky/Euclid) · waiting heights Z10/Z40 |
| 09_pause_filament.cfg | _PARK_HEAD (corner logic · lift 5 mm · anti-ooze −3 mm) |
| 12_maintenance.cfg | CALIBRATE_PA defaults · IRONING_CAL zones · TEMP_TOWER defaults |
| 02_sounds.cfg | tunes — triples freq:ms:volume |
| 01_state.cfg | variable_version · INIT defaults |

```
Golden rules: single braces {…} (NEVER {{ }}) · {% … %} for logic · no {# #}
inline comments in gcode · SAVE_VARIABLE names lowercase · True/False capitalized
· keep rename_existing: lines (the M99xxx base commands live behind them!)
```

### Hints from the macro comments (user adjustments)

| Where | Hint (from the code) |
|---|---|
| 01 INIT | runs 5 s after boot, fills only MISSING keys — your saved values are never overwritten |
| 05 presets | variable_presets are shipped defaults; your saved mat_<material>_<key> values always win — "Save as preset" makes yours permanent |
| 06 overrides | override ON → temperature redirected to YOUR value; OFF → file value passes unchanged |
| 08 purge | purge ALWAYS (user rule) — hotend heats to the LAYER-1 temperature first |
| 08 probe | _PROBE_STOW hook runs before every purge — dock your Klicky/Euclid probe there |
| 08 dialog | AS LEGACY uses your selected material · AS SLICED takes the material from the file |
| 09 pause | idle timeout = infinite during a pause — Klipper must never turn heaters off mid-pause |
| 10 PA | with the PA override ON, a sliced-in SET_PRESSURE_ADVANCE cannot override your value |
| 11 gantry | Z motors wired in parallel on ONE driver — SYNC_GANTRY does the mechanical sync; watch the first run. A printer with 2+ Z steppers + [z_tilt] gets Z_TILT everywhere instead (LCD swaps automatically) |
| 12 screws | screw positions live in [screws_tilt_adjust] in printer.cfg → ADJUST TO YOUR PRINTER |
| 15 objects | console users can always use Klipper's native EXCLUDE_OBJECT as well |

## 20. What happens when a macro executes

### 21.1 The idea in one worked example — from upload to finished print

The system's purpose in one sentence: **the printer understands its files.**
Four building blocks make that work — reading files, tagging them,
recognizing features, and triggering functions. Here is the complete chain
for a real print (`vase.gcode`, sliced in OrcaSlicer for Klipper):

**1. Reading the file (the watcher).** A service on the Pi
(`tools/r2_postproc.py`) watches the gcodes folder. One second after
`vase.gcode` arrives it reads the WHOLE file once: layer comments, `;TYPE:`
feature comments, slicer header, object definitions, temperatures, speeds —
and writes what it learned into the file itself.

**2. Tagging.** The watcher inserts markers that Klipper macros can react to:

```
; R2-POSTPROC v4          ← the tag: "this file is processed" (never twice)
_FILE_INFO LAYERS=312 …   ← everything the preview shows, one block
LAYER_MARK               ← before every layer change
APPLY_TYPE TYPE=WALL-OUTER  ← after every ;TYPE: comment
```

**3. Feature recognition.** `_FILE_INFO` contains the MEASURED values per
feature (which speeds really are in the file), the layer count, by-object
mode, the slicer + firmware it was made for. The moment you SELECT the file,
this block replays into the system — Pre-Print > File info fills itself, the
start dialog knows what it is dealing with, volumetric Marlin files get
flagged.

**4. Triggering functions.** During the print, the markers fire macros:
`LAYER_MARK` counts layers (→ layer 2: L2 temps, file fan back, full speed),
`APPLY_TYPE` switches the live overrides to whatever feature is printing
right now, `PRINT_START`/`PRINT_END` (or their absence in a legacy file!)
trigger the start/end choreography. The file NAME is a trigger too:
`photo.png` selected in the file list switches to plot mode (the watcher
generates `00_Plot_*` on demand), `notes.txt` to a text plot —
and a saved variable bumping (the "nonce" counters) triggers the five
generators of chapter 5 in the background.

The same pattern everywhere: **detect once, decide in a macro, act live.**
Nothing is baked in — AS SLICED runs the file 1:1, and every automatic rule
is a switch you can turn off.

### 21.2 Execution mechanics

1. **Render before execute:** Klipper evaluates the whole template FIRST, then
   runs plain gcode — a macro cannot see values it just set. Verification phases
   run as delayed_gcode (_LEGACY_PREP2 1.5 s, _OBJECT_PREP 2 s) and render FRESH.
2. **rename_existing interception:** M104/M106/M140/M190/M204/M220/
   SET_PRESSURE_ADVANCE/SET_RETRACTION are OUR macros; the real commands live on
   as M99104 … M99220 and receive the redirected values.
3. **delayed_gcode** = "run once in N seconds". _STATE_WATCHER re-schedules every
   second.
4. **State lives twice:** fast runtime state in _STATE variables · persistent
   settings in save_variables.
5. **{action_…} calls** become host actions — the Pi shutdown is moonraker's method.
6. **Errors abort the chain** — risky sequences are split into phases: a hard
   error in phase 1 cannot kill phase 2; it just never runs. Look ABOVE in the
   console for the first real error.

## 21. Troubleshooting

| Symptom | Cause → fix |
|---|---|
| Must home axis first | the real error is usually ABOVE it in the console; right at a legacy file's start: fixed in .32 (START_PRINT does the real legacy start) |
| L1 speed did not apply (legacy) | file sent M220 S100 — capped + re-applied after every resume /.26 |
| L2 never came after object change/skip | .24 frozen-counter bug — fixed in .26 (Z re-anchors at every object start) |
| Purge moved but nothing came out | heat soak + tighter wait ; check tension/clog if still weak |
| Values "not applied" | override OFF or 0 (SHOW_STATUS) — or print runs AS SLICED |
| LCD value invisible while editing | fixed — all labels ≤16 chars incl. value (test-enforced) |
| Retraction LCD stale/reset | live mirror |
| Acceleration changed without asking | old forced 4000 — now only ON + value > 0 |
| Probe samples exceed tolerance | clean the bed; samples_tolerance: 0.15 |
| Unknown profile r2 after restart | mesh was session-only → "Save after print" ON |
| VARIABLE must not contain upper case | ancient version → upload complete package |
| LCD entries missing/mixed | old lcd_menues.cfg → upload complete folder |
| No sounds | [pwm_cycle_time beeper] missing/wrong · TOGGLE_SOUNDS |
| Pi shutdown does nothing | moonraker not reachable — SYS_SHUTDOWN logs clearly |
| Probe hit the bed edge at the purge line | fixed in .29 — prime line is probe-offset aware (right→x0); KAMP LINE purge auto-skipped with side offset > 10 mm |
| "Minimum cruise ratio not applied" | it IS passed (SET_VELOCITY_LIMIT, Klipper ≥ v0.12) — the console confirms: "[OK] minimum cruise ratio … -> Klipper" + "Machine limits -> Klipper: …" at start |
| SYNC_GANTRY needs force_move | [force_move] enable_force_move: True |
| KAMP meshes the whole bed | check KAMP_Settings.cfg margin |
| Dialog/menus "did nothing", mode stuck 'waiting' | .30 bug, fixed in .31 (dialog schedules its decision waiter, PRINT_START heals stale modes); dead watcher: .32 _WATCHDOG re-arms it every 5 s |
| "Extrude below minimum temp" at a legacy file's start | same .31 root cause + M109 no longer waits in the background; AS SLICED now homes, waits for the file's temps and purges before the file continues |
| Pause + L1 temps mid-object ("next object" from nowhere) | z-hop ratcheted the Z mark — fixed in: hops <= 1 mm are un-ratcheted, trigger zone tightened to < 0.75 mm |
| Hotend at full temp during bed + mesh (oozing) | the AS LEGACY prep drops it to 170C standby and re-heats for the purge |
| Movement file (no heating, no start gcode) runs cold / file ran during the start dialog | every print is caught — reliably (M25 holds the file at position 0, nothing runs before the decision); after the decision the net probe gives movement files home + heat (preset/overwrites) + purge automatically |
| 'switch_sensor' is not valid for SENSOR | SET_FILAMENT_SENSOR takes the SECTION name (filament_sensor / encoder_sensor) — the BTT example was copied 1:1 although your section is named differently; corrected block: ch. 7 |
| "Save config froze the printer" (LCD dark after Save config) | NOT a crash by design: SAVE_CONFIG restarts Klipper and the LCD keeps its last image until the MCU reconnects — on the Pi Zero 2 W that can take up to ~2 min (big config).: System > Save config warns first ("LCD goes dark"), refuses during prints, restarts anyway when nothing is pending (your R2 settings save instantly), and the boot beep + "R2 ready" confirm a SUCCESSFUL restart. Still dark + Mainsail error after 2 min → FIRMWARE_RESTART from Mainsail or `sudo service klipper restart`, then send ~/printer_data/logs/klippy.log (never power-cycle the Pi!) |
| Question came only after the bed heated | M190/M109 do not block while the decision is pending — bed preheats in background, question within seconds |
| Z_TILT refuses: no [z_tilt] section | add it to printer.cfg — one X,Y pair per Z stepper, e.g. `z_positions: 45,45` + `215,45`; single-driver printers don't need it (SYNC_GANTRY) |
| Nozzle preheats to 182 on select | that is the filament-swap level — change filament while the start dialog waits; Pre-Print > Preheat changes or disables it |
| **MCU 'Timer too close' shutdown** (host cannot feed the MCU) | ALWAYS a HOST problem — NEVER stepper current, never the electronics fan, never a safety trigger, and never a zip lying in the config folder (nothing scans it). **System > Host check** names it: THROTTLED = undervoltage (PSU/USB cable!) or heat · OVERLOADED = load >= core count, the Top-CPU list shows who — typical eaters on a Pi Zero 2: **webcam (crowsnest), sonar, OctoEverywhere, moonraker's object processing (enable_object_processing: True — your own moonraker.conf comment warns against it on a Pi Zero!)**, update manager, a fan/temp script with software PWM (RPi.GPIO) · SWAPPING = swap traffic RIGHT NOW (the check measures in/out — quietly parked pages after boot are OK and no reason to panic) — **the verdict names the processes sitting in the swap („Top SWAP") directly** · also: after boot/update give the Pi ~2 min before starting a print (moonraker + watcher both re-scan the whole gcode folder while klippy parses the big config). Software side already hardened: mesh travels capped, preview pushes cost zero disk writes, meshes run adaptive |
| Mesh is full bed although 'adaptive' |: honest wording — 'full bed (file has no object data)' now SAYS so. The mesh before a held file runs adaptive (the watcher replays the file's EXCLUDE_OBJECT_DEFINE at selection); Orca files carry them when 'Label objects' is enabled. Plot/label/bridge files bring their own object polygon |
| KAMP meshes the whole bed | check KAMP_Settings.cfg margin — AND the file needs object data (see row above) |
| `sudo` + the watcher check lists 2–3 r2-postproc "processes" | measurement artifact, NOT hidden watchers (.136d field log): `pgrep -f` matches the full command line and the sudo+pgrep pair carries the pattern itself — pgrep excludes only its own PID. A real watcher line looks like `/usr/bin/python3 …/r2_postproc.py --watch …`. Self-match-proof check (with or without sudo): `pgrep -af '[r]2_postproc.py'` — exactly ONE line. Better: update.sh prints the watcher census after every update ("exactly 1 r2-postproc watcher (PID …)"), and a second .136+ watcher cannot even start (kernel flock — it refuses with the reason) |
| Web-LCD: Tools menu + SD list empty although the badge says live=ok | fixed in .136k: a status snapshot lists objects WITHOUT their values until one is set — the page's existence tests (`'x' in printer.objects`) answered no and hid the Generators/SD rows. The live answer now carries `available` (plain object names) next to `objects`; the page materializes them as empty objects. Field-bug class #19: VALUELESS SNAPSHOTS. |
| LCD: FILE_CHECK / RETAG not reachable | R175b had buried File check as a COMMAND with children under Pre-Print > Fixes — klipper's display menu never opens a command's children (the web menu did, which is why it worked there). Back as a LIST under **System > File check**: Scan now, How it works, Retag old (2-press), Re-fix types (2-press). |
| Web-LCD: „Moonraker lehnte ab (403)" | fixed in .136e: Moonraker rejects any request whose Origin header it does not know — and browsers send Origin on EVERY command POST (same-origin GETs carry none: live values worked, buttons died since .136b). The nginx site now strips Origin at the proxy and runs its own CSRF guard (foreign websites get 403 from nginx, never reaching the printer), and update.sh refreshes the web-LCD on every package update. .136f: case-insensitive same-origin check + live-guard self-test after every reload. **.136g: the page itself answered 403 (already on open, inkognito too)** — nginx runs as www-data and could not read the page under /home/pi (serve-path permissions can flip on any update; the API paths kept working, which is why every proxy test was green). The page is now served from `/var/www/r2lcd` (world-readable, outside every home dir), synced on every package update, and the self-test also GETs the page itself. **.136h: the page's JavaScript had never executed at all** — the JSON embed left a stray `null` after the menu data (`EMBEDDED_MENU_JSON = {...} null;` = syntax error), so no click ever worked and the menu stayed at „__main“; plus Moonraker's `{"result":…}` envelope was never unwrapped and the live poll started before the menu data arrived. All three fixed; a new integration test parses and runs the REAL shipped page (node) against the REAL component response — envelope included. **.136i: everything showed but nothing was USABLE** — raw template text in many labels (save_variables...), OctoPrint/Temperature/Live-Tuning visible although the LCD hides them, no way back up, badge saying Klipper nicht bereit although Klipper was fine: the live snapshot had failed and its REASON was thrown away (that handler had never run in the field - the page JS was dead until .136h); enable strings also ship WITH braces, which the evaluator parsed as a dict literal, so NOTHING was ever hidden even with live data; and the sender would have POSTed raw templates (968 of 1964 commands carry jinja). .136i: the component never fails silently (reason in the badge, per-object retry), the page hides/shows exactly like the display, renders every command before sending, adds back-navigation, input value fields, the M117 notification history, the console and the status dashboard. **.136j: the .136i badge paid off immediately** - the surfaced reason revealed the real bug: the component called moonraker with the klipper-style lookup_object (AttributeError on every live poll since the extension existed - masked by an offline fake that implemented the wrong method). Now lookup_component (+ fallback), and the offline fake mirrors only the REAL moonraker API surface |

Diagnostics: SHOW_STATUS · SELF_TEST · KAMP_STATUS · HOST_CHECK (Pi health) · _CHECK_INSTALL at boot.

## 22. Limits & known behavior

- **nozzle diameter = printer.cfg truth**: every generator (labels, ties,
  angles, frames, litho, seals, bridge) reads `[extruder] nozzle_diameter`
  from printer.cfg — line widths, E-per-mm and hatch spacing all derive from
  it (fallback 0.6, console note when it deviates)
- texture tool: outer-wall vertices move, and (.136v) inner walls FOLLOW
  the embossing in BUMPS mode (gap stays one line width — no valley
  capping, wall contact kept, winding-aware); the first outer vertex of a
  file and zero-length restarts stay untextured (no approach direction),
  a file without outer walls gets zero shifts — and the 100th version
  (V99 full) refuses with a cleanup hint instead of overwriting
- sequential detection needs the previous object ≥1.6 mm tall (protects by-layer prints)
- legacy files (no APPLY_TYPE): feature factors apply instantly, but only the
  GLOBAL factor is re-applied at layer 2 / after resumes
- "State re-synced" after object-change resumes: cosmetic self-healing
- AS SLICED = no injections, but homing/mesh/prime still run BEFORE the file
- temperature tower holds the last temperature at the end — stop it afterwards
- a2d/accel_to_decel no longer exists — minimum_cruise_ratio replaced it everywhere
- **the real bed is NOT position_max:** the steppers' position_max is
  lifted on this machine (micro probe + mesh rides beyond the plate). All
  generators, the prime line and the park corners use the
  **[gcode_macro _R2_CONFIG]** settings macro in printer.cfg instead — without
  it everything falls back to the Ender-3 default 220×220 (x 0…220, y −3…217)
  and the console says so:

  ```
  [gcode_macro _R2_CONFIG]
  variable_bed_min_x: 0.0
  variable_bed_max_x: 220.0
  variable_bed_min_y: -3.0
  variable_bed_max_y: 217.0
  gcode:
      # config carrier only - never runs
  ```

  **Position options (all optional — defaults = the classic behavior):**
  `variable_present_x: 10.0` / `variable_present_y: 228.0` — where PRINT_END
  presents the finished part (always clamped to your axes);
  `variable_wipe_x` / `variable_wipe_y` — the anchor of the nozzle-wipe pad
  (default −1 = the axis-minimum corner). On another printer or with the pad
  somewhere else, set them once — no macro editing needed.

  ⚠ **Never use a raw `[r2_postproc]` section** (the pre-.82 form, R92…R81):
  Klipper refuses unknown sections outright — „Section 'r2_postproc' is not a
  valid config section", the printer ends up in a halt loop. A settings macro
  (like KAMP's `_KAMP_Settings`) is the only valid carrier; `setup.sh`
  migrates an old section automatically (backup included).

## 23. Cheat sheet: LCD paths & Mainsail commands

**LCD quick paths**

| I want to… | LCD path |
|---|---|
| print with my overwrites | Start Print? > AS LEGACY |
| print exactly as sliced | Start Print? > PRINT AS SLICED |
| system takeover of a sliced file | Start Print? > PRINT AS LEGACY |
| adjust Z live | Live Tuning > Z +0.04/−0.04 |
| hotend/bed/fan/Z-offset fast | Live Tuning > Hot / Bed / Fan / Zoff |
| slow everything down | Live Tuning > Spd per feat > Glob |
| machine limits live | Live Tuning > Velocity |
| flow/PA/retraction live | Live Tuning > Extrusion |
| pause at layer 17 | Live Tuning > Pause & Control > Pause@: 17 |
| skip an object | Live Tuning > Objects (2×) |
| change material preset | Pre-Print > Material > LOAD NOW |
| compare with the file values | Pre-Print > Temperatures > File H:/File B: |
| first layer slower/faster | Pre-Print > 1st layer % |
| calibrate flow | Maintenance > Flow Cal. |
| run a temperature tower | Maintenance > Temp Tower |
| print cable ties | Tools > Cable ties > Create (press 2×) |
| print an angle bracket | Tools > Angles+Flat > Mode > Angle, Settings, Create |
| join two boards flush | Tools > Angles+Flat > Mode > Flat splice, Left/Right, Create |
| print a lithophane | Tools > Lithophane > Images (Create) — slot press, then start |
| print a color picture | Tools > ColorPicture > Images — slot press, swap filament at every beep |
| print building bricks | Tools > Bricks > Catalog (count parts) > Create |
| turn a sliced file into a kit | Tools > Bricks > Kit from file > CREATE kit |
| print figures | Tools > Bricks > Figures > Scale/Count > CREATE figure |
| print a gasket | Tools > Gaskets > Settings, Create (press 2×) |
| print a picture frame | Tools > Frames > Settings, Create (press 2×) |
| cast a mold from a print | Tools > Casting molds > Split & part > Build mold (press 2×) |
| cast a blank mold with relief seat | Tools > Casting molds > Blank molds > Build blank mold (press 2×) |
| frame as glue kit | Tools > Frames > Preset 13x18, Border 16+, Create — strips + plate, glue the joints |
| fuzzy skin / dimples on a part | Pre-Print > Texture — pick mode + values, > Apply, check the _TX file in the viewer |
| delete a lithophane image | Tools > Lithophane > Delete image — press the slot twice |
| test ironing | Maintenance > Ironing Cal. |
| purge / cold pull | console `PURGE_MORE` (15 mm) · Maintenance > Filament |
| shutdown the Pi | System > Pi shutdown? arm, then >> PI SHUTDOWN NOW (2 presses) |
| cable/lamp hole in a range part | Pre-Print > Range/Stop > Fl.hole / Top hole, then Create |
| which g-code files are outdated | System > File check — console lists every file; Retag old (2×) upgrades them |
| printer off, Pi stays on | PRINTER_POWER_OFF (console — needs the relay, ch. 26) |

**Mainsail — the 20 you will actually use**

```
SHOW_STATUS · SET_MATERIAL MATERIAL=PLA · SET_OVERRIDE_VALUE NAME=… VALUE=… ·
TOGGLE_OVERRIDE NAME=… · CLEAR_OVERRIDES · PRINT_AS_SLICED / PRINT_WITH_OVERRIDES /
PRINT_AS_LEGACY · SET_GLOBAL_SPEED · SET_GLOBAL_ACCEL · SET_LIVE_VELOCITY ·
SET_LIVE_MINIMUM_CRUISE_RATIO · SET_LIVE_PRESSURE_ADVANCE · SET_LIVE_RETRACTION ·
SET_FLOW_RATE · SET_GLOBAL_ACCEL_PERCENT PERCENT=150 · SET_FAN_SCALE · PAUSE · RESUME · CANCEL_PRINT (2×) ·
PAUSE_AT_LAYER LAYER=n · SKIP_OBJECT OBJECT=name · GEN_LABELS TEXT="A|B" ·
GEN_CABLE_TIES COUNT=6 LENGTH=120 · GEN_ANGLES ANGLE=90 WIDTH=25 WALLS=4 INFILL=60 ·
GEN_FRAME PRESET=10x15 DEPTH=8 CLOSURE=BACK HANG=TOP STAND=1 ·
TEXTURE_APPLY FILE=myfile.gcode MODE=BUMPS PATTERN=WAVES SCALE=10 AMP=0.35 ·
SET_LAYER_RANGE FLOOR=3 FLOOR_HOLE=15 TOP_HOLE=28 ·
FILE_CHECK · FILE_CHECK RETAG=1 CONFIRM=1 ·
CALIBRATE_PA · FLOW_CAL MEASURE=0.46 · TEMP_TOWER_START START=200 END=230 STEP=5 BAND=10
```

**Mainsail's macro panel:** every macro carries a one-line `description:`
(the same text Mainsail shows under the macro name). Type the macro name in
the console with a `?` and no parameters — most macros answer with their
usage line and the valid values instead of doing something.

**Web-LCD:** `web/index.html` is the complete operating console for the
12864 LCD in the browser — same menus, same conditions, same values.
Layout (.136i): a **status strip** on top (mode, file, hotend/bed temps
with targets, fan %, feed % + speed, flow %, PA, accel, progress with
layer count, elapsed and estimated remaining time, and the feature
currently printing with ITS speed/accel/flow/PA), the **menu tree** on
the left — a true LCD mirror: same order, rows whose enable condition is
false are INVISIBLE (OctoPrint/Temperature/Live Tuning appear exactly
when the display would show them), names evaluated live — **details &
send** top right (select an entry: evaluated name, its LCD visibility,
for input items a value field `[min .. max]`, and the RENDERED G-code
preview — jinja evaluated exactly like the LCD does before executing a
command; nothing raw is ever sent), the **LCD notifications** bottom
right (the current M117 line pinned on top, the full history below in
arrival order — scroll back any time), and the **console** across the
whole bottom width (the printer's echo/RESPOND stream, auto-scrolling,
plus a G-code input line — Enter sends, arrow-up recalls the last
command). **.136k:** the dashboard values sit in a responsive **grid**
(2–3 rows instead of one endless line) with the font up two sizes — the
**whole page including the console fits without scrolling**; the console
got a **toolbar** like Mainsail: *Leeren* (clear), a **search field**
(filters the history live) and the autoscroll toggle. The live poll also
survives value-less snapshots now (see Troubleshooting: Tools menu /
SD list empty). **.136m (R214):** the live area at the top is grouped
into STACKED topic columns — mode + file, temperatures (nozzle/bed/fan),
speed (feed/accel), flow + PA, times (progress %, elapsed, remaining) —
and ONE full-width line at the very bottom carries layer + current
feature. Same poll, same data, zero extra requests (the MCU load does
not change). **.136l (R213):** the page NEVER scrolls anymore —
`100dvh` layout with `overflow:hidden`, only the console scrolls INSIDE
its own box, and the G-code input line moved UP to sit with the console
buttons (always visible, no scrolling to reach it); on screens under
900 px the columns stack without ever growing the page. Font sizes: the
header carries global **A+ / A−** buttons (11–24 px in 0.5 steps,
remembered per browser) AND three separate dials — notifications,
file browser + send menu, console — each −5…+8 px around the base
(also remembered). LCD notification text grew 3–4 sizes, the detail
text above it 2, the file browser 1. **↑ zurück** or a click into the breadcrumb brings you back up
a level. On the printer's host it loads the live tree (`web/r2_menu.py`
Moonraker extension, `GET /server/r2_menu/tree`) and **evaluates the
menu templates live**: every 3 s it fetches a pruned printer snapshot
(`GET /server/r2_menu/live` — the objects the menu templates + dashboard
reference, fat values pruned to what the menus read) and renders names
exactly as the LCD does — same jinja dialect, cross-checked against the
1.910 render tests AND an 80-command sender parity vs jinja2. The poll
is CHEAP by design: the extension queries only the objects the templates
actually reference (not every macro object), fat lists are pruned, a
2.5 s cache shares one query across tabs — and if the snapshot ever
fails, its REASON shows in the badge (nothing fails silently anymore).
Since .136m two more guards: `configfile` is requested as `settings` only
(klippy used to serialize the ENTIRE config text on every poll — one of
the .136l 'Timer too close' contributors), and after a start-type command
(SDCARD_PRINT_FILE / PRINT_AS_… / RESUME) the page pauses the live poll
for 25 s — the homing phase schedules its moves just-in-time and does not
need dashboard updates; the console keeps flowing.
Opened from anywhere else it falls back to the embedded JSON snapshot
(labels still evaluate if the live endpoint answers). Commands go
through Moonraker's own `/printer/gcode/script` endpoint. **Install is ONE command** (SSH on the Pi):
`bash ~/printer_data/config/klipper-e3-r2d2/web/install_web.sh` — it copies
the Moonraker extension, adds the `[r2_menu]` section (with a backup of
moonraker.conf) and sets up its own small nginx site on a free port
(7126/7186/7196 — your Mainsail nginx config is never touched;
`--uninstall` removes everything again). Then open the URL the installer
prints: `http://<pi-ip>:7126/r2lcd/` — bookmark it on your phone. After
menu changes: press "Export neu laden" on the page, or
`python3 tools/menu_json_export.py` (plus `--embed web/index.html`). It is a second DISPLAY, not a second brain:
values always come from the printer; file management and the G-code viewer
stay with Mainsail.

**Abbreviation decoder** — the short codes the console, M117 and the LCD use:

| Code | Means | Code | Means |
|---|---|---|---|
| **L1 / L2** | layer 1 / layer 2 (temp & fan system, ch. 8) | **PA** | pressure advance |
| **OW / IW** | outer wall / inner wall | **SP / SO** | sparse infill / solid infill |
| **TP / BT** | top surface / bottom surface | **BR / GP** | bridge / gap fill |
| **SU / IR** | support / ironing | **SK / BM** | skirt / brim |
| **FS_* / FA_*** | file's measured speed / acceleration of that feature | **o:ON** | that feature's override is ON |
| **Src:** | where a value comes from: file / overwrite / live | **Now:** | the feature printing right now |
| **LH** | layer height | **CS** | countersink (generator holes) |
| **Vers / V01…** | the generated file's version number | **CLA / LOO** | CLASSIC / LOOP closure (cable ties) |
| **Boss** | thick wall ring around a generated hole | **Bridge-first** | cap layer 1 anchors the top hole edge (no sagging) |
| **Zoff** | Z offset (babystepping total) | **RetLen / RetSpd / Unret** | retract length / speed / unretract speed |
| **MCR** | minimum cruise ratio | **SCV** | square corner velocity |

## 24. Complete macro index
416 entries: every public macro with parameters (defaults in parentheses; blank = no parameters) plus the internal hooks worth knowing. Internal helpers (leading `_`) are not user-facing — **272 public + 114 internal macros exist in total** (386 `gcode_macro` + 30 `delayed_gcode`, counted from the .cfg files, not copied from an older list). Grouped by module file — the same file you would edit.


### State & sentinels — 01_state.cfg (14)
| Macro | Parameters | Purpose |
|---|---|---|
| **DOCTOR_PACK** |  | Build the evidence pack (logs + system state) for support - one downloadable file |
| **PP_ENGINE_INFO** |  | Show which post-processor engine runs and what the difference is |
| **SET_PP_ENGINE** | MODE='' | Choose the post-processor engine: stable (today's) or next (the experimental copy) |
| **SET_RECOVERY** | MODE='' | Enable/disable the MCU-shutdown auto-recovery (MODE=on/off) |
| **TOGGLE_PP_ENGINE** |  | Flip between the stable and the experimental post-processor (menu hook) |
| **TOGGLE_RECOVERY** |  | Toggle the MCU-shutdown auto-recovery (menu hook) |
| _CHECK_INSTALL |  | Verify all macro modules are loaded and current (runs at boot) |
| _INIT_DEFAULTS |  | seed the live values from save_variables at boot (PA smoothing, recovery flags) |
| _PACE | P=100 | Micro-pause between disk writes (idle only - never dwells during a print) |
| _R2_DOCTOR |  | Old name of DOCTOR_PACK |
| _R2_VERSION |  | Version of the macro package |
| _SDM |  | holder object for the SD list/state the menus and the watcher query |
| _STATE |  | Internal state store (do not call directly) |
| _V01_STATE |  | Version sentinel of 01_state.cfg |

### Sounds — 02_sounds.cfg (8)
| Macro | Parameters | Purpose |
|---|---|---|
| **M300** | P=100, S=1000 | single beep — wrapper; the real beep lives on as M99300 |
| **PLAY_SOUND** | NAME='r2_click' | play a tune by name (ch. 16) |
| **TEST_SOUNDS** |  | play all 20 tunes in sequence |
| **TOGGLE_SOUNDS** |  | sounds on/off (persisted: sound_on) |
| _PLAY_JOB_START |  | Watcher: a queued generation starts building now |
| _SOUND_LIB | TUNE='', NAME='' | Internal sound database (do not call directly) |
| _UI_SOUND | NAME='r2_click' | UI confirmation sound - SILENT while a print runs: queue management and generator presses beep when idle, never into a running print. Errors and alarms (NOTIFY SOUND=...) keep their sound - always. |
| _V02_SOUNDS |  | Version sentinel of 02_sounds.cfg |


### Notifications — 04_notify.cfg (3)
| Macro | Parameters | Purpose |
|---|---|---|
| **NOTIFY** | TEXT, LEVEL='info', SOUND | notification helper: text + sound in one call |
| **SHOW_STATUS** |  | full status: mode, material, overrides, live values |
| _V04_NOTIFY |  | Version sentinel of 04_notify.cfg |

### Materials & profiles — 05_materials.cfg (33)
| Macro | Parameters | Purpose |
|---|---|---|
| **DEFAULT_PRESETS_INFO** |  | list all default profiles (slot, material, marker, epoch) |
| **DELETE_DEFAULT_PRESET** | N=1..8 | delete default profile N |
| **DELETE_DEPOT_PRESET** | CONFIRM=0 | Delete the Depot profile |
| **DEPOT_INFO** |  | Show the Depot profile status (console) |
| **FILE_PROFILES_INFO** |  | what is stored for the selected file: pre/post, epochs, which one auto-load picks |
| **FILE_PROFILE_AUTO** | FILE=<relpath> (int.) | watcher hook on every file selection: sets the menu flags + applies the newer profile when Auto-load is ON |
| **FILE_PROFILE_DELETE** | WHICH=pre/post | delete the selected file's profile slot (other slot stays) |
| **FILE_PROFILE_LOAD** | WHICH=pre/post | load the selected file's profile slot |
| **LOAD_DEFAULT_PRESET** | N=1..8 | load standalone default profile N (values + ON switches via _PROFILE_APPLY) |
| **LOAD_DEPOT_PRESET** | CONFIRM=0 | Apply the Depot profile to the Pre-Print settings |
| **OPT_INFO** |  | Show the last print snapshot / pending question (console) |
| **SAVE_DEFAULT_PRESET** | N=1..8 | save the current override state as default profile N |
| **SAVE_DEPOT_PRESET** | CONFIRM=0 | Save ALL current Pre-Print settings as the Depot profile |
| **SAVE_FILE_PROFILE** | WHICH=pre | save the selected file's CURRENT pre-print state as its 'pre' profile |
| **SAVE_MATERIAL_TEMPS** | MATERIAL=<current> | save current values as this material's preset — works WITHOUT loading it first |
| **SET_MATERIAL** | MATERIAL=<current>, APPLY_PRESET=1 | select material; APPLY_PRESET=1 also loads its preset |
| **SHOW_MATERIAL** |  | show the current material + its stored preset |
| _MATERIALS |  | Internal material database (do not call directly) |
| _OPT_APPLY_PICKED | IDX=0 | Load an optimized file's values into Pre-Print |
| _OPT_BAKED | SNAP | Optimized-file replay - the values baked into the copy apply |
| _OPT_END_ASK |  | Compare the final snapshot vs the baseline, arm the question |
| _OPT_PROMPT_NO |  | Rate-print answer NO - discard the live tuning |
| _OPT_PROMPT_RESOLVE |  | End an unanswered rate-print question |
| _OPT_PROMPT_YES |  | Rate-print answer YES - write the optimized copy, keep the values |
| _OPT_QUEUE_JOB |  | Ask the watcher for the optimized copy |
| _OPT_RESTORE_BASELINE | QUIET=0 | Restore the pre-print override state |
| _OPT_SAVE_LATER |  | Save the LAST print's snapshot as an optimized copy |
| _OPT_SNAP_WRITE | DEST='' | Snapshot the current override state |
| _PROFILE_APPLY | SRC=default N= · SRC=file WHICH= FILE= (int.) | the ONE apply path: values + ON switches + feature values + material |
| _PROFILE_SAVE | WHICH= FILE= (int.) | snapshot the live state and hand it to the writer |
| _PROFILE_WRITE | WHICH= FILE= (int.) | merge the snapshot into file_profiles (other slot + other files preserved), bump the epoch |
| _PROF_ARM | KEY='', WHICH='confirm' | Profiles: arm the 2-press confirm for KEY |
| _V05_MATERIALS |  | Version sentinel of 05_materials.cfg |

### Temperatures — 06_temp_controls.cfg (18)
| Macro | Parameters | Purpose |
|---|---|---|
| **LAYER_MARK** |  | layer marker (inserted by the post-processor) |
| **M104** | S=-1, T | hotend temp — interceptor, redirects by layer (real: M99104) |
| **M106** | S=255 | part fan — scaling + from-layer-2 rule |
| **M109** | S=-1, T | like M104, but waits |
| **M140** | S=-1 | bed temp — interceptor (real: M99140) |
| **M190** | S=-1 | like M140, but waits |
| **M204** | P, S, T | acceleration — interceptor (M99204): feature accel while that feature's override is ON, else global overwrite ON → your accel, else file 1:1 |
| **M220** | S=100 | speed — interceptor (real: M99220): L1 cap while layer 1 runs; ALWAYS stores the clean global % as g_speed_clean — the base command features use |
| **M221** | S=100 | Flow factor - captured from the file, redirected to YOUR flow when ON |
| **PAUSE_AT_LAYER** | LAYER=0 | one-shot pause at layer n (n greater than 1) |
| **PAUSE_NEXT_LAYER** | REASON='next layer' | one-shot pause at the next layer boundary |
| **SET_LIVE_BED_TEMP** | T=-1 | change the bed target live |
| **SET_LIVE_HOTEND_TEMP** | T=-1 | change the hotend target live |
| **SET_STOP_AT_LAYER** | LAYER=0 | Stop the print NORMALLY when layer N begins (0 = off) |
| _ACCEL_SET | VALUE=0 | Set move accel + update the M204 tracker |
| _END_AT_LAYER | LAYER=0 | Planned end at layer N : stop the file + normal end choreography |
| _SPEED_COMBINED |  | apply the effective speed factor - clean global x the CURRENT feature override |
| _V06_TEMPS |  | Version sentinel of 06_temp_controls.cfg |

### Start confirm — 07_start_confirm.cfg (10)
| Macro | Parameters | Purpose |
|---|---|---|
| **CANCEL_PENDING_PRINT** |  | start dialog: cancel (nothing is hot yet) |
| **CLEAR_OVERRIDES** |  | all switches OFF (values stay stored) |
| **PRINT_AS_LEGACY** |  | start dialog: AS LEGACY |
| **PRINT_AS_SLICED** |  | start dialog: answer AS SLICED |
| **PRINT_WITH_OVERRIDES** |  | alias for AS LEGACY (merged mode) |
| **SET_OVERRIDE_VALUE** | NAME, VALUE | generic: NAME=feat_spd_<code> / feat_acc_<code> / feat_on_<code> for 16 codes + all legacy names; feat_on=0 resets speed→100% + accel→file M204 + ironing flow→slicer value |
| **TOGGLE_FIRST_LAYER_RULES** |  | First-layer rules also in AS SLICED on/off |
| **TOGGLE_OVERRIDE** | NAME='' | flip one override switch |
| **TOGGLE_START_CONFIRMATION** |  | start dialog on/off (persisted: start_confirm) |
| _V07_CONFIRM |  | Version sentinel of 07_start_confirm.cfg |

### Print start / stop — 08_print_start_stop.cfg (33)
| Macro | Parameters | Purpose |
|---|---|---|
| **FILE_AS_PRESET** |  | Take the previewed file parameters as Pre-Print values (temps/fan/PA) - with beep |
| **FIX_FILE** | WHAT=RETRACT/VOL/FLOWCAP/TRAVELACC/QUALITY/SPEED, CAP=(12), ACCEL=(8000) | repair the SELECTED file in place: retract pairs → G10/G11 · volumetric E → mm · flow cap mm³/s · travel accel · QUALITY = travel golden rule (.136n, ch. 3.4b) · SPEED = direct ways + ironing skipped (.136n) |
| **G28** |  | Home - tells the host that the machine is moving |
| **M23** | `filename` (rawparams) | the stock SD list's file tap (real: M9923): selects the file via SDCARD_PRINT_FILE **and** opens the start dialog — a folder link picked there prints exactly like a browser pick; the stripped `_fn` also takes the plain `/name.gcode` Klipper passes |
| **M24** |  | Start/resume SD print - fresh starts ask first |
| **PRINT_END** |  | end choreography: heaters/fans per settings, stats, sound, full _PRINT_CLEANUP |
| **PRINT_START** | BED, HOTEND_FIRST, HOTEND_AFTER, BED_AFTER, MATERIAL='PLA', LAYER_HEIGHT=0.2, TOTAL_LAYERS=0, OUTER_WALL_SPEED=0, SUPPORT_SPEED=0, IRONING_SPEED=0 | start choreography — called by the sliced file |
| **RETRACT_FIX** | STATE=1 | Old-file rescue - rewrite the retracts of the NEXT upload to G10/G11 (your retraction applies) |
| **SDCARD_PRINT_FILE** | FILENAME='' | Print button: load the file, hold it at position 0, ask first |
| **SET_LAYER_RANGE** | START, END, FLOOR, FLOOR_SHAPE (0/1), FLOOR_FILL (0/1), TOP, TOP_SHAPE, TOP_FILL, FLOOR_HOLE, TOP_HOLE, BRIM | layer-range excerpt with raft/cap, centered floor+top holes (E14/E27 presets: ch. 5.1); refuses while a print runs |
| **START_PRINT** |  | old macro name: marked = no-op · legacy = real legacy start (dialog or auto-prep) |
| **OBJ_EXPORT** | FILE=printer.print_stats.filename | default('' |
| _APPLY_OVERRIDES_CORE |  | Apply PA/retract/accel/flow overwrites |
| _DIALOG_PEEK |  | Start dialog opened - force a fresh file-info peek |
| _FILE_INFO | MATERIAL, SLICER, FW, VOLUMETRIC, OPT=0, RETRACT, RETRACT_STATUS='', RETRACT_MAX=0, LAYER_HEIGHT=0, TOTAL_LAYERS=0, LINE_WIDTH=0, LINE_WIDTH_FIRST=0, LINE_WIDTH_WALL=0, FLOW_RATIO=0, PA=0, BY_OBJECT=0, TYPES, CUSTOMGROUPS, NOZZLE=0, WALL_LOOPS=0, IRONING_FLOW=0, DERIVED=0, CONF=0, COVER=0, MAXRATE=0, TRAVEL=0, SEAM, SEAMN=0 | File parameters - injected by the R2 post-processor |
| _FILE_INFO_RESET |  | Clear ALL file-parameter state - no leftovers from the previous print/selection |
| _LEGACY_AS_SLICED |  | Legacy file AS SLICED: home + file temps + purge, then the file rules |
| _LEGACY_DIALOG |  | Legacy file detected: pause + ask AS SLICED or AS LEGACY |
| _LEGACY_HOME |  | Legacy file: home + overwrites even without full prep (phase 1, internal) |
| _LEGACY_PREP |  | Auto level+purge a legacy print at its start (phase 1: pause, internal) |
| _MOVEMENT_START | APPLY=0 | Pure movement file: home + heat + purge infrastructure |
| _OPT_END_CAPTURE |  | PRINT_END hook: offer the print's live tuning as an optimized file |
| _PREHEAT_SELECTED |  | Preheat to standby levels the moment a file is selected |
| _PREVIEW |  | Selected-file preview card, in-memory (pushed by the watcher, internal) |
| _PREVIEW_SET |  | Watcher pushes the selected file's parameters here (in-memory, internal) |
| _PREVIEW_TEMPS | HOTEND=0, BED=0, FAN=0 | File preview temps from the watcher push (internal, display only) |
| _PRIME_LINE | LAYER_HEIGHT=0.2, FLUSH=6 | Purge/prime line: nozzle wipe + X only, right -> toward x=0, probe-aware |
| _PROBE_STOW |  | Hook - stow/dock the probe before the purge line (EDIT for dockable probes!) |
| _RUN_PRINT_START | APPLY=0, LEGACY=0 | the actual start sequence after confirmation (APPLY=1 applies overrides, LEGACY=1 hands over to a self-heating file) |
| _SELECT_FILE | FILE='' | Swap the held/selected file for a freshly GENERATED one |
| _UNIVERSAL_START_INTERCEPT |  | Catch EVERY print start: hold the file + ask how to proceed |
| _V08_STARTSTOP |  | Version sentinel of 08_print_start_stop.cfg |
| _WAIT_IDLE_RESTORE |  | Restore the configured idle_timeout after the start dialog |

### Pause & filament — 09_pause_filament.cfg (18)
| Macro | Parameters | Purpose |
|---|---|---|
| **CANCEL_PRINT** |  | 1st press arms (expires 60 s, also while paused), 2nd press cancels + _PRINT_CLEANUP |
| **CHANGE_FILAMENT** |  | M600 for humans — works from idle too (heats) |
| **CHANGE_FILAMENT_RESUME** |  | internal continuation after the load |
| **M0** |  | slicer pause — mapped to PAUSE |
| **M1** |  | slicer pause — mapped to PAUSE |
| **M600** |  | filament change (park, unload, wait for load) |
| **PAUSE** | REASON='User' | pause + park (mode-aware) |
| **PURGE_MORE** |  | purge 15 mm more (after change/resume) |
| **QUICK_PAUSE** |  | alias for PAUSE |
| **RESUME** |  | the full resume sequence (ch. 6) |
| _FILAMENT_INSERTED |  | (Insert) Filament detected - acknowledge |
| _FILAMENT_RUNOUT |  | (Runout) Filament empty - alarm + pause at the next layer boundary |
| _PARK_HEAD |  | park the head at a safe point before a pause (retract stored for the resume) |
| _PRINT_CLEANUP |  | internal: resets ALL per-print state (called by PRINT_END/CANCEL/watcher — settings + mesh stay) |
| _PURGE_STRIP | MM=15 | Purge as a fat line beside the objects (never the park corner) |
| _RESTORE_IDLE_TIMEOUT |  | Restore idle timeout after pause/cancel/print end |
| _RESUME_COMMON | UNRETRACT=-1.0 | shared resume path: XY at safe height first, refill the park retract, then Z down |
| _V09_PAUSE |  | Version sentinel of 09_pause_filament.cfg |

### Live tuning — 10_live_tuning.cfg (52)
| Macro | Parameters | Purpose |
|---|---|---|
| **APPLY_TYPE** | TYPE='' | feature switch: sets current_type + applies the active overrides for THIS feature (speed % x clean global via M99220, absolute accel via M99204, ironing flow via M99221) — injected after every ;TYPE: by the post-processor |
| **BABYSTEP_DOWN** |  | Z --0 mm live |
| **BABYSTEP_DOWN_FINE** |  | Z --0 mm — quick rescue step |
| **BABYSTEP_UP** |  | Z offset +0.04mm (full step, live, with move) |
| **BABYSTEP_UP_FINE** |  | Z +0 mm — quick rescue step |
| **G10** |  | Firmware retract + optional Z-hop lift |
| **G11** |  | Optional Z-hop lower + firmware unretract |
| **PARAM_SOURCES** |  | Value provenance - file vs your override vs LIVE now, for every parameter |
| **SET_EXTRUDER_DRIVE** | TYPE=DIRECT\ | BOWDEN |
| **SET_FAN_CLAMP** | ON=-1, MIN=-1, MAX=-1, BRIDGE=-1 | fan curve clamp: every M106 runs between MIN/MAX %, BRIDGE lifts the fan on bridge sections (0 = off); -1 = leave unchanged |
| **SET_FAN_HOLD** | PERCENT=0 | Hold the part fan at a fixed % - replaces the file's M106 values (SET_FAN_HOLD PERCENT=40, 0 = file rules again) |
| **SET_FAN_LIVE** | PERCENT=, ON=1 | your ABSOLUTE fan % — beats hold, scale, clamp and the layer-1 rule; ON=0 hands control back to the file chain |
| **SET_FAN_SCALE** | PERCENT=100 | fan scaling % |
| **SET_FEAT_PA** | FEATURE, PA=-1 | pressure advance for ONE feature, 0 = off — applied at its boundaries, global PA returns after |
| **SET_FEAT_SHAPER_OFF** | FEATURE, STATE=-1 | input shaper OFF while one feature prints — freqs saved/restored, safety net at PRINT_END/cancel |
| **SET_FLOW_RATE** | PERCENT=100 | global flow % (M221) |
| **SET_GLOBAL_ACCEL** | ACCEL=4000 | global acceleration, mm/s²; a feature with its own accel keeps it |
| **SET_GLOBAL_ACCEL_PERCENT** | PERCENT=100 | scales ALL per-feature accel limits by % (10–300) in the same ratio — the global accel itself stays absolute |
| **SET_GLOBAL_SPEED** | PERCENT=100 | global speed % (M220 style, never capped); the running feature stays on top — re-applied immediately |
| **SET_INFILL_ACCEL** | ACCEL=0 | Infill accel mm/s2, 0=global (SET_INFILL_ACCEL ACCEL=5000) |
| **SET_INFILL_SPEED** | PERCENT=100 | Infill speed in % (SET_INFILL_SPEED PERCENT=120) |
| **SET_INNER_WALL_ACCEL** |  | (compat no-op) per-feature tuning removed in .38 - use the global setter |
| **SET_INNER_WALL_SPEED** |  | (compat no-op) per-feature tuning removed in .38 - use the global setter |
| **SET_IRONING_ACCEL** |  | (compat no-op) per-feature tuning removed in .38 - use the global setter |
| **SET_IRONING_FLOW** | PERCENT=100 | ironing-only flow override |
| **SET_IRONING_SPEED** | PERCENT=100 | Ironing speed in %% ON TOP of the global factor |
| **SET_IRONING_TEMP** |  | (compat no-op) per-feature tuning removed in .38 - use the global setter |
| **SET_LIVE_ACCEL** | ACCEL=4000 | Global acceleration cap in mm/s2 - every move, travels included (SET_LIVE_ACCEL ACCEL=4000) |
| **SET_LIVE_MINIMUM_CRUISE_RATIO** | VALUE=0.5 | minimum cruise ratio, live |
| **SET_LIVE_PA_SMOOTH** | TIME=0 | PA smooth time, live |
| **SET_LIVE_PRESSURE_ADVANCE** | VALUE=0.045 | pressure advance, live |
| **SET_LIVE_RETRACTION** | LENGTH, SPEED, UNRETRACT_SPEED, EXTRA | live retraction — one parameter, the others stay |
| **SET_LIVE_SQUARE_CORNER** | VALUE=5 | square corner velocity, live |
| **SET_LIVE_VELOCITY** | VELOCITY=300 | max velocity, live |
| **SET_OUTER_WALL_ACCEL** | ACCEL=0 | Outer wall acceleration mm/s^2 - only this feature |
| **SET_OUTER_WALL_SPEED** | PERCENT= / ACCEL= | legacy-friendly per-feature setters: forward to feat_spd/feat_acc + ON — % sits on top of the CLEAN global |
| **SET_PRESSURE_ADVANCE** | ADVANCE, SMOOTH_TIME | interceptor — with the PA override ON your value wins |
| **SET_RETRACTION** | RETRACT_LENGTH=0.75, RETRACT_SPEED=35, UNRETRACT_SPEED | firmware retraction — interceptor, override-aware |
| **SET_SOLID_INFILL_ACCEL** |  | (compat no-op) per-feature tuning removed in .38 - use the global setter |
| **SET_SOLID_INFILL_SPEED** |  | (compat no-op) per-feature tuning removed in .38 - use the global setter |
| **SET_SUPPORT_ACCEL** | ACCEL=0 | Support acceleration mm/s^2 - only this feature |
| **SET_SUPPORT_SPEED** | PERCENT=100 | Support speed in %% ON TOP of the global factor - only this feature |
| **SET_UNRETRACT_EXTRA** | EXTRA=-1 | every unretract adds EXTRA mm — seals the dot after a travel; 0 = off |
| **SET_Z_HOP** | ENABLE=-1, HEIGHT=0 | Z-hop on firmware retracts: SET_Z_HOP ENABLE=1 HEIGHT=0.4 |
| _APPLY_OV_RETRACT |  | Push the armed retraction overrides into the firmware |
| _FAN_CHAIN_NOW |  | The fan computation path right now, as one line (internal, R175c) |
| _FEAT_TUNING_RESTORE |  | safety net - restore global PA + input shaper after a feature tuning left them on |
| _LIVE_RESET |  | Reset all live tuning values to default (100%/off) |
| _SET_PA | ADVANCE, SMOOTH_TIME | Set PA once - repeat values are swallowed |
| _SYNC_OV_ACCEL |  | Mirror the pre-print accel override into _STATE |
| _SYNC_OV_FEAT |  | Refresh the _STATE override mirrors from save_variables |
| _V10_LIVE |  | Version sentinel of 10_live_tuning.cfg |

### Gantry sync — 11_gantry_sync.cfg (8)
| Macro | Parameters | Purpose |
|---|---|---|
| **SYNC_GANTRY** | FORCE=0, QUIET=0 | mechanical Z gantry sync — ONE Z stepper/driver only (needs [force_move] + a TMC driver); 2+ Z steppers → use Z_TILT |
| **TOGGLE_GANTRY_SYNC_BOOT** |  | sync at every boot on/off |
| **TOGGLE_GANTRY_SYNC_PRINT** |  | sync at every print start on/off |
| **TOGGLE_Z_TILT_BOOT** |  | z-tilt at every boot on/off (single-Z printers keep SYNC_GANTRY's switch) |
| **TOGGLE_Z_TILT_PRINT** |  | z-tilt at every print start on/off |
| **Z_TILT** | RETRIES, RETRY_TOLERANCE, QUIET=0 | Z_TILT_ADJUST over the [z_tilt] points — 2+ Z steppers only; defaults from the LCD settings, homes first |
| **Z_TILT_INFO** |  | lists the probe points, horizontal move Z, retries + tolerance (console) |
| _V11_GANTRY |  | Version sentinel of 11_gantry_sync.cfg |

### Maintenance — 12_maintenance.cfg (63)
| Macro | Parameters | Purpose |
|---|---|---|
| **BED_SCREWS_CANCEL** |  | Bed screws - cancel |
| **BED_SCREWS_DONE** |  | Bed screws - finish / take over |
| **BED_SCREWS_NEXT** |  | Bed screws - show the next screw |
| **BED_SCREWS_ROUND** |  | Bed screws - new round (re-measure all screws) |
| **BED_SCREWS_START** |  | Bed screw calibration on the LCD (Mainsail flow) - start |
| **BRIDGE_TEST** | OUT | build the bridging test file (long + short bridge) |
| **CALIBRATE_BELT** | MODE=TEST (default); MODE=COMPUTE X= Y= REF=; MODE=STATUS; MODE=RESET | belt-drive geometry: safe in-bed motion test (uses _R2_CONFIG limits, never hardcoded coords) + linear stretch scale stored in save_variables.belt_comp_x/y (diagnostic store; motion-layer applies the actual position-proportional correction — audit P1-02 rebuild) |
| **CALIBRATE_EXTRUDER** | TEMP=210, MEASURED=0, STEP='' | extruder steps: mark 120 mm, extrude 100, enter the rest |
| **CALIBRATE_MESH** |  | full bed mesh now (at bed temperature) |
| **CALIBRATE_PA** | TEMP, BED, START, STEP, LINES, LEN, SLOW, FAST, ACCEL, LAYER, SPACING, WIDTH — all from menu/preset | PA pattern print |
| **CALIBRATE_PA_SMOOTH** | START, STEP, LINES (0.02/0.01 def., 19 lines) | smooth-time pattern with YOUR PA fixed; mesh + prime first, babystepping works during the test |
| **CALIBRATE_PROBE_OFFSET** |  | probe Z offset — paper method, TESTZ, SAVE_CONFIG |
| **CALIBRATE_SHAPER** | AXIS='BOTH', FREQ_START, FREQ_END, MAX_SMOOTHING, AUTOSAVE | input shaper measurement (ADXL; ISHAPER.md) |
| **CLEAN_NOZZLE** | PASSES=2, TEMP=180 | Clean the nozzle: heat + zigzag wipe on the front-left pad (PASSES=2) |
| **COLD_PULL** | STEP='run', HOT=240, PULL=100 | cold pull wizard (2 steps + alarm) |
| **DELETE_MESH** | PROFILE='' | delete a profile (2x confirm) |
| **DUMP_RESONANCES** | AXIS='BOTH' | export raw shaper data |
| **FLOW_CAL** | MEASURE=<menu>, TARGET | wall measurement -> suggested flow % |
| **FLOW_CAL_APPLY** |  | apply the suggested flow (override ON, 50-150 % guard) |
| **FLOW_TEST** | SIZE=sv.flow_t_size | default(30, HEIGHT=sv.flow_t_height |
| **HOST_CHECK** |  | Pi health check |
| **IRONING_CAL** | F1=10, F2=15, F3=20, S1=20, S2=30, S3=40, TEMP=200, BED=60, LAYER=0.2, LEN=40, WID=24, ACCEL=3000 | 3-zone ironing test card |
| **IRONING_RESULT** | CARD=0 | Show the completed card's flow (% of a full line) and speed (mm/s); does not apply overrides. |
| **LEVEL_BED_SCREWS** |  | screw leveling with console report |
| **LOAD_BED_MESH** | PROFILE='' | load a mesh profile (menu list) |
| **LOAD_FILAMENT** |  | heat if cold + feed load_length mm |
| **MESH_BY_INDEX** | INDEX=-1 | load a mesh by menu index |
| **PA_RESULT** | SEG=0, VALUE=-1 | SEG=best line: PA computed + set live · VALUE=... skips the math |
| **PA_SMOOTH_RESULT** | SEG=n | line n → smooth = start+(n-1)·step, set live + override ON |
| **PLOT_CAL** | OUT | Plotter: calibration test plot - offset, dot raster, line quality |
| **PLOT_NAME_DEL_CHAR** |  | plot text file editor: delete char |
| **PLOT_STATUS** | CONFIRM=0 | draw the SHOW_STATUS report on one page |
| **PLOT_TEXT** | FILE='notes.txt' | draw a text file from the gcodes folder on paper |
| **PLOT_TUNE_RESET** |  | reset the plot start overrides to neutral |
| **PLT_FRAME** |  | Plotter: drive the pen around the configured bed frame (verify the limits) |
| **RESONANCE_DIAGRAM** | AXIS='BOTH', MODE='PRINT'/'PLOT' | CSV → printed/plotted diagram with the shaper table |
| **RETRACT_TOWER** | START=sv.rt_start | default(0.5, STEP=sv.rt_step |
| **RETRACT_TOWER_RESULT** | BLOCK=0 | Retract tower calculator: BLOCK=n -> retract = start + (n-1)*step -> retract override ON |
| **SAVE_MESH_AT_TEMP** |  | save the mesh as a bed-temp profile (e.g. r2_60C) |
| **SELF_TEST** |  | system self test — run before long prints |
| **SET_COLD_PULL_MATERIAL** | MATERIAL='' | Cold pull: material preset (PLA 230/90, PETG 250/115, ABS 260/130, TPU 235/100) |
| **SET_MESH_TRAVEL** | SPEED=-1 | Cap the mesh travel speed (SET_MESH_TRAVEL SPEED=120, 0 = off) |
| **SET_PLOT_PENZ** | DZ=0.05 | live: pen pressure fine tune (Z babystep) |
| **SET_PLOT_SHIFT** | X=, Y= | live: shift the whole drawing X/Y |
| **SET_PLOT_SPEED** | PCT=100 | live while plotting: pen speed % (M220) |
| **SHAPER_MANUAL** | AXIS, TYPE, FREQ, ON | manual shaper without an accelerometer: apply type/frequency live + boot override, `TYPE=CONFIG` restores printer.cfg (damping included), `ON=0` override off |
| **SHAPER_RESULT** | AXIS, TYPE, FREQ | shaper calculator: table show / apply the picked shaper + boot override |
| **TEMP_TOWER_GEN** | START=sv.ttg_start | default(220, STEP=sv.ttg_step |
| **TEMP_TOWER_RESULT** | BLOCK=0 | Temp tower calculator: BLOCK=n -> temperature = start + (n-1)*step -> temp override ON |
| **TEMP_TOWER_START** | START=200, END=230, STEP=5, BAND=10 | temperature tower (marker + legacy files) |
| **TEMP_TOWER_STOP** |  | stop early (otherwise the last temperature holds) |
| **TEST_RETRACTION** |  | retract/unretract pairs at temperature |
| **TUNE_PID** | HEATER='extruder', TARGET=210, FAN=-1, AUTOSAVE=1 | PID tune; FAN=% runs with the fan on (like printing) |
| **UNLOAD_FILAMENT** |  | heat + reverse (unload_length, LCD 40-150) |
| **UNLOAD_MESH** |  | clear the mesh + level again next time |
| _BED_SCREWS_UI |  | holder object of the screw-leveling assistant (round, current screw, last measurement) |
| _CAL_END |  | End a calibration like a print (heaters off, cooldown, idle) |
| _MESH_DEL_SLOT | INDEX=-1 | Delete mesh number n from the profile list (2-press, LCD slots) |
| _NOZZLE_WIPE | PASSES=2, TEMP=180 | Heat + zigzag wipe on the front-left pad, ends parked HIGH |
| _PLOT_END |  | Plot file end: heaters off, speed back to 100 |
| _PLOT_NAME_SET_CHAR | POS, CH | plot text file editor |
| _PLOT_START | EXTRUDE=0 | Plot file start: home + optional heat, then the pen rules |
| _RUN_PID_TUNE | HEATER='extruder', TARGET=210, AUTOSAVE=1, FAN=printer['save_variables'].variables.pid_fan_percent | default(100 |
| _V12_MAINT |  | Version sentinel of 12_maintenance.cfg |

### System — 13_system.cfg (15)
| Macro | Parameters | Purpose |
|---|---|---|
| **EMERGENCY_STOP** |  | immediate full halt |
| **FILE_CHECK** | RETAG=0, CONFIRM=0 | g-code inventory: tag version census (current/old/untouched/plotter) on console + LCD; `RETAG=1 CONFIRM=1` upgrades old files (.r2bak backup, never while printing) |
| **FORCE_END_PRINT** | CONFIRM=0 | emergency: ALWAYS ends the print cleanly, even from a wedged state |
| **HOST_RESTART_INFO** |  | explains what a host restart does |
| **HW_INFO** |  | Report the hardware profile (build volume, probe, positions) |
| **SDNAV_GO** | INDEX=0 | SD Card browser: open folder / start file at INDEX |
| **SDNAV_HOME** |  | SD Card browser: back to the G-Codes root |
| **SDNAV_PAGE** | DELTA=1 | SD Card browser: page +/ |
| **SDNAV_UP** |  | SD Card browser: one folder up |
| **SYS_FIRMWARE_RESTART** | CONFIRM=0 | Klipper restart (2x) |
| **SYS_HOST_RESTART** | CONFIRM=0 | host services restart (2x) |
| **SYS_PI_REBOOT** | CONFIRM=0 | Reboot the Pi (press twice / CONFIRM=1) - like Mainsail's button |
| **SYS_SAVE_CONFIG** | CONFIRM=0 | guarded SAVE_CONFIG: print guard + pending guard + dark-LCD warning (2x) |
| **SYS_SHUTDOWN** | CONFIRM=0 | heaters/fans off, then Pi shutdown (2x) |
| _V13_SYSTEM |  | Version sentinel of 13_system.cfg |

### KAMP — 14_kamp.cfg (8)
| Macro | Parameters | Purpose |
|---|---|---|
| **KAMP_STATUS** |  | KAMP configuration report |
| **SET_KAMP_PURGE_TYPE** | TYPE='LINE' | KAMP purge style: LINE or VORON |
| **TOGGLE_KAMP_MESH** |  | KAMP adaptive mesh on/off |
| **TOGGLE_KAMP_PURGE** |  | KAMP purge on/off |
| **TOGGLE_KAMP_SMART_PARK** |  | KAMP smart parking on/off |
| _CALIBRATE_MESH_PROFILE | PROFILE='mesh_default' | Calibrate bed mesh (KAMP/native/full) and save as profile 'r2' |
| _PURGE_SMART | LAYER_HEIGHT=0.2 | Purge: KAMP LINE/VORON_PURGE if active, else own prime line |
| _V14_KAMP |  | Version sentinel of 14_kamp.cfg |

### Objects — 15_objects.cfg (5)
| Macro | Parameters | Purpose |
|---|---|---|
| **SHOW_OBJECTS** |  | list objects + skip state |
| **SKIP_CURRENT_OBJECT** |  | skip the object currently printing (2x) |
| **SKIP_DISARM** |  | disarm a pending skip |
| **SKIP_OBJECT** | NAME='' | arm a skip for one object (2x confirm) |
| _V15_OBJECTS |  | Version sentinel of 15_objects.cfg |

### Labels — 16_labels.cfg (14)
| Macro | Parameters | Purpose |
|---|---|---|
| **GEN_LABELS** | TEXT, W, H, FONT, BASE_LAYERS, TEXT_LAYERS, LAYER_H, FIRST_H, IRONING, HOLE, HOLE_D, BRIM, GAP, COLOR2 | console/Mainsail label job: `GEN_LABELS TEXT="A\ |
| **LABEL_ADD** |  | append the edited text to the queue (max 24) |
| **LABEL_CLEAR_ALL** | CONFIRM=0 | clear the whole queue (2x) |
| **LABEL_CLEAR_TEXT** |  | clear the edit buffer |
| **LABEL_DEL_CHAR** |  | delete the character at the cursor position |
| **LABEL_DEL_LAST** |  | remove the last label from the queue |
| **LABEL_FIT_CALC** |  | Labels: font estimate for the CURRENT text on the current label size |
| **LABEL_GENERATE** | CONFIRM=0, OUT | create the file for the queued labels (bumps label_gen_nonce; the watcher builds it) |
| **LABEL_INFO** |  | queue + size + font + bed-fit info |
| **LABEL_SELECT_LINE** | L=1 | Labels: switch the text editor to line 1..5 |
| **LABEL_SHOW_TEXT** |  | show the edit buffer (LCD + console) |
| _LABELS |  | Label generator state (charset + limits, internal) |
| _LABEL_SET_CHAR | POS=sv.label_pos | default(1, CH=0 |
| _V17_LABELS |  | Version sentinel of 16_labels.cfg |

### Generators — 17_generator.cfg (49)
| Macro | Parameters | Purpose |
|---|---|---|
| **ANGLE_GENERATE** | CONFIRM=0, OUT | create the plate file from the stored settings (bumps angle_nonce) |
| **ANGLE_INFO** |  | every angle/flat setting + the auto-hole rules |
| **CABLE_TIE_GENERATE** | CONFIRM=0, OUT | create the tie file from the stored settings (bumps cable_tie_nonce; the watcher builds it, beeps + selects) |
| **CABLE_TIE_INFO** |  | every tie setting in one listing + material tip |
| **CAKE_APPLY** | YAW=0, PITCH=0, ROLL=0, Z=5, PART=BOTH, REORIENT=0, FILE= | cut the selected file with a plane (0.5° grid) — both halves become standalone files in Cake/ |
| **FRAME_DELETE_PRESET** | N=1 | Delete frame user preset N |
| **FRAME_GENERATE** | CONFIRM=0, OUT | create the frame file from the stored settings (bumps frame_nonce) |
| **FRAME_INFO** |  | every frame setting in one listing + closure explanation |
| **FRAME_LOAD_PRESET** | N=1 | Load frame user preset N |
| **FRAME_PRESETS_INFO** |  | List all frame user presets (console) |
| **FRAME_SAVE_PRESET** |  | Store the current frame settings as a user preset |
| **GEN_ANGLES** | COUNT=2, ANGLE=90, LEG_A=60, LEG_B=60, WIDTH=25, LAYERS=6, HOLES=2, HOLE_D=4, CS=1, STIFFENER=1, WALLS=2, INFILL=100, IRONING=0, FLAT=0, LAYER_H=0.2 | console/Mainsail angle/flat job: `GEN_ANGLES ANGLE=45 LEG_A=80 LEG_B=50 STIFFENER=2` — CS=1 countersunk · FLAT=1 flat connector |
| **GEN_CABLE_TIES** | COUNT=6, LENGTH=120, WIDTH=8, LAYERS=3, VARIANT='CLASSIC', LAYER_H=0.2, BRIM=1 | console/Mainsail cable-tie job: `GEN_CABLE_TIES COUNT=6 LENGTH=120 VARIANT=LOOP` — sets everything + creates the file (VARIANT: CLASSIC one-way pawl · LOOP adjustable bead loop, reusable) |
| **GEN_FILE_DEL_SLOT** | INDEX=-1 | Gen files: delete output slot INDEX (press twice to confirm) |
| **GEN_FRAME** | PRESET='', W=102, H=152, DEPTH=8, BORDER=12, CORNER=6, SHAPE='RECT', CLOSURE='BACK', HANG='TOP', STAND=0, IRONING=1, INFILL=60 | console/Mainsail frame job: `GEN_FRAME PRESET=A6 DEPTH=16 CLOSURE=BACK HANG=OFF STAND=1` — bed fit checked, kit fallback, guard errors beep + show |
| **GEN_SEAL** | OD=40, ID=20, HEIGHT=1.2, PROFILE='FLAT', IRONING=0, LAYER_H=0.2 | console/Mainsail gasket job: `GEN_SEAL OD=30 ID=15 HEIGHT=2 PROFILE=NUT` — groove + two sealing lips |
| **GEN_SHAPE** | SHAPE=CYLINDER, X=40, Y=40, Z=20, CORNERS=0, WALLS=2, WALL_THICK=0, INFILL=20, BASE=3 | geometry generator (.136n): TRIANGLE/SQUARE/POLY 3–12/CYLINDER, WALLS=1 = vase mode — output in Shapes/ |
| **LITHO_CREATE** | INDEX=0 | lithophane from image slot INDEX (0 = newest picture in Tools > Lithophane; big jobs run in a background thread) |
| **LITHO_DEL_SLOT** | INDEX=0 | delete image slot INDEX — 2-press logic like the LCD: first call arms, the second deletes (plotter `.gcode` stays) |
| **LITHO_INFO** |  | lithophane settings + how many images are ready |
| **MIRROR_APPLY** | AXIS=sv.mirror_axis | default('x', CONFIRM=0, FILE=sv.preview_file |
| **MOLD_BLANK_CREATE** | SHAPE=sv.mold_blank_shape/default('MEDALLION', PART=sv.mold_part/default('BOTH', SURFACE=sv.mold_surface/default('STANDARD', PLANE='OFF', CONFIRM=0, DIA=sv.mold_blank_dia/default(40, THICK=sv.mold_blank_thick/default(8, WIDTH=sv.mold_blank_w/default(60, HEIGHT=sv.mold_blank_h/default(40, CORNER=sv.mold_blank_corner/default(4, LENGTH=sv.mold_blank_len/default(90, BARW=sv.mold_blank_bw/default(40, BARH=sv.mold_blank_bh/default(25, TAPER=sv.mold_blank_taper/default(0.85, POCKET_T=sv.mold_blank_pt/default(2, POCKET_D=sv.mold_blank_pd/default(0, POCKET_W=sv.mold_blank_pw/default(0, POCKET_H=sv.mold_blank_ph/default(0, OUT | Molds: build a parametric blank mold (bumps mold_blank_nonce) |
| **MOLD_BLANK_INFO** |  | Molds: show the parametric blank settings |
| **MOLD_CREATE** | PART=sv.mold_part/default('BOTH', PLANE=sv.mold_plane/default('AUTO', SECTORS=sv.mold_sectors/default(0, HALF=sv.mold_sec_half/default('AUTO', SURFACE=sv.mold_surface/default('STANDARD', FILE=sv.preview_file/default('', CONFIRM=0, OUT | Molds: build the mold from the selected file (bumps mold_nonce) |
| **MOLD_INFO** |  | Molds: show the settings + the selected file |
| **SCALE_APPLY** | X=100, Y=100, TOP_X=0, TOP_Y=0, FILE= | scale the selected file 25–300 % per axis (.136n: TOP_X/TOP_Y = taper, 0 = off) — E recomputed per move, output in Scale/ |
| **SEAL_GENERATE** | CONFIRM=0, OUT | create the seal file from the stored settings (bumps seal_nonce) |
| **SEAL_INFO** |  | gasket settings + NUT/material tips |
| **SHAPE_GENERATE** | CONFIRM=0, OUT | Geometry: create the shape file (bumps shape_nonce) |
| **SHAPE_INFO** |  | Geometry: current settings |
| **STENCIL_CREATE** | INDEX=0 | spray-stencil set from image slot INDEX (0 = newest picture in the lithophane list): 2–4 tone bands, one plate each + optional negative — bridges 3× nozzle, 4 registration holes D4.2, sprays lightest→darkest (bumps stencil_nonce) |
| **STENCIL_INFO** |  | stencil settings (bands, edge, thickness, negative) + ready images |
| **STRINGART_APPLY** | PATTERN=0, SHAPE=0, W=102, H=152, DIAMETER=180, ANCHORS=300, LINES=1700, RING_H=2.4, ARC=2.0, FILE=bild.png | string art job (.136n: SHAPE 0=ROUND / 1=RECT with the photo-size presets, RING_H ring height, ARC strand bow in Z): PATTERN 0=SPIRAL / 1=PHOTO — the ring prints first (2 walls, 3+3 solid, 5% sparse), the strands ride on top in six Z bands as bows, starts 15 deg apart; PHOTO weaves the FILE image (default: the picked one), output lands in the StringArt folder |
| **STRINGART_IMG** |  | cycles the root image list (the lithophane list, newest first) for the PHOTO pattern |
| **STRINGART_PICK** | INDEX=-1 | ArtisticStrings: pick the root image from the paged image list (the PHOTO pattern weaves it) |
| **TEXTURE_APPLY** | FILE='', MODE='OFF', THICK, DENSITY, PATTERN, SCALE, AMP, DIR='OUT', OUT= | fuzzy skin / shaped bumps for the SELECTED (or FILE) g-code: `TEXTURE_APPLY MODE=FUZZY THICK=0.3 DENSITY=100` — new `Vnn_<name>_TX` file in the background — selected under QUEUE, but never auto-STARTED (ch. 5.9) |
| **TOOLCHAIN_APPLY** | PRESET=sv.toolchain_preset, FILE=sv.preview_file, CONFIRM=0, OUT= | run a preset tool chain: every step feeds the next, ONE background job, only the last output stays — `V<nn>_<name>_<PresetName>.gcode` in Toolchain/, progress `Chain n/N` on the display, input may come from any subfolder |
| **TWIST_APPLY** | DEG=90, FILE= | twist the selected file around Z (.136n): 0° at the bottom → DEG at the top, E verbatim, output in Twist/ |
| _GENERATORS |  | Part generator limits (cable ties + angle plates, internal) |
| _GEN_ARM | KEY='', WHAT='the generation' | Generators: arm the 2-press confirm for KEY |
| _GEN_GO |  | Generators: the armed second press - dialog cancel + start sound |
| _GEN_OUT_SET | OUT=QUEUE/PREVIEW (SELECT/ONLY/1/0) (int.) | the sticky generator output switch (ch. 5.0) — every `*_GENERATE` macro also takes a per-run `OUT=` |
| _GEN_PRESET | GEN='', ACTION='', NAME='preset', SRC='user', SLOT=0, DELTA=1 | User preset engine for all generators |
| _GEN_QUEUE_CLEAR | CONFIRM=0 | Drop queued/stuck generator jobs (press twice / CONFIRM=1) |
| _GEN_QUEUE_SKIP |  | Cancel the RUNNING generator job - the next one starts |
| _GEN_QUEUE_STOP | CONFIRM=0 | Cancel the running job AND clear the whole queue |
| _IMG_PAGE | DELTA=0 | Image list paging - shared by the Lithophane/ColorPicture/ArtisticStrings pickers (10 per page, up to 60 images) |
| _TX_PATTERN | SLOT=0 | Texture pattern picker for the LCD slots - page math + save + info in one place |
| _V18_GEN |  | Version sentinel of 17_generator.cfg |

### ColorPic — 18_colorpic.cfg (8)
| Macro | Parameters | Purpose |
|---|---|---|
| **COLORPIC_CREATE** | INDEX=0–9, SRC='photo.png', OUT= | create from image slot INDEX / explicit SRC / the last picked lithophane image (bumps colorpic_nonce; the watcher builds, beeps + selects) |
| **COLORPIC_SET_COLOR** | BAND=1, COLOR='' | ColorPic: store the color of one band (BAND=2 COLOR=RED) |
| **GEN_COLORPIC** | SRC='photo.png', WIDTH=25–230, BANDS=2–8, BANDH=0.4–3, COLORS='WHT,GRY,BLK', LAYER_H, IRONING=0/1, BRIM=0–8, SWAP=0/1, CONTRAST=0/1 | console/Mainsail color picture: sets everything + creates (SWAP=0 prints every band without a filament change) |
| _COLORPIC_DONE | R=1, G=1, B=1 | ColorPic: filament changed - steady new color |
| _COLORPIC_STATE |  | ColorPic blink state |
| _COLORPIC_SWAP | IDX=0, TOTAL=0, NAME='?', PREV_R=1, PREV_G=1, PREV_B=1, R=1, G=1, B=1 | ColorPic: announce the next color |
| _V18_COLORPIC |  | Version sentinel of 18_colorpic.cfg |

### Bricks — 19_bricks.cfg (12)
| Macro | Parameters | Purpose |
|---|---|---|
| **BRICK_ADD** | CODE='B2x4', COUNT=2 | add COUNT × CODE to the queue (same codes merge; unknown code or count outside 1–99 rejected) |
| **BRICK_CLEAR** | CONFIRM=1 | empty the queue (2-press: first call arms) |
| **BRICK_CREATE** | OUT=QUEUE/PREVIEW | build the file from the queue (bumps bricks_nonce; the watcher builds, beeps + selects) |
| **BRICK_DEL_LAST** |  | drop the last queue entry |
| **BRICK_INFO** |  | settings + geometry summary |
| **BRICK_SHOW** |  | list the queue |
| **GEN_BRICKKIT** | SRC='box.gcode', INDEX=0–4, DETAIL=AUTO/MICRO/SMALL/BIG, MODE=BY_LAYER/BY_OBJECT, COLORS=1–8 | sliced file → stylized kit (source = the file selected in the file list, like Texture; Mainsail: SRC=name or INDEX=0–4 = recent jobs; no silent newest-job fallback) |
| **GEN_BRICKS** | CODES='B2x4:3\ | P2x2:2' |
| **GEN_FIGURES** | SCALE=25–300, COUNT=1–24 | figures at % scale — 5 parts each, assembly without glue; only 100 % mates with the system |
| **GEN_QUEUE_CANCEL** |  | Drop all queued generator jobs (a running job finishes) |
| _BRICKS |  | Bricks module state |
| _V19_BRICKS |  | Version sentinel of 19_bricks.cfg |

### Menu helpers (menus/lcd_menues.cfg) — ../menus/lcd_menues.cfg (1)
| Macro | Parameters | Purpose |
|---|---|---|
| _V16_MENUS |  | Version sentinel of menus/lcd_menues.cfg |

### delayed_gcode hooks (30)
| Macro | Parameters | Purpose |
|---|---|---|
| _INIT_AFTER_BOOT | — | delayed_gcode hook (01_state.cfg) |
| _WATCHDOG | — | delayed_gcode hook (01_state.cfg) |
| _STATE_WATCHER | — | delayed_gcode hook (01_state.cfg) |
| _START_CONFIRM_WAITER | — | delayed_gcode hook (07_start_confirm.cfg) |
| _HOMING_GUARD_OFF | — | delayed_gcode hook (08_print_start_stop.cfg) |
| _LEGACY_HOME2 | — | delayed_gcode hook (08_print_start_stop.cfg) |
| _LEGACY_PREP2 | — | delayed_gcode hook (08_print_start_stop.cfg) |
| _OBJECT_PREP | — | delayed_gcode hook (08_print_start_stop.cfg) |
| _START_NET_PROBE | — | delayed_gcode hook (08_print_start_stop.cfg) |
| _OPT_PROMPT_HINT | — | delayed_gcode hook (08_print_start_stop.cfg) |
| _END_FAN_OFF | — | delayed_gcode hook (08_print_start_stop.cfg) |
| _END_MOTORS | — | delayed_gcode hook (08_print_start_stop.cfg) |
| _SYSTEM_BOOT | — | delayed_gcode hook (08_print_start_stop.cfg) |
| _BOOT_IDLE | — | delayed_gcode hook (08_print_start_stop.cfg) |
| _BOOT_ZSYNC | — | delayed_gcode hook (08_print_start_stop.cfg) |
| _BOOT_ZTILT | — | delayed_gcode hook (08_print_start_stop.cfg) |
| _AV_HOMING_AV | — | delayed_gcode hook (08_print_start_stop.cfg) |
| _AV_PRINT_AV | — | delayed_gcode hook (08_print_start_stop.cfg) |
| _PAUSE_NOW_ARM_OFF | — | delayed_gcode hook (09_pause_filament.cfg) |
| _SENSOR_GRACE_OFF | — | delayed_gcode hook (09_pause_filament.cfg) |
| _AV_PAUSE_AV | — | delayed_gcode hook (09_pause_filament.cfg) |
| _AV_FILAMENT_AV | — | delayed_gcode hook (09_pause_filament.cfg) |
| _AV_RESUME_AV | — | delayed_gcode hook (09_pause_filament.cfg) |
| _BS_EVAL | — | delayed_gcode hook (12_maintenance.cfg) |
| _COLD_PULL_BEEP | — | delayed_gcode hook (12_maintenance.cfg) |
| _SHAPER_REPORT | — | delayed_gcode hook (12_maintenance.cfg) |
| _SAVE_AFTER_CAL | — | delayed_gcode hook (12_maintenance.cfg) |
| _GEN_ARM_CLEAR | — | delayed_gcode hook (17_generator.cfg) |
| _COLORPIC_BLINK | — | delayed_gcode hook (18_colorpic.cfg) |
## 25. Electronics & expansion — U2C + EBB42 + Relay V1.2

One four-wire harness to the toolhead instead of a thick bundle, the printer
switchable off while the Pi stays on. All of
this is OPTIONAL — the system runs unchanged on a bare SKR Mini E3 V3. Pin
data from BigTreeTech's GitHub (EBB repo + Relay V1.2 manual) and Klipper's
`sample-bigtreetech-ebb-canbus-v1.2.cfg`.

### 26.1 The architecture — and why

```text
230V mains --L--[RELAY V1.2]--L--> PSU 24V          (relay switches the PHASE)
230V mains --N----------------> PSU 24V             (direct, never switched)
PE ----------------------------------> PSU + frame  (ALWAYS direct!)
PSU 24V out ---> SKR Mini E3 V3  (board, bed, motors, LCD)
PSU 24V out ---> EBB42 VIN       (hotend, toolhead fans) - via the SAME relay
Pi Zero 2  <== OWN 5V USB PSU ==  (never powered from the SKR again!)
Pi Zero 2 USB ---> U2C V2.1 ---> CAN (H/L, twisted) ---> EBB42 at the toolhead
SKR free pin  ---> Relay 5V_IN   (HIGH while Klipper runs = printer ON)
```

- **Pi on its own 5V USB PSU** (≥ 2.5 A headroom): the relay kills the
  printer, the Pi stays — exactly what you wanted. Never power the Pi from
  two sources at once: REMOVE the old 5V-from-SKR line.
- **U2C V2.1** hangs on the Pi's USB port (powered by the Pi — stays alive).
  It converts USB to CAN. 120 Ω jumper ON (it is one end of the bus).
- **EBB42 CAN V1.2.1** sits at the toolhead (mounted at the extruder stepper)
  — one 4-wire harness replaces heater + 2 fans + probe + stepper
  cables. 120 Ω jumper ON (the other end). EXACTLY TWO terminators total.
- **Relay V1.2 in the 230V phase**: rated 10 A / 250 VAC — the whole printer
  draws ~1.5 A at 230 V. The module's control input (5V_IN, logic 3.3–5 V)
  comes from a free SKR pin that Klipper holds HIGH. Klipper dead = pin LOW
  = printer OFF: a hard FAIL-SAFE (a crashed host can never leave heaters
  powered). Your DC-DC 5V module is not needed in this architecture — keep
  it as a spare.
- **UART stays**: the SKR keeps talking to the Pi on the UART pins (the Pi
  Zero's only USB data port is used by the U2C). Add a 10 kΩ resistor in
  series with each UART line so the always-on Pi cannot phantom-power the
  unpowered SKR through its RX pin when the relay is off.

### 26.2 The cable list — EBB at the extruder stepper

Measure along the real route (carriage → X extrusion → chain → electronics
bay); these are proven starting points for an Ender-3 class frame:

| # | Cable | From → To | Type / gauge | Length | Connector at the EBB |
|---|---|---|---|---|---|
| 1 | 24 V + GND | PSU out (relay-switched) → EBB | 2 × silicone 0.5 mm² (20 AWG) | ~1.4 m | VIN screw terminal (mind polarity + onboard fuse) |
| 2 | CAN-H / CAN-L | U2C CAN port → EBB | twisted pair 0.14–0.25 mm² (26–24 AWG) | ~1.4 m | 4-pin CAN (use H, L, GND; verify pin order on BOTH silkscreens — never trust wire colors) |
| 3 | Extruder stepper | motor → EBB | existing 4-pin, shortened | 10–15 cm | motor header (onboard TMC2209) |
| 4 | Hotend heater | cartridge → EBB | existing silicone, shortened | 15–20 cm | HE terminal (40 W ≈ 1.7 A, EBB allows 5 A) |
| 5 | Hotend thermistor | → EBB | existing, shortened | 15–20 cm | TH0 (PA3) |
| 6 | Hotend fan | → EBB | existing, shortened | ~15 cm | FAN (PA1) — max 1 A |
| 7 | Part fan | → EBB | existing, shortened | ~20 cm | FAN (PA0) — max 1 A |
| 8 | MicroProbe | → EBB | existing BLTouch-style, shortened | 20–25 cm | probe port: signal PB8, control/power PB9 (MicroProbe: 3rd wire = POWER) |
| 10 | Filament sensor (optional) | → EBB | 2-pin | ~20 cm | PB4 (switch) or PB3 (motion) |

Stays where it is: **X endstop** (stationary at the gantry — stays on the
SKR), bed + Z + Y (SKR). Reuse your existing cables by SHORTENING them at the
toolhead end — the long run to the bay is now only the 4-wire harness.

### 26.3 Firmware: flashing the EBB42 (once)

1. On the Pi: `cd ~/klipper && make menuconfig` — STM32, **STM32G0B1**,
   8 MHz crystal, **CAN bus (on PB0/PB1)**, CAN speed **1000000** (matches
   BTT's precompiled firmware; if you build for 500 k, change can0 too),
   8 KiB bootloader (katapult).
2. `make` → flash via DFU: USB-C jumper for USB power, hold RESET+BOOT,
   release RESET then BOOT, `lsusb` shows the DFU device, flash with
   `make flash FLASH_DEVICE=...`.
3. Bring CAN up on the Pi (`/etc/network/interfaces.d/can0`, bitrate matching
   the firmware, `sudo reboot`), then
   `~/klippy-env/bin/python ~/klipper/scripts/canbus_query.py can0`
   → `Found canbus_uuid=...`.
4. Copy the `[mcu EBB]` block from `printer.cfg.example` into printer.cfg.

### 26.4 printer.cfg changes (full template in printer.cfg.example)

Move to the EBB: extruder stepper (PD0/!PD1/!PD2, TMC2209 UART PA15), hotend
heater (PB13) + thermistor (PA3), part fan (PA0), hotend fan (PA1),
MicroProbe (PB8/PB9), optional filament sensor (PB4).
Delete the old copies on the SKR pins (LED sections are no longer part of the
system — the LED macros and the `[neopixel]`/`[led_effect]` sections were
removed in 26.20).

### 26.5 Relay V1.2 — printer OFF, Pi stays on

Wiring: mains L into the relay's AC-in, AC-out to the PSU's L (N and PE
direct). 5V_IN + GND of the relay to the SKR's `[output_pin power_hold]` pin
(`value: 1`, `shutdown_value: 0`). The relay's button connector takes any
momentary switch for manual power-on. `PRINTER_POWER_OFF` (template in
printer.cfg.example): refuses while printing, heaters off, then drops the
pin. Power-on flow: press the button → boards boot → **FIRMWARE_RESTART**
(the MCUs were completely off). Add the macro to your System menu or console
— the system's `SYS_SHUTDOWN` (Pi off) stays as it is.

**SAFETY — read before touching mains**

- 230 V is lethal. Work only with the plug pulled; if you are not sure, have
  an electrician do the mains side. The relay PCB carries live power on open
  pads — mount it in the enclosed electronics bay, away from anything
  conductive, "No touch! High voltage danger!" is printed on it for a reason.
- NEVER switch or interrupt PE. Only the L conductor goes through the relay.
- Wire gauge: mains side 0.75 mm²+ with ferrules and strain relief; 24 V
  bed path stays untouched (it runs through the SKR, not the relay).
- The 10 A relay contact is for the whole printer at ~1.5 A — do NOT use it
  to switch 24 V DC directly (arcing!) — on the DC side the bed alone draws
  ~10 A: over the rating and DC arcs do not self-extinguish.
- Insulate everything, check every crimp twice, measure before powering up
  (with everything off: CAN-H↔CAN-L should read ~60 Ω = two 120 Ω in
  parallel — the standard termination check).
- After a relay-off, the EBB was unpowered while Klipper ran — expect one
  "MCU shutdown/lost" message; FIRMWARE_RESTART after power-on is normal.

### 26.6 NeoPixel limits at the EBB

(The EBB42's RGB port is no longer used by the system — LED control was
removed in 26.20.)

---

## Appendix A: Installation (detailed)

### A.1 Requirements

- Klipper + Moonraker + Mainsail (or Fluidd), path `~/printer_data/`
- the 15 macro modules + `menus/lcd_menues.cfg`
- `[save_variables]` — the memory (survives restarts)

### A.2 printer.cfg checklist (see printer.cfg.example)

| Section | Why / Notes |
|---|---|
| [save_variables] | ALL settings/presets live here — exact path matters |
| [virtual_sdcard] [pause_resume] [display_status] [respond] [exclude_object] | infrastructure; exclude_object unlocks adaptive mesh + object skip + smart parking |
| [idle_timeout] timeout: 3600 | pause management saves/restores this |
| [firmware_retraction] | live retraction + retraction overrides + test |
| [filament_switch_sensor filament_sensor] | runout handling — NAME matters, pause_on_runout: False |
| [pwm_cycle_time beeper] pin PB5 | sounds — pwm_cycle_time NOT output_pin (runtime frequency!) |
| [display] (st7920) | LCD menus (12864, 16 characters per line) |
| [force_move] enable_force_move: True | SYNC_GANTRY needs SET_KINEMATIC_POSITION |
| [screws_tilt_adjust] / [bed_mesh] + adaptive_margin: 5 | leveling / meshing |
| [probe] / [resonance_tester]+[adxl345] | see A.3 / optional shaper calibration |

```
[include klipper-e3-r2d2/macros/01_state.cfg]
... 02 .. 15 ...
[include klipper-e3-r2d2/menus/lcd_menues.cfg]
-- at the END of printer.cfg; macros first, menus last
```

**A.2.1 The real bed — [gcode_macro _R2_CONFIG] (required once):**
this machine's `position_max` is lifted on purpose (micro probe + bed mesh
rides beyond the plate). So the generators, the prime line and the park
corners read the REAL printable bed from this section — add it once:

```
[gcode_macro _R2_CONFIG]
variable_bed_min_x: 0.0
variable_bed_max_x: 220.0
variable_bed_min_y: -3.0
variable_bed_max_y: 217.0
gcode:
    # config carrier only - never runs
```

Without it everything falls back to the Ender-3 default 220×220 and the
console notes that on every watcher start. Optional positions:
`variable_present_x`/`variable_present_y` (PRINT_END part presentation,
default 10/228) and `variable_wipe_x`/`variable_wipe_y` (nozzle-wipe pad
anchor, −1 = axis-minimum corner) — all clamped to the axes, see chapter 22.
A raw `[r2_postproc]` section (pre-.82) HALTS Klipper — `setup.sh` migrates it.

### A.3 Z-probe variants

- Stock probe with offsets (MicroProbe !PC14, x/y offset): works 1:1
- BLTouch/3DTouch: [probe] with pin + offsets; `samples_tolerance: 0.15` against dirty points
- Inductive/capacitive: same section; mind the sensing distance on PEI spring steel
- Klicky/Euclid: works — docking macros are yours; mesh runs via BED_MESH_CALIBRATE
- No probe: mesh + LEVEL_BED_SCREWS unavailable; level via [bed_screws], Z-offset by hand

### A.4 Filament sensor variants

```ini
[filament_switch_sensor filament_sensor]
switch_pin: !PC15     # YOUR pin
pause_on_runout: False
runout_gcode: _FILAMENT_RUNOUT
insert_gcode: _FILAMENT_INSERTED
```

Motion sensors (BTT Smart) may add `runout_distance: 3.0`. Without a sensor
everything else runs fine — runout simply never triggers.


## Appendix B: Power & electrics

Voltage domains, safe supply for the Pi Zero 2 W and Neopixels, the UART serial
link, multi-PSU ground rules and silent-fan mods. Based on the BTT wiring guide
and BTT/community findings. **Verify every rail with a multimeter before
connecting anything.**

### B.1 Voltage map

```
230 V mains -> [24 V PSU] -> bed heater (HB, 20 A fuse) | hotend | steppers | fans | probe VIN
                             -> [SKR mini E3 v3.0]  (onboard 5 V buck ~1 A max - logic only!)
                             -> [DCDC 24V->5V >=3 A] -> Pi Zero 2 W + Neopixels (own rails)
```

### B.2 What the onboard 5 V buck can (not) do

- Onboard buck of the SKR mini E3 v3.0: **~1 A max** (community consensus). BTT's
  own wiring guide: the board is NOT capable of powering a Raspberry Pi.
- Pi Zero 2 W + 5 Neopixels from the board 5 V = right at that limit → brown-outs,
  unstable Pi, SD corruption risk.
- **Official upgrade path:** the green **Neo-PWR1 jumper** selects the 5 V source —
  onboard buck OR the plug-in **BTT DCDC Mode V1.0 module** (MP1584, ~3 A ideal,
  BTT documents up to 30 Neopixel). Alternative: any external 24V→5V buck ≥3 A.

### B.3 Target wiring — one ground star, never parallel plus-rails

```
24V PSU --+24V--> SKR (VIN+/VIN-)          SKR --UART 3 wires--> Pi
          --+24V--> [DCDC 24V->5V] --+5V--> Pi (USB-PWR or GPIO 2/4 + GND 6)
                                  +--5V--> 5x Neopixel (data: PA8 + series R)
GND: every V- lands on ONE star point. Only GND is shared -
     NEVER tie +5 V of two sources together. SW_USB jumper: REMOVE.
```

**Golden rules:** 1) tie ALL V− together at one star point. 2) NEVER parallel +5 V
of two sources. 3) Remove the SW_USB jumper (USB-5 V backfeed). 4) Fuse each 5 V
rail; Pi wiring ≥24 AWG. 5) Measure before first connect: 5.0-5.2 V. 6) Pi GPIO
5 V bypasses the polyfuse — only from a verified, steady source.

### B.4 Powering the Pi Zero 2 W — three options

| Option | How | Verdict |
|---|---|---|
| from the SKR 5 V | 5 V + GND from the board | ✗ ~1 A is already spent — not recommended |
| **USB PWR-IN (micro-USB)** | 5 V ≥2.5 A from the buck/PSU | ✓ cleanest: own cable, keeps polyfuse path |
| GPIO pins 2 (5V) + 6 (GND) | direct into the header | ✓ ok from a measured rail — bypasses the Pi polyfuse |

### B.5 UART instead of USB (TX/RX)

```
Pi Zero 2 W header          SKR mini E3 v3.0 (TFT port)
pin 8  TXD  ----------------> TFT pin 2 RX        (crossover!)
pin 10 RXD  <---------------- TFT pin 3 TX
pin 6  GND  <---------------- TFT pin 4 GND       (mandatory)
```

Pi: `/boot/config.txt` → `enable_uart=1`, `dtoverlay=disable-bt`;
`/boot/cmdline.txt` → remove `console=serial0,115200`. Klipper firmware
(make menuconfig): STM32 → STM32G0B1 → Serial (on USART2 PA3/PA2), bootloader
28 KiB. Then `[mcu] serial: /dev/ttyAMA0 · baud: 250000 · restart_method: command`.
Pin numbers: verify against the BTT pinout PDF of your board revision.

### B.6 Neopixels safely on external 5 V

- **1000 µF electrolytic** across +5 V/GND at the first pixel (inrush)
- **330-470 Ω series resistor** right before DIN (protects pixel 1)
- **common ground with the SKR is mandatory** — otherwise the 3.3 V data has no reference
- long wires or ghost pixels → 74AHCT125 level shifter
- Budget: 5 px × 60 mA = 0.3 A worst case (full white) — a ≥3 A buck has headroom

### B.7 Silent fan mods

| Mod | Wiring | Notes |
|---|---|---|
| 24 V silent fans | plug & play into FAN0/1/2 | simplest — FAN ports run at the 24 V rail |
| 12 V fans (Noctua…) via buck | buck 24V→12V; fan+ from buck, fan− into the board FAN port (low-side) | common ground comes free (same PSU); verify polarity |
| electronics-bay fan | small fan on the electronics housing | keeps drivers + buck cool |

Hotend heatsink fan: keep at 100% whenever the hotend is hot (enforced by the
system). Better a quiet fan at full speed than a fast one slowed down.

### B.8 First-power-on checklist

1. Buck output measured: 5.0-5.2 V BEFORE the Pi or any pixel is connected.
2. Continuity: every V− lands on the star point.
3. NO continuity between separate +5 V rails.
4. SW_USB jumper removed; Neo-PWR1 set to your 5 V source.
5. All joints soldered + heat-shrunk; no stray strands.
6. Boot order: 24 V PSU → SKR → buck rails stable → Pi.

### B.9 Where do I connect what? (quick reference)

| Signal / Load | Comes from | Goes to | Watch out |
|---|---|---|---|
| Pi Zero 2 W, 5 V | DCDC/buck 5 V (≥2.5 A) | micro-USB PWR (best) or GPIO 2+6 | GPIO path bypasses the Pi polyfuse |
| UART serial | Pi GPIO 14/15 | TFT port RX/TX (crossover) | GND mandatory · verify BTT pinout |
| Filament sensor | 5 V + GND (SKR) | signal → !PC15 | pause_on_runout: False |
| Silent fans 12 V | buck 24V→12V | fan+ from buck, fan− to FAN port | low-side switching — polarity! |

## Appendix C: First start & updates

- upload the folder → includes at the end of printer.cfg → RESTART
- console: `Macro system OK: all 18 modules loaded and current (build R2-2026-11-20.0)`
- ~10 s later: boot sound
- SHOW_STATUS → mode, material, overrides · Maintenance > Tests > demos + self test

**Updating (simple):** 1) upload the ZIP in Mainsail into the **config
folder** (where printer.cfg lives — next to the `klipper-e3-r2d2` folder, not
inside it), 2) SSH: `bash ~/printer_data/config/klipper-e3-r2d2/update.sh` —
it finds the newest uploaded ZIP, unzips it over the old folder, checks the
includes and the `#` blocker and restarts Klipper and r2-postproc (python3
fallback if `unzip` is missing; older ZIPs are skipped unless `--force`; the
uploaded ZIP may stay in the folder). Mixed old/new files
are detected by _CHECK_INSTALL at boot. All settings live in variables.cfg
and survive every update.

**Daily health check:** SELF_TEST + SHOW_STATUS before long prints.
